// Dauntless Forever - Dauntless 1.6.2 server DLL (UndauntedInternalServer)
// Copyright (C) 2026 Addison2k (port to this Dauntless build and all changes). https://github.com/addison2k/DauntlessForever
// Based on Undaunted, Copyright (C) gwog and contributors, https://github.com/SyST3MDeV/Undaunted
// Licence: AGPL-3.0-only (LICENSE-AGPL-3.0.txt). Keep this notice: the licence requires it.
// ObjectivePriming.inl - server side
//
// The game server only replicates objectives that CHANGE this session (UProgressionComponent::UpdatedPlayerObjectives),
// so mastery bars show 0 in town even though the progress is saved. When a player has been connected for a few
// seconds, this fetches their saved objectives from the metagame (/internal/objectives/<id>, local only) and appends
// them to UpdatedPlayerObjectives, which Unreal then replicates to that player's client like normal updates.
//
// #include this in dllmain.cpp right ABOVE "void* OrigGameEngineTick", and call TickObjectivePriming(DeltaTime)
// inside GameEngineTickHook's "if (Globals::Listening && Networking::NetDriver)" block.

#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")
#include <mutex>
#include <set>
#include <new>

struct PrimedObjective {
    std::wstring Id;
    int32_t Value;
    int32_t Completed;
};

static std::mutex PrimeMutex;
static std::map<void*, std::vector<PrimedObjective>> PrimeReady;   // player controller -> fetched objectives
static std::map<void*, float> PrimeWait;                           // player controller -> seconds connected (-1 = fetching)
static std::set<void*> PrimeDone;

static const float PrimeDelaySeconds = 8.0f;
static const uintptr_t FMemoryReallocRva = 0x1E4A690;              // FMemory::Realloc (1.6.2)

static std::string PrimeHttpGet(const std::wstring& Path)
{
    std::wstring Host = L"127.0.0.1";
    INTERNET_PORT Port = 61000;
    size_t Colon = Globals::MetagameAddress.find(L':');
    if (Colon != std::wstring::npos) {
        Host = Globals::MetagameAddress.substr(0, Colon);
        Port = (INTERNET_PORT)std::stoi(Globals::MetagameAddress.substr(Colon + 1));
    }

    std::string Body;
    HINTERNET Session = WinHttpOpen(L"Undaunted", WINHTTP_ACCESS_TYPE_NO_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    HINTERNET Connect = Session ? WinHttpConnect(Session, Host.c_str(), Port, 0) : nullptr;
    HINTERNET Request = Connect ? WinHttpOpenRequest(Connect, L"GET", Path.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0) : nullptr;

    if (Request && WinHttpSendRequest(Request, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(Request, nullptr)) {
        DWORD Available = 0;
        while (WinHttpQueryDataAvailable(Request, &Available) && Available > 0) {
            std::string Chunk(Available, '\0');
            DWORD Read = 0;
            if (!WinHttpReadData(Request, Chunk.data(), Available, &Read) || Read == 0)
                break;
            Body.append(Chunk.data(), Read);
        }
    }

    if (Request) WinHttpCloseHandle(Request);
    if (Connect) WinHttpCloseHandle(Connect);
    if (Session) WinHttpCloseHandle(Session);
    return Body;
}

static void PrimeStartFetch(void* Key, const std::string& AccountId)
{
    std::thread([Key, AccountId]() {
        std::string Body = PrimeHttpGet(L"/internal/objectives/" + std::wstring(AccountId.begin(), AccountId.end()));

        // Lines of "id<TAB>value<TAB>completed"
        std::vector<PrimedObjective> List;
        size_t Start = 0;
        while (Start < Body.size()) {
            size_t End = Body.find('\n', Start);
            if (End == std::string::npos) End = Body.size();
            std::string Line = Body.substr(Start, End - Start);
            Start = End + 1;

            size_t Tab1 = Line.find('\t');
            size_t Tab2 = Tab1 == std::string::npos ? std::string::npos : Line.find('\t', Tab1 + 1);
            if (Tab2 == std::string::npos) continue;

            std::string Id = Line.substr(0, Tab1);
            try {
                List.push_back({ std::wstring(Id.begin(), Id.end()),
                                 (int32_t)std::stol(Line.substr(Tab1 + 1, Tab2 - Tab1 - 1)),
                                 (int32_t)std::stol(Line.substr(Tab2 + 1)) });
            }
            catch (...) {}
        }

        std::lock_guard<std::mutex> Lock(PrimeMutex);
        PrimeReady[Key] = std::move(List);
    }).detach();
}

static void PrimeAppendObjectives(SDK::UProgressionComponent* Comp, const std::vector<PrimedObjective>& List)
{
    if (List.empty()) return;

    // Raw TArray layout: Data, Num, Max. Memory must come from the game's allocator.
    struct RawArray { SDK::FPlayerObjective* Data; int32_t Num; int32_t Max; };
    auto* Arr = reinterpret_cast<RawArray*>(&Comp->UpdatedPlayerObjectives);
    auto Realloc = reinterpret_cast<void* (*)(void*, size_t, uint32_t)>(Globals::BaseAddress + FMemoryReallocRva);

    int32_t NewNum = Arr->Num + (int32_t)List.size();
    if (NewNum > Arr->Max) {
        Arr->Data = reinterpret_cast<SDK::FPlayerObjective*>(Realloc(Arr->Data, sizeof(SDK::FPlayerObjective) * NewNum, 0));
        Arr->Max = NewNum;
    }

    for (size_t i = 0; i < List.size(); i++) {
        SDK::FPlayerObjective* Slot = &Arr->Data[Arr->Num + i];
        memset(Slot, 0, sizeof(*Slot));
        new (&Slot->ObjectiveId) SDK::FString(List[i].Id.c_str());   // copies into game memory
        Slot->Value = List[i].Value;
        Slot->CompletedCount = List[i].Completed;
    }
    Arr->Num = NewNum;
}

static void TickObjectivePriming(float DeltaTime)
{
    std::set<void*> Current;

    for (SDK::UNetConnection* Conn : Networking::NetDriver->ClientConnections) {
        if (!Conn || !Conn->PlayerController || !Conn->PlayerController->PlayerState)
            continue;

        void* Key = Conn->PlayerController;
        Current.insert(Key);
        if (PrimeDone.count(Key))
            continue;

        if (!Conn->PlayerController->IsA(SDK::AArchonPlayerController::StaticClass())) {
            PrimeDone.insert(Key);
            continue;
        }
        auto* PC = static_cast<SDK::AArchonPlayerController*>(Conn->PlayerController);

        // Wait until the player has been in for a bit, then fetch in the background
        auto Wait = PrimeWait.find(Key);
        if (Wait == PrimeWait.end() || Wait->second >= 0.0f) {
            float& Seconds = PrimeWait[Key];
            Seconds += DeltaTime;
            if (Seconds < PrimeDelaySeconds)
                continue;

            std::string AccountId = static_cast<SDK::AArchonPlayerState*>(PC->PlayerState)->GetUniqueIdAsString().ToString();
            size_t Uid = AccountId.find("UID-");
            if (Uid != std::string::npos) AccountId = AccountId.substr(Uid);

            PrimeStartFetch(Key, AccountId);
            Seconds = -1.0f;
            continue;
        }

        // Fetched? Append on the game thread.
        std::vector<PrimedObjective> List;
        {
            std::lock_guard<std::mutex> Lock(PrimeMutex);
            auto Ready = PrimeReady.find(Key);
            if (Ready == PrimeReady.end())
                continue;
            List = std::move(Ready->second);
            PrimeReady.erase(Ready);
        }

        SDK::UProgressionComponent* Comp = PC->GetProgressionComponent();
        if (Comp) {
            PrimeAppendObjectives(Comp, List);
            std::cout << "[Objectives] Sent " << List.size() << " saved objectives to a joining player" << std::endl;
        }
        PrimeDone.insert(Key);
    }

    // Forget players who left (their controller address can be reused)
    for (auto It = PrimeDone.begin(); It != PrimeDone.end();) { if (!Current.count(*It)) It = PrimeDone.erase(It); else ++It; }
    for (auto It = PrimeWait.begin(); It != PrimeWait.end();) { if (!Current.count(It->first)) It = PrimeWait.erase(It); else ++It; }
}
