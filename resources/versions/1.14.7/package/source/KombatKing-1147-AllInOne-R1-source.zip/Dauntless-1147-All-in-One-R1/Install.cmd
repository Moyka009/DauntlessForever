@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run.ps1" -Action install
set "patchExit=%errorlevel%"
echo.
echo Press any key to close . . .
pause >nul
exit /b %patchExit%
