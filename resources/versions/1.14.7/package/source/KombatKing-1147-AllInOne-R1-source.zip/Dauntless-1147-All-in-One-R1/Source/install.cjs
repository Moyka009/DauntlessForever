// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{prepare,cmp}=require('./launcher.cjs'),{entries}=require('./paks.cjs');
const base=path.resolve(__dirname,'..'),read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'')),hash=(b,alg='sha256')=>crypto.createHash(alg).update(b).digest('hex'),bytes=p=>fs.existsSync(p)?fs.readFileSync(p):null;
function files(dir){const a=[];for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())a.push(...files(p));else a.push(p);}return a;}
function write(p,b){if(b===null){fs.rmSync(p,{force:true});return;}fs.mkdirSync(path.dirname(p),{recursive:true});const t=p+'.aio-'+crypto.randomUUID();try{fs.writeFileSync(t,b,{flag:'wx'});fs.renameSync(t,p);}finally{fs.rmSync(t,{force:true});}}
function verify(){for(const[n,h]of Object.entries(read(path.join(base,'Integrity.json')).files)){if(path.isAbsolute(n)||n.split('/').includes('..')||hash(fs.readFileSync(path.join(base,n)))!==h)throw Error('All-in-one SHA256 mismatch: '+n);}}
function setup(root,launcher,game,spec){
 if(hash(fs.readFileSync(path.join(game,'Archon/Binaries/Win64/Dauntless-Win64-Shipping.exe')))!==spec.exe_sha256)throw Error('Requires Dauntless 1.14.7 CL647472; executable SHA256 differs');
 const candidates=[path.join(root,'version.json'),...(path.basename(root).toLowerCase()==='package'?[path.join(path.dirname(root),'version.json')]:[]),path.join(launcher,'resources/versions/1.14.7/version.json')].filter(p=>fs.existsSync(p));
 if(!candidates.length)throw Error('Launcher version metadata not found; complete the official 1.14.7 setup first');
 const metas=candidates.map(p=>({p,m:read(p)}));const newest=metas.reduce((v,x)=>cmp(x.m.package?.packageVersion||'',v)>0?x.m.package.packageVersion:v,'');
 if(cmp(newest,spec.upstream_package)>0)throw Error('A newer official server package needs comparison before installing this build');
 for(const{p,m}of metas.filter(x=>(x.m.package?.packageVersion||'')===newest)){
  if(m.id!=='1.14.7'||String(m.exeSha256).toLowerCase()!==spec.exe_sha256||m.package?.play!=='tools/start.ps1'||!m.package.installedFiles?.length)throw Error('Unsupported launcher setup metadata: '+p);
  for(const e of m.package.installedFiles){const n=String(e.rel).replaceAll('\\','/');if(path.isAbsolute(n)||n.split('/').includes('..'))throw Error('Invalid installed-file path');const b=bytes(path.join(game,n));if(!b||hash(b)!==String(e.sha256).toLowerCase())throw Error('Complete official 1.14.7 setup first; installed file differs: '+n);}
 }
 const common=fs.readFileSync(path.join(root,'tools/common.ps1'),'utf8');for(const[key,n]of [['LoaderHash','dxgi.dll'],['StandInHash','EOSSDK-Win64-Shipping.dll']]){
  const m=new RegExp('\\$'+key+"\\s*=\\s*'([0-9a-f]{64})'",'i').exec(common),actual=bytes(path.join(game,'Archon/Binaries/Win64',n));if(!m||!actual||hash(actual)!==m[1].toLowerCase())throw Error('Official startup/native DLL hashes differ: '+n);
 }
 for(const[n,h]of Object.entries(spec.source_paks)){const b=bytes(path.join(game,'Archon/Content/Paks',n));if(!b||hash(b,'sha1')!==h)throw Error('Original game PAK differs from the 1.14.7 manifest: '+n);}
 if(!fs.existsSync(path.join(root,'captures'))||!fs.existsSync(path.join(root,'eos/eos_offline.ini')))throw Error('Complete official setup first; capture/sign-in setup markers are missing');
}
function clamp(b){if(b===null)return null;const defs=read(path.join(base,'Payload/package/rules.json')).rules,keys=new Set(defs.filter(r=>r.choices.some(c=>Number(c[0])>1)).map(r=>r.key));const s=b.toString('utf8').replace(/^(\uFEFF?[ \t]*)([a-z_]+)([ \t]*=[ \t]*)([0-9.]+)([ \t]*)(\r?)$/gm,(all,a,k,eq,v,ws,cr)=>keys.has(k)&&Number(v)>5?a+k+eq+'5'+ws+cr:all);return Buffer.from(s);}
function install(packageDir,launcherDir,action='install',options={}){
 if(!['install','check','restore'].includes(action))throw Error('Unknown action');verify();const root=fs.realpathSync(packageDir),launcher=fs.realpathSync(launcherDir),dir=path.join(root,'backup/all-in-one1147-r1'),receipt=path.join(dir,'installation.json'),pending=path.join(dir,'pending.json');
 if(fs.existsSync(pending))throw Error('Interrupted all-in-one transaction. Keep backup/all-in-one1147-r1 intact for recovery');
 if(fs.existsSync(receipt)){
  const r=read(receipt);if(r.revision!==1||r.package!==root||r.launcher!==launcher)throw Error('All-in-one backup belongs to another installation');
  const before=r.files.map((t,i)=>{const b=t.existed?fs.readFileSync(path.join(dir,i+'.original')):null;if(b!==null&&hash(b)!==t.original)throw Error('Original all-in-one backup hash differs');return b;});
  if(action!=='restore'){
   try{
    const cfg=read(path.join(root,'config.json'));if(typeof cfg.GameDir!=='string'||fs.realpathSync(cfg.GameDir)!==r.game)throw Error('Configured game folder changed after installation');
    setup(root,launcher,r.game,read(path.join(__dirname,'compatibility.json')));
   }catch(e){if(action==='check')return{installed:false,package:root,reason:e.message};throw e;}
  }
  const good=r.files.every(t=>{if(t.keepOnRestore)return true;const b=bytes(t.path);if(t.kind==='pointer'){if(!b)return false;const cur=JSON.parse(b);return cur.version===t.version&&String(cur.sha256).toLowerCase()===t.installedChecksum;}return b!==null&&hash(b)===t.installed;});
  if(action==='check'){const currentDyes=bytes(path.join(root,'backend/dyes1147.js')),wantedDyes=fs.readFileSync(path.join(base,'Payload/package/backend/dyes1147.js')),dyePackCurrent=currentDyes!==null&&currentDyes.equals(wantedDyes);return{installed:good&&dyePackCurrent,package:root,components:12,game:r.game,dye_pack_current:dyePackCurrent,dye_store:dyePackCurrent?'one free All Dyes pack; captured individual dye listings removed':'run this updated Install.cmd to update the dye store'};}if(!good)throw Error('A managed file changed after installation; no files overwritten');if(action==='install'){const upgraded=require('./upgrade-dyes.cjs').upgrade({base,root,dir,receipt,r,write,afterWrite:options.afterWrite});return{installed:true,already_installed:!upgraded,updated:upgraded,components:12,dye_store:'one free All Dyes pack',saves_preserved:true};}
  const current=r.files.map(t=>bytes(t.path));fs.writeFileSync(pending,'restore',{flag:'wx'});
  try{for(let i=0;i<r.files.length;i++){const t=r.files[i];if(t.keepOnRestore)continue;let b=before[i];if(t.kind==='pointer'){const cur=JSON.parse(current[i]);cur.sha256=t.beforeChecksum;b=Buffer.from(JSON.stringify(cur,null,1));}write(t.path,b);options.afterWrite?.(i,t);}fs.unlinkSync(pending);fs.renameSync(dir,dir+'-restored-'+crypto.randomUUID());}
  catch(e){for(let i=0;i<r.files.length;i++)write(r.files[i].path,current[i]);fs.rmSync(pending,{force:true});throw e;}
  return{restored:true,saves_preserved:true,current_settings_preserved:true};
 }
 if(action==='check')return{installed:false,package:root};if(action==='restore')throw Error('No all-in-one installation record');if(fs.existsSync(dir))throw Error('Incomplete all-in-one backup folder');
 const cfg=read(path.join(root,'config.json'));if(typeof cfg.GameDir!=='string'||!path.isAbsolute(cfg.GameDir))throw Error('GameDir missing from official config.json');const game=fs.realpathSync(cfg.GameDir),spec=read(path.join(__dirname,'compatibility.json'));setup(root,launcher,game,spec);
 const plan=[];
 for(const p of files(path.join(base,'Payload/package'))){const n=path.relative(path.join(base,'Payload/package'),p).replaceAll('\\','/'),target=path.join(root,n),before=bytes(target),after=fs.readFileSync(p);
  if(before!==null&&!before.equals(after)&&!spec.allowed[n]?.includes(hash(before)))throw Error('Unknown edited package file; no files changed: '+n);plan.push({path:target,after,kind:'package'});
 }
 const pakDir=path.join(game,'Archon/Content/Paks'),ours=new Set();let protectedAssets=new Set();
 for(const p of files(path.join(base,'Payload/paks'))){const n=path.basename(p),target=path.join(pakDir,n),before=bytes(target),after=fs.readFileSync(p);ours.add(n.toLowerCase());for(const a of entries(p))protectedAssets.add(a);
  if(before!==null&&!before.equals(after)&&!spec.allowed['paks/'+n]?.includes(hash(before)))throw Error('Unknown edited patch PAK: '+n);plan.push({path:target,after,kind:'pak'});
 }
 const originals=new Set(spec.original_paks.map(n=>n.toLowerCase()));for(const n of fs.readdirSync(pakDir))if(n.toLowerCase().endsWith('.pak')&&!ours.has(n.toLowerCase())&&!originals.has(n.toLowerCase())){
  if(entries(path.join(pakDir,n)).some(a=>protectedAssets.has(a)))throw Error('Another overlay replaces an all-in-one asset: '+n);
 }
 const launch=prepare(launcher,options.env||process.env);plan.push(...launch.plan);
 const setting=path.join(root,'data/rules.txt'),oldSettings=bytes(setting),capped=clamp(oldSettings);if(oldSettings&&!oldSettings.equals(capped))plan.push({path:setting,after:capped,kind:'settings',keepOnRestore:true});
 if(new Set(plan.map(t=>t.path.toLowerCase())).size!==plan.length)throw Error('Duplicate target in all-in-one transaction');
 const before=plan.map(t=>bytes(t.path)),r={revision:1,package:root,launcher,game,components:12,created:new Date().toISOString(),files:plan.map((t,i)=>({path:t.path,kind:t.kind,keepOnRestore:!!t.keepOnRestore,existed:before[i]!==null,original:before[i]===null?null:hash(before[i]),installed:hash(t.after),...(t.kind==='pointer'?{version:t.version,beforeChecksum:t.beforeChecksum,installedChecksum:t.installedChecksum}:{})}))};
 fs.mkdirSync(dir,{recursive:true});
 try{for(let i=0;i<plan.length;i++)if(before[i]!==null)fs.writeFileSync(path.join(dir,i+'.original'),before[i],{flag:'wx'});fs.writeFileSync(pending,JSON.stringify(r,null,2),{flag:'wx'});
  for(let i=0;i<plan.length;i++){write(plan[i].path,plan[i].after);options.afterWrite?.(i,plan[i]);}fs.writeFileSync(receipt,JSON.stringify(r,null,2),{flag:'wx'});fs.unlinkSync(pending);
 }catch(e){for(let i=0;i<plan.length;i++)write(plan[i].path,before[i]);fs.rmSync(dir,{recursive:true,force:true});throw e;}
 return{installed:true,package:root,game,components:12,active_launcher:launch.active,saves_preserved:true,settings_capped_to:5,prior_patch_installers_required:false,dye_store:'one free All Dyes pack; captured individual dye listings removed',gauntlet_rewards:'not implemented'};
}
if(require.main===module){try{const r=install(process.argv[3],process.argv[4],process.argv[2]);console.log(JSON.stringify(r,null,2));if(process.argv[2]==='check'&&!r.installed)process.exitCode=1;}catch(e){console.error(e.message);process.exitCode=1;}}
module.exports={install,clamp,setup,verify};
