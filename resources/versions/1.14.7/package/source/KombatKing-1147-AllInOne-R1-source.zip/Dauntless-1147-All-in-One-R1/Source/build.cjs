// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..'),src=n=>path.join(root,'Patches',n,'Source'),out=path.join(root,'Payload/package');
const stages=['03-Game-Rules','04-Fountain-Supplies','05-Middleman','06-Trials-Store'];
function copy(from,to){fs.mkdirSync(path.dirname(to),{recursive:true});fs.copyFileSync(from,to);}
let b=fs.readFileSync(path.join(src('01-Backend-Quality'),'recorder-base.js'));
for(const c of stages){const r=require(path.join(src(c),'patch-backend.cjs')).patch(b);b=Buffer.isBuffer(r)?r:r.buffer;}
for(const n of ['integrate-pass.cjs','integrate-seasons.cjs'])b=require(path.join(src('07-Hunt-Pass-Seasons'),n)).patch(b);
for(const c of ['08-Bounties-Challenges','09-Power-Surge','10-Free-Dyes','12-Gauntlet-Trials'])b=require(path.join(src(c),'patch-backend.cjs')).patch(b);
new vm.Script(b.toString('utf8'));fs.mkdirSync(path.join(out,'backend'),{recursive:true});fs.writeFileSync(path.join(out,'backend/recorder-1147.js'),b);
for(const c of fs.readdirSync(path.join(root,'Patches'))){const dir=src(c);
 for(const f of fs.readdirSync(dir)){
  if(/^(quality|supervisor-1147|game-rules1147|mega1147|middleman1147|trials1147|huntpass1147|huntpass-seasons1147|bounties1147|equipment1147|dyes1147|modes1147)(-data)?\.js(on)?$/.test(f))copy(path.join(dir,f),path.join(out,'backend',f));
  if(f.endsWith('.pak'))copy(path.join(dir,f),path.join(root,'Payload/paks',f));
 }
}
for(const f of ['start.ps1','server-1147.ps1','host-mode1147.ps1'])copy(path.join(src('01-Backend-Quality'),f),path.join(out,'tools',f));
let play=fs.readFileSync(path.join(src('01-Backend-Quality'),'play-1147.ps1'),'utf8'),nl=play.includes('\r\n')?'\r\n':'\n';play=play.replaceAll('\r\n','\n');
const anchor=play.includes('$clientErrTask =')?'$clientErrTask = $p.StandardError.BaseStream.CopyToAsync($clientErrStream)':'$p = [Diagnostics.Process]::Start($psi)';
if(play.split(anchor).length!==2)throw Error('Expected one client-start anchor');play=play.replace(anchor,anchor+"\n& (Join-Path $PSScriptRoot 'bounty-menu1147.ps1') -GameProcessId $p.Id -GameExe $Exe");fs.writeFileSync(path.join(out,'tools/play-1147.ps1'),play.replaceAll('\n',nl));
for(const f of ['items.js','catalog-1147.json'])copy(path.join(src('02-Inventory-Search'),f),path.join(out,'tools',f));
for(const f of ['bounty-menu1147.ps1','menu-repair1147.json'])copy(path.join(src('08-Bounties-Challenges'),f),path.join(out,'tools',f));
copy(path.join(src('03-Game-Rules'),'rules.json'),path.join(out,'rules.json'));
fs.cpSync(path.join(src('07-Hunt-Pass-Seasons'),'seasons'),path.join(out,'seasons'),{recursive:true});
console.log('Built complete backend, helpers, rules, seasons and three PAKs from consolidated sources.');
