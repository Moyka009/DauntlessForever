// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const oldHash='ed1484a68901cfdd5dcbd2ae97d38918baaba6f60a2821ff79e83b0ea3ae9912';
const previousPackHash='4cc3d5c33a6739a6b5e17759065c90cc0b6b48d1a965abeb352ceeffe5502b14';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function upgrade({base,root,dir,receipt,r,write,afterWrite}){
 const target=path.join(root,'backend/dyes1147.js'),source=path.join(base,'Payload/package/backend/dyes1147.js'),t=r.files.find(t=>t.path===target);
 if(!t)throw Error('All-in-one dye installation record is missing');
 const before=fs.readFileSync(target),after=fs.readFileSync(source);
 if(before.equals(after))return false;
 const beforeHash=hash(before);if(![oldHash,previousPackHash].includes(beforeHash)||t.installed!==beforeHash)throw Error('Unsupported dye module upgrade; no files changed');
 const originalReceipt=fs.readFileSync(receipt),pending=path.join(dir,'pending.json');
 const recovery=path.join(dir,'dye-pack-upgrade-v2');
 if(fs.existsSync(recovery))throw Error('Dye upgrade recovery backup already exists; keep it intact');
 fs.mkdirSync(recovery);
 fs.writeFileSync(path.join(recovery,'dyes1147.js'),before,{flag:'wx'});
 fs.writeFileSync(path.join(recovery,'installation.json'),originalReceipt,{flag:'wx'});
 // Preserve the first install's original backups. Restore still returns to the pre-all-in-one setup.
 const updated=JSON.parse(JSON.stringify(r));updated.files.find(t=>t.path===target).installed=hash(after);updated.dye_pack_revision=2;
 fs.writeFileSync(pending,JSON.stringify({operation:'dye-pack-upgrade',target,before:beforeHash,after:hash(after)}),{flag:'wx'});
 try{
  write(target,after);afterWrite?.(0,{path:target,kind:'dye-upgrade'});
  write(receipt,Buffer.from(JSON.stringify(updated,null,2)));afterWrite?.(1,{path:receipt,kind:'receipt-upgrade'});
  fs.unlinkSync(pending);
 }catch(e){write(target,before);write(receipt,originalReceipt);fs.rmSync(pending,{force:true});fs.rmSync(recovery,{recursive:true,force:true});throw e;}
 return true;
}
module.exports={upgrade,oldHash,previousPackHash};
