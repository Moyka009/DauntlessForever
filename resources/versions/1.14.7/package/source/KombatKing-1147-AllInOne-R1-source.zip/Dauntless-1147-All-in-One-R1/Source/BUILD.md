# Consolidated source and testing

Run from the main folder:

```
node Source/build.cjs
python Source/package.py
```

The builder starts from patch 01's merged current official/Quality source, applies the component integration functions, and copies only final runtime modules, settings, seasons, the final 12-point menu helper and three PAKs. The installer writes this complete result in one transaction. It never runs the old individual patch installers or requires their backup records.

The inventory launcher changes are applied at install time to the bundled archive and its active app update, preserving unrelated files/features and the update version. No old prebuilt launcher is substituted for a newer launcher. Its update pointer checksum is changed only to match the modified archive; restore preserves other pointer fields.

Reference tests use `DAUNTLESS_REFERENCE_WORKSPACE` (defaults to the parent of this folder) for the original verified 1.14.7 files, current official package, current native DLLs/PAKs and original launcher. These are not redistributed. `Tests/fixtures.cjs` documents the exact reference layout. Unit/VM/native-helper tests that do not need those inputs run directly. Shared tests:

```
node Tests/install.cjs
node Tests/runtime.cjs
node Tests/test-ui.cjs
node Tests/test-ipc.cjs
```

Component tests are in each relevant Source folder. Native/helper rebuild scripts require their original manifest-verified assets and GNU assembler/repak where used. Rebuild native components first, then run the main builder. Building source is separate from installing the ready-made ZIP.

The original game executable, official native DLLs, SDK, original PAKs, private saves, sign-in files and optional diagnostic recorders are not bundled. Validation records state the exact checks run and distinguish them from Windows/gameplay testing.

Dye pack revision: `node Patches/10-Free-Dyes/Source/test-dyes.cjs` and `node Tests/dye-upgrade.cjs` cover pack redemption and the installed R1 upgrade. The compressed previous module under Tests/fixtures is a regression fixture, never installed.
