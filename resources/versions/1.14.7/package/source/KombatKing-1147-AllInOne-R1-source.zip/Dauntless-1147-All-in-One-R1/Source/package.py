# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import json,hashlib,zipfile,shutil
root=Path(__file__).resolve().parents[1]
for p in list(root.rglob('__pycache__')):shutil.rmtree(p)
for p in root.rglob('*.pyc'):p.unlink()
files=sorted(p for p in root.rglob('*')if p.is_file()and p.name!='Integrity.json')
(root/'Integrity.json').write_text(json.dumps({'files':{str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in files}},indent=2)+'\n')
out=root.with_suffix('.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(root.rglob('*')):
  if p.is_file():z.write(p,str(Path(root.name)/p.relative_to(root)))
with zipfile.ZipFile(out)as z:
 assert z.testzip()is None
 for p in sorted(root.rglob('*')):
  if p.is_file():assert z.read(str(Path(root.name)/p.relative_to(root)))==p.read_bytes()
print(out,'bytes',out.stat().st_size)
