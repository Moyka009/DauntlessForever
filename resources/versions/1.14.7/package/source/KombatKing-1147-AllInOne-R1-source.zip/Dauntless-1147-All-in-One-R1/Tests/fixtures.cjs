// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),{unpack,pack}=require('../Patches/02-Inventory-Search/Source/asar.cjs');
const bundle=path.resolve(__dirname,'..'),work=process.env.DAUNTLESS_REFERENCE_WORKSPACE||path.dirname(bundle),official=path.join(work,'game_rules1147_work/upstream/resources/versions/1.14.7/package');
function link(src,dst){fs.mkdirSync(path.dirname(dst),{recursive:true});fs.linkSync(src,dst);}
function fixture(options={}){
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'aio1147 space ')),root=path.join(tmp,'Local/DauntlessForever/versions/1.14.7'),launcher=path.join(tmp,'Launcher'),game=path.join(tmp,'Game'),env={LOCALAPPDATA:path.join(tmp,'Local')};
 fs.cpSync(official,root,{recursive:true});fs.mkdirSync(path.join(root,'data'),{recursive:true});fs.mkdirSync(path.join(root,'eos'),{recursive:true});fs.writeFileSync(path.join(root,'eos/eos_offline.ini'),'fixture offline sign in');
 fs.cpSync(path.join(work,'uploaded_backend1147/archive2/1.14.7/captures'),path.join(root,'captures'),{recursive:true});
 const meta=JSON.parse(fs.readFileSync(path.join(work,'game_rules1147_work/upstream/resources/versions/1.14.7/version.json')));
 fs.mkdirSync(path.join(launcher,'resources/versions/1.14.7'),{recursive:true});fs.writeFileSync(path.join(launcher,'resources/versions/1.14.7/version.json'),JSON.stringify(meta));
 link(path.join(work,'game_rules1147_work/reference/Archon/Binaries/Win64/Dauntless-Win64-Shipping.exe'),path.join(game,'Archon/Binaries/Win64/Dauntless-Win64-Shipping.exe'));
 for(const n of ['Archon_Player_1-WindowsClient.pak','Archon_25-WindowsClient.pak','Archon_49-WindowsClient.pak'])link(path.join(work,'game_rules1147_work/reference/Archon/Content/Paks',n),path.join(game,'Archon/Content/Paks',n));
 for(const e of meta.package.installedFiles)link(path.join(work,'aio1147_work/native',path.basename(e.rel)),path.join(game,e.rel));
 fs.writeFileSync(path.join(root,'config.json'),JSON.stringify({GameDir:game,Node:process.execPath,keepSetting:'PRESERVE'}));
 const account='A'.repeat(26),character='B'.repeat(26),player={accountId:account,username:'Fixture',characters:[{id:character,name:'Fixture',updateVersion:0,data:null}],inventory:{[character]:{stackedItems:[{catalogId:'CURRENCY_NOTES',quantity:42}],instancedItems:[]}}};
 fs.writeFileSync(path.join(root,'data/state.json'),JSON.stringify({players:{local:player},lastPlayer:'local',hostId:'0123456789abcdef'}));
 fs.writeFileSync(path.join(root,'data/rules.txt'),options.highRules?'rams=25\nweapon_xp=10\nfree_crafting=1\n':'rams=3\nweapon_xp=1\n');
 const a=unpack(fs.readFileSync(path.join(work,'upload/app(3).asar')));
 if(options.currentLauncher)for(const n of ['src/main/main.js','src/renderer/app.js','src/renderer/index.html','src/renderer/styles.css','package.json'])a.files.set(n,fs.readFileSync(path.join(work,'aio1147_work/launcher',n)));
 const original=pack(a.header,a.files);fs.mkdirSync(path.join(launcher,'resources'),{recursive:true});fs.writeFileSync(path.join(launcher,'resources/app.asar'),original);
 if(options.update){const pkg=JSON.parse(a.files.get('package.json'));pkg.version='0.2.99';a.files.set('package.json',Buffer.from(JSON.stringify(pkg)));a.files.set('src/renderer/app.js',Buffer.concat([a.files.get('src/renderer/app.js'),Buffer.from('\n// PRESERVE ACTIVE UPDATE FEATURE\n')]));const bytes=pack(a.header,a.files),dir=path.join(tmp,'Local/DauntlessForever/app-update/0.2.99');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'app.asar'),bytes);fs.writeFileSync(path.join(path.dirname(dir),'current.json'),JSON.stringify({version:'0.2.99',minShell:'0.2.4',sha256:require('crypto').createHash('sha256').update(bytes).digest('hex'),tries:0,good:true,preserveFlag:123}));}
 return{tmp,root,launcher,game,env,account,character,player,clean:()=>fs.rmSync(tmp,{recursive:true,force:true})};
}
module.exports={fixture,work,bundle,official,link};
