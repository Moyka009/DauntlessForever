# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import json,subprocess,hashlib,ast
r=Path(__file__).resolve().parents[1]
assert sorted(p.name for p in r.glob('*.cmd'))==['Check-Installed.cmd','Install.cmd','Restore.cmd']
assert not list((r/'Patches').rglob('*.cmd'))
cs=[p for p in (r/'Patches').iterdir()if p.is_dir()];assert len(cs)==12
for p in cs:assert (p/'PATCH-NOTES.md').is_file()and(p/'LICENSE-AGPL-3.0.txt').is_file()and(p/'Source').is_dir()
for f in r.rglob('*'):
 if not f.is_file():continue
 assert f.name not in ['Collect-Launcher-State.cmd','Collect-Launcher-State.ps1']
 if f.suffix in ['.js','.cjs']:subprocess.run(['node','--check',str(f)],check=True,capture_output=True)
 if f.suffix=='.py':ast.parse(f.read_text('utf-8'),filename=str(f))
 if f.suffix in ['.py','.js','.cjs','.ps1','.json','.md','.txt','.cmd','.s']:
  t=f.read_text('utf-8');assert not any(ord(c)<32 and c not in '\n\r\t'for c in t),str(f)
for name,action in [('Install.cmd','install'),('Check-Installed.cmd','check'),('Restore.cmd','restore')]:
 b=(r/name).read_bytes();assert b'\n'not in b.replace(b'\r\n',b'');assert ('-File "%~dp0Run.ps1" -Action '+action).encode()in b
spec=json.loads((r/'Payload/package/tools/menu-repair1147.json').read_text());assert len(spec['patches'])==12
assert len(list((r/'Payload/paks').glob('*.pak')))==3
assert (r/'Payload/package/backend/modes1147.js').exists()
assert (r/'Payload/package/backend/quality.js').exists()
play=(r/'Payload/package/tools/play-1147.ps1').read_text();assert play.count("& (Join-Path $PSScriptRoot 'bounty-menu1147.ps1') -GameProcessId $p.Id -GameExe $Exe")==1
start=(r/'Payload/package/tools/start.ps1').read_text();assert 'host-mode1147.ps1'in start and 'supervisor-1147.js'in start
for f in r.rglob('*'):
 if f.is_file() and f.name!='Integrity.json':
  if f.suffix in ['.js','.cjs','.ps1','.py']:assert '\n<<<<<<< 'not in f.read_text('utf-8'),str(f)
print(json.dumps({'passed':1,'failed':0,'checks':'12 source/license/notes folders; one install button; final helper/PAKs; Node/Python syntax; CMD paths/CRLF; UTF-8/control chars; no recorder buttons or merge conflicts','PowerShell_Windows':'not executed'}))
