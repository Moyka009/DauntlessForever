# Dauntless 1.14.7 All-in-One R1

One installer for the current official 1.14.7 package, with no previous community backend or individual patch installation required.

| Folder | Included patch |
| --- | --- |
| [01-Backend-Quality](Patches/01-Backend-Quality/PATCH-NOTES.md) | Backend and save protection |
| [02-Inventory-Search](Patches/02-Inventory-Search/PATCH-NOTES.md) | Inventory and name/ID search |
| [03-Game-Rules](Patches/03-Game-Rules/PATCH-NOTES.md) | Game Rules up to 5x |
| [04-Fountain-Supplies](Patches/04-Fountain-Supplies/PATCH-NOTES.md) | Fountain and store supplies |
| [05-Middleman](Patches/05-Middleman/PATCH-NOTES.md) | Middleman slots and fusion |
| [06-Trials-Store](Patches/06-Trials-Store/PATCH-NOTES.md) | Trials store ownership |
| [07-Hunt-Pass-Seasons](Patches/07-Hunt-Pass-Seasons/PATCH-NOTES.md) | Hunt Pass seasons and Mega pass |
| [08-Bounties-Challenges](Patches/08-Bounties-Challenges/PATCH-NOTES.md) | Bounties, Challenges and menu freezes |
| [09-Power-Surge](Patches/09-Power-Surge/PATCH-NOTES.md) | Power surge saving |
| [10-Free-Dyes](Patches/10-Free-Dyes/PATCH-NOTES.md) | One free All Dyes pack |
| [11-Hammer-Reload](Patches/11-Hammer-Reload/PATCH-NOTES.md) | Hammer failed reload |
| [12-Gauntlet-Trials](Patches/12-Gauntlet-Trials/PATCH-NOTES.md) | Gauntlet access and Trials launches |

Each folder contains final source, its own patch notes and an AGPL-3.0 license. Later fixes are folded into their parent patch.

**Gameplay status:** Fountain/shop, Middleman, Trials store, Hunt Pass/seasons, inventory search, power surge, Challenges/menu freezes and hammer reload were confirmed in the prior individual patches. The combined installer/backend still needs a Windows launch check. Free dyes and some Game Rules paths need gameplay checks. Bounty claim timing/Ramsgate claiming remain pending. Patch 12 is included with its stated missing reward/guild features and pending gameplay test.

**Left out:** Bounty Freeze Sampler, Bounty Transition Trace, diagnostic collection buttons, old standalone installers, replaced PAK/helper revisions and failed offer/search implementations. Normal operational backend/helper logs remain; these are not the optional diagnostic recorders.

**Preserved:** Player saves, configured game path, sign-in data, existing item menu, active season choice, launcher update version/preferences, installed official native DLLs/PAKs, and the 1.6.2 installation. Rule choices above 5 are the one settings migration.

**Target checked:** Dauntless 1.14.7 CL647472; official server package 2026-10-17.12. Manifest SHA1: `aa70748e4c0a776a991f2bac10ad342adaa31476`.

Dye pack update: individual dye offers are replaced by one free All Dyes pack. Existing all-in-one users run the same main Install.cmd to update; saves, existing dyes, and original restore backups are preserved.

1.14.7 dye pack revision 2 also removes original captured dye listings; there is one All Dyes Pack for all 475 verified dyes. Existing original/first-pack installs update through the main Install.cmd.
