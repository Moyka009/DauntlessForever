// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const crypto=require('crypto'),fs=require('fs'),path=require('path');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function once(source,from,to){if(source.split(from).length!==2)throw Error('Expected one inspected backend match: '+from.slice(0,90));return source.replace(from,to);}
function patch(buffer){
 const allowed=JSON.parse(fs.readFileSync(path.join(__dirname,'supported-backends.json'),'utf8'));
 const found=allowed.find(x=>x.sha256===hash(buffer));if(!found)throw Error('Unknown backend SHA256. Preserve this package for comparison before installing Game Rules.');
 let s=buffer.toString('utf8');const newline=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 const root=s.match(/^const ROOT = .+;$/m);if(!root)throw Error('Backend root declaration missing');
 s=once(s,root[0],root[0]+"\n// Game Rules 1.14.7: isolated settings and catalog-verified transformations.\nconst gameRules = require('./game-rules1147').create(ROOT);");
 s=once(s,'function applyInventory(inv, body) {','function applyInventory(inv, body) {\n  body = gameRules.inventory(inv, body);');
 s=once(s,"const p = playerFor(c.req); const pr = progressOf(p); const b = c.body && typeof c.body === 'object' ? c.body : {};",
 "const p = playerFor(c.req); const pr = clone(progressOf(p)); const b = gameRules.progress(c.body && typeof c.body === 'object' ? c.body : {});");
 s=once(s,'cur.progress = (Number(cur.progress) || 0) + (Number(t.progress) || 0); tracks.push(trackOut(p, t.progression_id, cur));',
 'cur.progress = gameRules.sumTrack(t.progression_id, cur.progress, Number(t.progress) || 0); tracks.push(trackOut(p, t.progression_id, cur));');
 s=once(s,'  saveState();\n  return J(wrapped({ progress_tracks: tracks, objectives }),',
 '  p.progress = pr; saveState();\n  return J(wrapped({ progress_tracks: tracks, objectives }),');
 s=once(s,'cur.progress = (Number(cur.progress) || 0) + (Number(c.match[2]) || 0); saveState();',
 'cur.progress = gameRules.sumTrack(id, cur.progress, gameRules.track(id, Number(c.match[2]) || 0)); saveState();');
 // Quality Fix2 already owns replay protection and copy-on-write inventory.
 // Stock versions receive the same bounded receipt format without replacing quality code.
 if(!s.includes('const history=p.inventoryTransactions||[];')){
  s=once(s,'    const result = applyInventory(inventoryOf(p, b.characterId), b); saveState();\n    return J(result);',
  '    const before = clone(p);\n    try {\n      const result = gameRules.transact(p, b, inventoryOf(p, b.characterId), applyInventory); saveState();\n      return J(result);\n    } catch (error) { for (const k of Object.keys(p)) delete p[k]; Object.assign(p, before); throw error; }');
 }
 return {buffer:Buffer.from(s.replaceAll('\n',newline)),baseline:found};
}
module.exports={patch,hash};
