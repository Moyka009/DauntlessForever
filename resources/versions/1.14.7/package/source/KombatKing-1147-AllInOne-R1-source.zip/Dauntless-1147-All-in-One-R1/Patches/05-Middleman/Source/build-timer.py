# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import struct,hashlib,json,shutil,sys
from equipment_asset import Asset
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()=='93a1914c345e174eef4284ee4022033916798f326951c8582900e19ffd3d1dee', 'Not the verified 1.14.7 table'
assert hashlib.sha256(source.with_suffix('.uexp').read_bytes()).hexdigest()=='7cc6f39379807321ad3a576036a420d5c4597c9fb7a5a3754324947126c5a357', 'Not the verified 1.14.7 table payload'
a=Asset(source);b=bytearray(a.b);e=a.exports[0];pos,_=a.properties(e['start']);assert struct.unpack_from('<I',a.b,pos)[0]==0;pos+=4
count=struct.unpack_from('<I',a.b,pos)[0];pos+=4;rows=[]
for _ in range(count):
 row,pos=a.name(pos)
 while True:
  tag=a.tag(pos);pos=tag['end']
  if tag['name']=='None':break
  if tag['name']=='TimeRequired':
   assert tag['type']=='StructProperty' and tag['struct']=='Timespan' and tag['size']==8
   ticks=struct.unpack_from('<q',a.b,tag['start'])[0];new=min(ticks,420*10000000);assert new>=0
   struct.pack_into('<q',b,tag['start'],new);rows.append({'row':row,'offset':tag['start'],'old_seconds':ticks/10000000,'new_seconds':new/10000000})
assert len(rows)==3 and pos==e['start']+e['size'];assert len(a.b)==len(b)
allowed={x['offset']+i for x in rows for i in range(8)};assert all(i in allowed for i,(x,y) in enumerate(zip(a.b,b)) if x!=y)
shutil.copyfile(source,out/source.name);(out/source.with_suffix('.uexp').name).write_bytes(b)
print(json.dumps({'source_uasset_sha256':hashlib.sha256(a.ua).hexdigest(),'source_uexp_sha256':hashlib.sha256(a.b).hexdigest(),'patched_uexp_sha256':hashlib.sha256(b).hexdigest(),'rows':rows},indent=2))
