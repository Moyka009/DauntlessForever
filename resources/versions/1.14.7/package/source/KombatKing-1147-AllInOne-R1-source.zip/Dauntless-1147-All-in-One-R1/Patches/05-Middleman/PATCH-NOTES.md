# Middleman slots and fusion

Left/right slot purchases grant the correct saved unlock tokens. Fusion uses the correct slot state and the timer is capped at seven minutes. Existing fusions are shortened when processed by the final module.

Consolidates the final purchase/save fix with the seven-minute timer PAK. Removes the need to install either older Middleman ZIP.

**Validation and limits:** Slot purchase and fusion were confirmed working. Backend purchase/slot tests and manifest-verified timer changes are included.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
