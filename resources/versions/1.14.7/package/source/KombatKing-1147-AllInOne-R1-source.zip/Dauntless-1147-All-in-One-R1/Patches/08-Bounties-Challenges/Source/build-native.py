from pathlib import Path
import json,struct,hashlib,subprocess,tempfile,os
root=Path(__file__).resolve().parents[1];exe=Path(os.environ.get('DAUNTLESS_REFERENCE_WORKSPACE',str(root.parents[2])))/'game_rules1147_work/reference/Archon/Binaries/Win64/Dauntless-Win64-Shipping.exe';b=exe.read_bytes()
assert hashlib.sha256(b).hexdigest()=='f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b'
# Each displaced sequence ends on an instruction boundary and contains no RIP-relative instruction.
rows=[('panel_refresh',0x1fd0880,11),('journal_cta',0x1feb8d0,5),('selection_assets',0x1fe4f90,5),('selection_draft',0x1fe5f80,10),('panel_assets',0x1fe5320,5),('draft_timeout',0x1fe6330,5),('huntpass_progress',0x1fa91a0,10),('objective_legend',0x1fec6b0,5)]
s='''.intel_syntax noprefix
.text
.global closed,cleanup,compact
# Returns AL=1 only for a widget owned by a destructed ArchonScreen.
closed:
 mov r10,rcx
 mov edx,64
 mov rax,QWORD PTR [rip+screen_class]
 mov rax,QWORD PTR [rax]
 test rax,rax
 jz open
outer_loop:
 test r10,r10
 jz open
 mov r11,QWORD PTR [r10+0x10]
 mov r8d,64
class_loop:
 test r11,r11
 jz next_outer
 cmp r11,rax
 je found_screen
 mov r11,QWORD PTR [r11+0x40]
 dec r8d
 jnz class_loop
 jmp open
next_outer:
 mov r10,QWORD PTR [r10+0x20]
 dec edx
 jnz outer_loop
open:
 xor eax,eax
 ret
found_screen:
 movzx eax,BYTE PTR [r10+0x3d0]
 ret

# Called in place of JournalScreen's call to its base NativeDestruct.
# Preserve the base call and then remove closed-screen bindings from normal bounties.
cleanup:
 push rbx
 push rsi
 push rdi
 sub rsp,32
 mov rbx,rcx
 call QWORD PTR [rip+base_destruct]
 lea rcx,[rbx+0x530]
 call QWORD PTR [rip+weak_get]
 test rax,rax
 jz cleanup_end
 mov rsi,rax
 mov edi,0xe0
cleanup_next:
 lea rcx,[rsi+rdi]
 mov rdx,rbx
 call compact
 add edi,16
 cmp edi,0x160
 jb cleanup_next
 lea rcx,[rsi+0x1f0]
 mov rdx,rbx
 call compact
 lea rcx,[rsi+0x200]
 mov rdx,rbx
 call compact
cleanup_end:
 add rsp,32
 pop rdi
 pop rsi
 pop rbx
 ret

# Stable compact FScriptDelegate[16]. Retain capacity and other screens' bindings.
# RCX=&invocation array, RDX=closed screen. No allocations and no delegate broadcasts.
compact:
 push rbx
 push rsi
 push rdi
 push r12
 push r13
 push r14
 push r15
 sub rsp,32
 mov rbx,rcx
 mov r12,rdx
 mov rsi,QWORD PTR [rcx]
 mov r13d,DWORD PTR [rcx+8]
 test rsi,rsi
 jz compact_end
 test r13d,r13d
 jle compact_end
 cmp r13d,4096
 ja compact_end
 cmp r13d,DWORD PTR [rcx+12]
 ja compact_end
 xor edi,edi
 xor r14d,r14d
compact_next:
 mov r15d,edi
 shl r15,4
 lea rcx,[rsi+r15]
 call QWORD PTR [rip+weak_get]
 test rax,rax
 jz compact_drop
 mov ecx,64
compact_outer:
 cmp rax,r12
 je compact_drop
 mov rax,QWORD PTR [rax+0x20]
 test rax,rax
 jz compact_keep
 dec ecx
 jnz compact_outer
compact_keep:
 mov rax,QWORD PTR [rsi+r15]
 mov rdx,QWORD PTR [rsi+r15+8]
 mov r10d,r14d
 shl r10,4
 mov QWORD PTR [rsi+r10],rax
 mov QWORD PTR [rsi+r10+8],rdx
 inc r14d
compact_drop:
 inc edi
 cmp edi,r13d
 jb compact_next
 mov DWORD PTR [rbx+8],r14d
compact_end:
 add rsp,32
 pop r15
 pop r14
 pop r13
 pop r12
 pop rdi
 pop rsi
 pop rbx
 ret
'''
s+='''
.global background_fallback
background_fallback:
 cmp QWORD PTR [rsi+0x10],0
 je missing_background
 push rax
 mov rax,QWORD PTR [rip+log_verbosity]
 cmp BYTE PTR [rax],bpl
 pop rax
 jmp QWORD PTR [rip+background_continue]
missing_background:
 jmp QWORD PTR [rip+background_skip]
'''
s+=(root/'Source/season-cache.s').read_text()
s+=(root/'Source/menu-week-count.s').read_text()
fix={'total_week_count':0x1a04f60,'season_body':0x1a0bf95,'log_verbosity':0x6d286d0,'background_continue':0x1fa947a,'background_skip':0x1fa95f2,'screen_class':0x6d625b8,'base_destruct':0x1e4c030,'weak_get':0x287aa20}
for name,rva,n in rows:
 old=b[rva-0xa00:rva-0xa00+n]
 s+=f'''\n.global {name}\n{name}:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz {name}_closed
 .byte {','.join(hex(c) for c in old)}
 jmp QWORD PTR [rip+{name}_return]
{name}_closed:
 ret
'''
 fix[name+'_return']=rva+n
s+='\n.balign 8\n'
for name in fix:s+=f'.global {name}\n{name}: .quad 0\n'
s+='\n.org 4096\n.global season_cache\nseason_cache: .zero 128\n'
(root/'Source/menu-repair.s').write_text(s)
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);subprocess.run(['as','--64',str(root/'Source/menu-repair.s'),'-o',str(p/'code.o')],check=True);subprocess.run(['ld','-Ttext=0','-e','closed',str(p/'code.o'),'-o',str(p/'code.elf')],check=True);subprocess.run(['objcopy','-O','binary','--only-section=.text',str(p/'code.elf'),str(p/'code.bin')],check=True)
 syms={line.split()[2]:int(line.split()[0],16) for line in subprocess.check_output(['nm','-n',str(p/'code.elf')],text=True).splitlines() if len(line.split())==3};code=(p/'code.bin').read_bytes()
assert len(code)==4224
patches=[{'name':name,'rva':rva,'before':b[rva-0xa00:rva-0xa00+n].hex(),'target_offset':syms[name],'op':0xe9}for name,rva,n in rows]
assert b[0x1fe02da-0xa00:0x1fe02df-0xa00].hex()=='e851bde6ff'
patches.append({'name':'journal_close_cleanup','rva':0x1fe02da,'before':'e851bde6ff','target_offset':syms['cleanup'],'op':0xe8})
patches.append({'name':'bounded_menu_week_placeholders','rva':0x1fcf7d2,'before':'e88957a3ff','target_offset':syms['menu_week_count'],'op':0xe8})
assert b[0x1fcf7d2-0xa00:0x1fcf7d7-0xa00].hex()=='e88957a3ff'
patches.append({'name':'weekly_season_dates_cache','rva':0x1a0bf90,'before':b[0x1a0bf90-0xa00:0x1a0bf95-0xa00].hex(),'target_offset':syms['season_dates'],'op':0xe9})
# Invalid background asset branch: skip the invalid SetBrushFromSoftTexture call,
# retain the existing brush ONLY for an empty asset path; keep pending asset loads.
rva=0x1fa9473;before=b[rva-0xa00:rva-0xa00+7];assert before.hex()=='40382d56f2d704'
patches.append({'name':'invalid_progress_background_fallback','rva':rva,'before':before.hex(),'target_offset':syms['background_fallback'],'op':0xe9})
spec={'game':'1.14.7 CL647472','source_sha256':hashlib.sha256(b).hexdigest(),'code':code.hex(),'symbols':syms,'fixups':[{'offset':syms[k],'rva':v} for k,v in fix.items()],'patches':patches}
(root/'Source/menu-repair1147.json').write_text(json.dumps(spec,indent=2)+'\n')
print('Generated',len(code),'bytes;',len(patches),'repair points')
