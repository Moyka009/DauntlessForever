// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),assert=require('assert/strict'),net=require('net');
const {spawnSync}=require('child_process');
const base=path.resolve(__dirname,'..'),payload=__dirname;
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const original=process.env.INVENTORY_ORIGINAL_HELPER;
const r1root=process.env.INVENTORY_R1_DIR;
const source=process.env.INVENTORY_PACKAGE_REFERENCE;
const quality=process.env.INVENTORY_QUALITY_REFERENCE;
const id='A'.repeat(26),friend='B'.repeat(26),epic='1'.repeat(32),key=hash('epic:'+epic).slice(0,32);
const player=id=>({characters:[{id,name:'Fixture'}],inventory:{[id]:{stackedItems:[],instancedItems:[]}},loadouts:{}});
const initial=()=>({hostId:'KEEP',players:{[key]:player(id),friend:player(friend)},progress:{untouched:42}});
const tests=[];let passed=0,skipped=0;
const test=(name,fn)=>tests.push([name,fn]);
const tmp=[];
function fixture(patched=true){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'inv-r2-'));tmp.push(root);
 for(const d of ['tools','data','eos','bin','backend'])fs.mkdirSync(path.join(root,d));
 fs.writeFileSync(path.join(root,'version.json'),JSON.stringify({id:'1.14.7',package:{installedFiles:[{path:'bin/dxgi.dll',hash:'unchanged'}]}}));
 fs.writeFileSync(path.join(root,'items.json'),'\uFEFF{ "groups": [{"title":"MY EXISTING LIST","items":[{"id":"CURRENCY_NOTES","name":"Rams"}]}] }\n');
 fs.writeFileSync(path.join(root,'data/state.json'),JSON.stringify(initial()));
 fs.writeFileSync(path.join(root,'eos/eos_offline.ini'),'EpicAccountId='+epic);
 fs.writeFileSync(path.join(root,'config.json'),'{}');
 if(source)for(const n of ['backend/recorder-1147.js','tools/common.ps1','tools/setup.ps1','tools/start.ps1','bin/dxgi.dll'])if(fs.existsSync(path.join(source,n)))fs.copyFileSync(path.join(source,n),path.join(root,n));
 if(quality)for(const n of ['backend/recorder-1147.js','backend/quality.js','backend/supervisor-1147.js','tools/start.ps1','tools/server-1147.ps1'])if(fs.existsSync(path.join(quality,n)))fs.copyFileSync(path.join(quality,n),path.join(root,n));
 if(patched)for(const n of ['items.js','catalog-1147.json'])fs.copyFileSync(path.join(payload,n),path.join(root,'tools',n));
 else {if(!original)throw Error('INVENTORY_ORIGINAL_HELPER required for installer tests');fs.copyFileSync(original,path.join(root,'tools/items.js'));}
 return root;
}
const state=r=>JSON.parse(fs.readFileSync(path.join(r,'data/state.json')));
const put=(r,s)=>fs.writeFileSync(path.join(r,'data/state.json'),JSON.stringify(s));
const inv=r=>state(r).players[key].inventory[id];
function run(r,cmd,who=id,input){const a=[path.join(r,'tools/items.js'),cmd,who];if(input!==undefined)a.push(typeof input==='string'?input:JSON.stringify(input));const x=spawnSync(process.execPath,a,{encoding:'utf8'});assert.equal(x.status,0,x.stderr);return JSON.parse(x.stdout);}
const cat=JSON.parse(fs.readFileSync(path.join(payload,'catalog-1147.json'))).items;
const dye=cat.find(x=>x.cosmetic&&x.storage==='stack'),accessory=cat.find(x=>x.cosmetic&&x.storage==='instance');
function protectedHashes(r){const out={};for(const n of ['items.json','version.json','config.json','data/state.json','tools/common.ps1','tools/setup.ps1','tools/start.ps1','tools/server-1147.ps1','bin/dxgi.dll','backend/recorder-1147.js','backend/quality.js','backend/supervisor-1147.js'])if(fs.existsSync(path.join(r,n)))out[n]=hash(fs.readFileSync(path.join(r,n)));return out;}
test('List keeps original interface, offers no full catalog or new controls, grants nothing',()=>{
 const r=fixture(),before=fs.readFileSync(path.join(r,'data/state.json')),v=run(r,'list');
 assert.deepEqual(Object.keys(v).sort(),['characters','ok']);assert.deepEqual(v.characters,[{id,name:'Fixture',items:{}}]);
 assert(fs.readFileSync(path.join(r,'data/state.json')).equals(before));
});
test('Only selected resources, equipment, lantern and cosmetic storage types are changed',()=>{
 const r=fixture();assert(run(r,'set',id,{CURRENCY_NOTES:4321,WP_EB_BEAVER:8,LT_BASIC:1,[dye.id]:3,[accessory.id]:4}).ok);
 assert(inv(r).stackedItems.some(x=>x.catalogId==='CURRENCY_NOTES'&&x.quantity===4321));
 assert(inv(r).stackedItems.some(x=>x.catalogId===dye.id&&x.quantity===1));
 assert.deepEqual(inv(r).instancedItems.map(x=>x.catalogId).sort(),['WP_EB_BEAVER','LT_BASIC',accessory.id].sort());
 assert.equal(inv(r).stackedItems.length,2);assert.deepEqual(state(r).players.friend,initial().players.friend);
});
test('Existing instances retain upgrades, cells, parts and IDs on repeated set',()=>{
 const r=fixture();run(r,'set',id,{WP_EB_BEAVER:1});let s=state(r);s.players[key].inventory[id].instancedItems[0].itemData=JSON.stringify({CurrentLevel:15,EquippedCells:['KEEP_CELL'],EquippedWeaponParts:['KEEP_PART']});put(r,s);
 const before=inv(r).instancedItems;assert(run(r,'set',id,{WP_EB_BEAVER:99}).ok);assert.deepEqual(inv(r).instancedItems,before);
});
test('Unsupported bulk/gear commands are rejected without save changes',()=>{
 const r=fixture(),before=fs.readFileSync(path.join(r,'data/state.json'));
 for(const cmd of ['addcosmetic','addgear','removegear'])assert.equal(run(r,cmd,id,'all').ok,false);
 assert(fs.readFileSync(path.join(r,'data/state.json')).equals(before));
});
test('Unknown IDs and invalid quantities reject entire batch',()=>{
 const r=fixture(),before=fs.readFileSync(path.join(r,'data/state.json'));
 for(const input of [{CURRENCY_NOTES:10,FAKE_ID:1},{CURRENCY_NOTES:-1},{CURRENCY_NOTES:1.5},{CURRENCY_NOTES:'3'},{CURRENCY_NOTES:100000000}])assert.equal(run(r,'set',id,input).ok,false);
 assert(fs.readFileSync(path.join(r,'data/state.json')).equals(before));
});
test('Ownership, wildcard isolation and ambiguous account refusal',()=>{
 const r=fixture();assert.equal(run(r,'set',friend,{CURRENCY_NOTES:1}).ok,false);assert(run(r,'set','*',{CURRENCY_NOTES:3}).ok);assert.deepEqual(state(r).players.friend,initial().players.friend);
 fs.unlinkSync(path.join(r,'eos/eos_offline.ini'));const before=fs.readFileSync(path.join(r,'data/state.json'));assert.equal(run(r,'set','*',{CURRENCY_NOTES:4}).ok,false);assert(fs.readFileSync(path.join(r,'data/state.json')).equals(before));
});
test('Equipped gear deletion is refused; owned gear lists without expanding choices',()=>{
 const r=fixture();run(r,'set',id,{WP_EB_BEAVER:1});const s=state(r),item=s.players[key].inventory[id].instancedItems[0];s.players[key].loadouts[id]={weapon:{instance_id:item.instanceId}};put(r,s);
 assert.equal(run(r,'set',id,{WP_EB_BEAVER:0}).ok,false);assert.equal(run(r,'list').characters[0].items.WP_EB_BEAVER,1);
});
test('Repair changes only existing wrong-list entries and preserves stateful entries',()=>{
 const r=fixture(),s=state(r);s.players[key].inventory[id]={stackedItems:[{catalogId:'WP_EB_BEAVER',quantity:5}],instancedItems:[{catalogId:dye.id,instanceId:'dye'}]};put(r,s);
 assert.equal(run(r,'repair','*').repaired.length,2);assert.equal(inv(r).instancedItems.length,1);assert.equal(inv(r).stackedItems.length,1);
 const a=state(r);a.players[key].inventory[id].instancedItems.push({catalogId:dye.id,instanceId:'keep',itemData:'{"custom":1}'});put(r,a);assert.deepEqual(run(r,'repair','*').skipped,[dye.id]);
});
test('Every actual edit has exact prior-save backup; no-op set creates no backup',()=>{
 const r=fixture(),before=fs.readFileSync(path.join(r,'data/state.json')),v=run(r,'set',id,{CURRENCY_NOTES:345});assert(fs.readFileSync(v.backup).equals(before));assert.equal(run(r,'set',id,{CURRENCY_NOTES:345}).backup,undefined);
});

(async()=>{try{for(const[n,f]of tests){await f();passed++;console.log('PASS '+n);}console.log(JSON.stringify({passed,failed:0}));}finally{for(const r of tmp)fs.rmSync(r,{recursive:true,force:true});}})().catch(e=>{console.error(e);process.exitCode=1;});
