from pathlib import Path
import json,struct,os
from equipment_asset import Asset
from blueprint_script import Script
root=Path(__file__).resolve().parents[1];a=Asset(root/'Source/pak/Archon/Content/Character/Player/blueprints/reload_ammo_hammer_bpn.uasset');s=Script(a,a.exports[0]);s.read();nodes={n['mem']:n for n in s.nodes};checks=0
assert s.m==struct.unpack_from('<I',a.b,s.start-8)[0]==623
for n in s.nodes:
 if n['op']in ['0x6','0x7','0x4c','0x5b']:assert n['v']in nodes,(n['mem'],n['v']);checks+=1
for n in s.nodes:
 if n['op']=='0x19':assert n['v'][0]==n['children'][1]['memend']-n['children'][1]['mem'];checks+=1
# Execute the added branch and original full-refill branch from decoded bytecode.
# Game-owned ammo functions are recorded rather than replaced in the payload.
def run(failed,normal_scale):
 calls=[];pc=424
 def value(n):
  if n['op']=='0x1'and n['v'].endswith(':FastReloadFailure'):return failed
  if n['op']=='0x1'and n['v'].endswith(':NormalAmmoScale'):return normal_scale
  if n['op']=='0x26':return 1
  if n['op']=='0x28':return False
  if n['op']=='0x0':return object()
  if n['op']=='0x19':return value(n['children'][1])
  if n['op']=='0x45':
   calls.append((n['v'],[value(c)for c in n['children'][:-1]]));return None
  raise AssertionError(n)
 for _ in range(8):
  n=nodes[pc]
  if n['op']=='0x7':pc=n['v']if not value(n['children'][0])else n['memend']
  elif n['op']=='0x6':pc=n['v']
  elif n['op']=='0x19':value(n);pc=n['memend']
  elif n['op']=='0x4d':return calls
  else:raise AssertionError(n)
 raise AssertionError('Control-flow did not finish')
for scale in [0.5,1.0,1.75,2.0]:
 assert run(True,scale)==[('AuthReloadNumAmmo',[1,scale])];checks+=1
 assert run(False,scale)==[('AuthReloadWeaponWithAmmoScale',[scale,False])];checks+=1
# Prove that branch landing positions, class properties, and original guard remain.
original=Asset(Path(os.environ.get('DAUNTLESS_REFERENCE_WORKSPACE',str(root.parents[2])))/'game_rules1147_work/hammer-reference/Archon/Content/Character/Player/blueprints/reload_ammo_hammer_bpn.uasset');old=Script(original,original.exports[0]);old.read()
prefix=bytearray(a.b[s.start:1246])
for n in old.nodes:
 if n['offset']<1246 and n['op']in ['0x6','0x7','0x4c','0x5b']and n['v']>424:struct.pack_into('<I',prefix,n['offset']+1-old.start,n['v'])
assert bytes(prefix)==original.b[old.start:1246];checks+=1
assert nodes[424]['children'][0]['v']=='reload_ammo_hammer_bpn_C:FastReloadFailure';checks+=1
assert [(e['name'],e['class_index'],e['outer_index'])for e in a.exports]==[(e['name'],e['class_index'],e['outer_index'])for e in original.exports];checks+=1
for old_e,new_e in zip(original.exports[1:],a.exports[1:]):assert original.b[old_e['start']:old_e['start']+old_e['size']]==a.b[new_e['start']:new_e['start']+new_e['size']];checks+=1
print(json.dumps({'passed':checks,'failed':0,'checks':'complete bytecode parse; all absolute branches and Context lengths; actual added branch selects one-cell grant only for failures; unchanged prefix and other exports','gameplay':'not executed'}))
# Run the ORIGINAL ammo function's real count-update bytecode up to SetAmmo.
# This checks the capacity clamp without writing to the shared ammo Blueprint.
ammo=Asset(next((Path(os.environ.get('DAUNTLESS_REFERENCE_WORKSPACE',str(root.parents[2])))/'game_rules1147_work/hammer-reference').rglob('ammo_bpc.uasset')));ars=Script(ammo,next(e for e in ammo.exports if e['name']=='AuthReloadNumAmmo'));ars.read();amap={n['mem']:n for n in ars.nodes}
def count_grant(current,capacity,server=True):
 values={'AuthReloadNumAmmo:AmmoToReload':1};count=current;changed=[];flow=[];pc=0
 def val(n):
  nonlocal count
  op=n['op']
  if op in ['0x0','0x48']:return values.get(n['v'],False)
  if op=='0x1':assert n['v'].endswith(':MaxAmmoCount');return capacity
  if op=='0x17':return 'self'
  if op in ['0x25','0x28','0xb']:return 0
  if op in ['0x26','0x27']:return 1
  if op=='0x1d':return n['v']
  if op in ['0x14','0xf']:
   lhs,rhs=n['children'];values[lhs['v']]=val(rhs);return values[lhs['v']]
  if op in ['0x68','0x1c']:
   name=n['v'].split('.')[-1];args=[val(c)for c in n['children'][:-1]]
   if name=='IsServer':return server
   if name=='GetCurrentAmmoCount':return count
   if name=='Add_IntInt':return args[0]+args[1]
   if name=='Min':return min(args)
   if name=='SetAmmo':count=args[0];changed.append(count);return None
   raise AssertionError(name)
  raise AssertionError(op)
 for _ in range(30):
  n=amap[pc];op=n['op']
  if op=='0x4c':flow.append(n['v']);pc=n['memend']
  elif op=='0x4f':pc=n['memend']if val(n['children'][0])else flow.pop()
  elif op=='0x7':pc=n['memend']if val(n['children'][0])else n['v']
  elif op=='0x6':pc=n['v']
  elif op=='0x4d':
   if not flow:return changed
   pc=flow.pop()
  else:val(n);pc=n['memend']
  if changed:return changed
 raise AssertionError('Ammo prefix did not reach SetAmmo')
for capacity in [1,4,6,7]:
 for current in range(capacity+1):assert count_grant(current,capacity)==[min(current+1,capacity)];checks+=1
print(json.dumps({'total_passed':checks,'failed':0,'extra':'executed original native-count Blueprint prefix for empty, partial and full clips at capacities 1,4,6,7'}))
