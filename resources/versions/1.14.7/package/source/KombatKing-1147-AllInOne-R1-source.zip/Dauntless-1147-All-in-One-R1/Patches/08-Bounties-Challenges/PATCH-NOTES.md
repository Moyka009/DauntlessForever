# Bounties, Challenges and menu freezes

Incremental normal/daily/weekly updates preserve other slots. Claimed/deleted bounties use saved tombstones to prevent stale reappearance. Includes all 12 final native UI repair points: closed-widget guards, delegate cleanup, empty-background fallback, cached weekly dates and a 52-week cap on empty UI placeholders.

Combines Bounties Fix2, Menu Repair, Timer Fix and the final Menu Size Fix into one source/runtime component. Keeps permanent Hunt Pass dates and leaves holiday/Trials schedules intact. Removes the need for the earlier layered installers.

**Validation and limits:** User confirmed stable loaded bounties, working Challenges and removal of repeated/open/close freezes. Native CPU tests validate the helper. Claim timing and claiming from Ramsgate still need the deferred gameplay test; backend claim/removal/restart tests pass.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
