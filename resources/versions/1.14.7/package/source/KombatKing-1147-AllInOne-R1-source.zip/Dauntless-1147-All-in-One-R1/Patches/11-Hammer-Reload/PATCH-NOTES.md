# Hammer failed reload

A failed active reload adds one ammo cell, up to the clip limit. Normal reload behavior is preserved. The patch replaces only the hammer failure notification Blueprint; successful reload and war pike assets are not replaced.

Uses the final manifest-verified Hammer Reload PAK and its Blueprint source/build scripts. No game executable or shared ammo Blueprint is replaced.

**Validation and limits:** User confirmed hammer works. The PAK rebuilds byte-for-byte from source; bytecode branch/ammo-cap tests pass.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
