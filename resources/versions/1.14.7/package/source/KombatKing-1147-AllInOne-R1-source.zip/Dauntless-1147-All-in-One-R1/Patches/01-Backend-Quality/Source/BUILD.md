# Backend and save protection source

This folder holds the final editable source and data used by this component. It contains no standalone install button.

To assemble the complete runtime from all component folders, run `node Source/build.cjs` from the main all-in-one folder. Then run `python Source/package.py` to refresh integrity hashes and create the ZIP. Node is enough to install the already-built package; Python/build tools are only for developers.

Component tests that start with `test-` exercise this final implementation. Shared fresh-install, rollback, launcher, HTTP and package tests are under the main `Tests` folder. See the main `Source/BUILD.md` for reference inputs.
