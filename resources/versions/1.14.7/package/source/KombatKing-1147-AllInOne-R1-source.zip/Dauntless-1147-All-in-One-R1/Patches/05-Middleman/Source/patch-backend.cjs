// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one backend anchor: '+a);return s.replace(a,b);}
function patch(bytes){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 const anchor="const mega1147 = require('./mega1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,loadCapture});";
 s=once(s,anchor,anchor+"\nconst middleman1147 = require('./middleman1147').create({playerFor,bearerOf,sessions,inventoryOf,applyInventory,saveState,next:c=>mega1147.handle(c)});");
 s=once(s,'reply = mega1147.handle(','reply = middleman1147.handle(');
 s=once(s,"reply={status:500,note:'mega1147: '+e.message}","reply={status:e.status||500,note:'middleman1147: '+e.message}");
 return Buffer.from(s.replaceAll('\n',nl));
}
module.exports={patch};
