// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one backend anchor: '+a.slice(0,80));return s.replace(a,b);}
function patch(bytes){
  let s=bytes.toString('utf8');const newline=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
  s=once(s,'function handle(svc, port, req, res, bodyBuf) {',
    "// Version-specific Ramsgate feature routes.\nconst mega1147 = require('./mega1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,loadCapture});\n\nfunction handle(svc, port, req, res, bodyBuf) {");
  s=once(s,'    for (const [rSvc, rMethod, rPath, fn] of routes) {',
    "    try { reply = mega1147.handle({service:svc.service,method:req.method,path:pathName,req,body,url}); known=!!reply; }\n    catch(e) { reply={status:500,note:'mega1147: '+e.message}; known=true; }\n    for (const [rSvc, rMethod, rPath, fn] of routes) {\n      if(reply) break;");
  return Buffer.from(s.replaceAll('\n',newline));
}
module.exports={patch};
