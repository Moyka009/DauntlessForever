// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),cp=require('child_process');
const backend=require('./recorder-1147'),{atomicWrite,appendLog}=require('./quality');
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function within(promise,ms){let timer;return Promise.race([promise,new Promise(resolve=>{timer=setTimeout(resolve,ms);})]).finally(()=>clearTimeout(timer));}
function alive(pid){if(!Number.isInteger(pid)||pid<1)return false;try{process.kill(pid,0);return true;}catch(e){return e.code==='EPERM';}}
async function run(options={}){
 const args=process.argv.slice(2),at=args.indexOf('--dir');
 const root=path.resolve(options.root||(at>=0?args[at+1]:path.join(__dirname,'..')));
 const data=path.join(root,'data'),logs=path.join(root,'logs');
 fs.mkdirSync(data,{recursive:true});fs.mkdirSync(logs,{recursive:true});
 const runtimeFile=path.join(data,'backend-runtime.json'),stopFile=path.join(data,'supervisor-stop.json');
 const marker=path.join(data,'server.json'),runId=crypto.randomUUID(),token=crypto.randomBytes(24).toString('hex');
 if(fs.existsSync(runtimeFile)){
  const old=JSON.parse(fs.readFileSync(runtimeFile,'utf8'));
  if(alive(old.pid))throw Error('A managed 1.14.7 session is already running. Use STOP in its launcher.');
 }
 const config=JSON.parse(fs.readFileSync(path.join(root,'config.json'),'utf8').replace(/^\uFEFF/,''));
 if(!config.GameDir)throw Error('Configured game folder is missing');
 for(const file of [marker,path.join(data,'server_hunt.json')]){
  let prior;try{prior=JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));}catch{}
  if(prior?.pid&&alive(prior.pid))throw Error('An older game server is still running; use STOP before launching again');
 }
 const services=JSON.parse(fs.readFileSync(path.join(root,'services_1147.json'),'utf8'));
 const controlPort=(services.find(s=>s.service==='_external')||services[0]).port;
 const children=new Set();let closing=false,shutdownPromise=null,reason='',exitCode=0,parentTimer,backendStarting;
 const output=options.output||(text=>console.log(text));
 const readJson=file=>{try{return JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));}catch{return null;}};
 const history=path.join(logs,'session-status.jsonl');
 function emit(stage,text,error=false){
  const event={time:new Date().toISOString(),stage,message:text,error};
  try{appendLog(history,event,2*1024*1024);}catch{}
  output((error?'STOPPED: ':'')+'['+stage+'] '+text);
 }
 function child(kind,command){
  const processChild=(options.spawn||cp.spawn)(command.file,command.args,{cwd:root,env:{...process.env},windowsHide:true,stdio:['ignore','pipe','pipe']});
  processChild.kind=kind;children.add(processChild);
  const exited=new Promise(resolve=>{processChild.once('exit',(code,signal)=>{children.delete(processChild);resolve({code,signal});});processChild.once('error',error=>{children.delete(processChild);resolve({code:1,error});});});
  processChild.exited=exited;
  for(const [stream,isError]of [[processChild.stdout,false],[processChild.stderr,true]]){
   let pending='';stream.setEncoding('utf8');stream.on('data',chunk=>{
    pending+=chunk;
    if(pending.length>256*1024)pending=pending.slice(-256*1024);
    const lines=pending.split(/\r?\n/);pending=lines.pop();
    for(const line of lines){
     if(!line.trim())continue;
     try{appendLog(path.join(logs,'controller-output.jsonl'),{time:new Date().toISOString(),worker:kind,error:isError,line},4*1024*1024);}catch{}
     if(isError||/STOPPED:|NOT DONE:|SECOND SERVER (starting|READY|stopped)|Game closed|Could not collect/i.test(line))emit(kind,line.trim(),isError||/STOPPED:|NOT DONE:/.test(line));
    }
   });
  }
  return processChild;
 }
 async function killTree(processChild){
  if(!children.has(processChild))return;
  if(options.killTree)return options.killTree(processChild);
  if(process.platform==='win32')await new Promise(resolve=>cp.execFile('taskkill.exe',['/PID',String(processChild.pid),'/T','/F'],{windowsHide:true},()=>resolve()));
  else processChild.kill('SIGTERM');
  await within(processChild.exited,3000);
 }
 async function shutdown(why,code=0){
  if(shutdownPromise)return shutdownPromise;
  closing=true;reason=why;exitCode=code;clearInterval(parentTimer);
  shutdownPromise=(async()=>{
   emit('Session','Stopping: '+why);
   atomicWrite(stopFile,JSON.stringify({run_id:runId}));
   for(const c of [...children])if(c.kind==='Game')await killTree(c);
   for(const c of [...children]){
    await within(c.exited,options.stopTimeout||15000);
    if(children.has(c))await killTree(c);
   }
   if(backendStarting)await backendStarting.catch(()=>{});
   await backend.stop();
   for(const file of [marker,path.join(data,'server_hunt.json'),path.join(data,'wanted.json'),stopFile]){
    try{fs.unlinkSync(file);}catch{}
   }
   try{if(readJson(runtimeFile)?.run_id===runId)fs.unlinkSync(runtimeFile);}catch{}
   emit('Session','Closed. Player saves kept.');
  })();
  return shutdownPromise;
 }
 const onSignal=()=>shutdown('Stop requested').catch(e=>console.error('STOPPED: '+e.message));
 process.on('SIGINT',onSignal);process.on('SIGTERM',onSignal);
 try{
  emit('Backend','Starting local services...');
  backendStarting=backend.start({quiet:true,control:(req,res)=>{
   let pathname;try{pathname=new URL(req.url,'http://127.0.0.1').pathname;}catch{return false;}
   if(pathname!=='/_supervisor/stop')return false;
   if(req.method!=='POST'||req.headers['x-df-control']!==token){res.writeHead(403);res.end();return true;}
   res.writeHead(202,{'Content-Type':'application/json'});res.end('{"stopping":true}');
   setImmediate(()=>shutdown('Launcher stop requested').catch(e=>console.error('STOPPED: '+e.message)));return true;
  }});
  await backendStarting;
  if(closing){await shutdownPromise;return exitCode;}
  atomicWrite(runtimeFile,JSON.stringify({pid:process.pid,run_id:runId,control_port:controlPort,control_token:token,started:new Date().toISOString()},null,2));
  const parentPid=options.parentPid===undefined?process.ppid:options.parentPid;
  if(parentPid) {parentTimer=setInterval(()=>{if(!closing&&!alive(parentPid))shutdown('Launcher session ended').catch(()=>{});},2000);parentTimer.unref();}
  for(const f of [marker,path.join(data,'server_hunt.json'),path.join(data,'wanted.json'),stopFile]){
   const prior=readJson(f);if(prior?.pid&&alive(prior.pid))throw Error('An older server is still running; use STOP before launching again');
   try{fs.unlinkSync(f);}catch{}
  }
  const commands=options.commands||{
   city:id=>({file:'powershell.exe',args:['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(root,'tools/server-1147.ps1'),'-Run','-Managed','-ManagedRunId',id]}),
   game:()=>({file:'powershell.exe',args:['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(root,'tools/play-1147.ps1')]})
  };
  emit('City','Starting Ramsgate server...');
  const city=child('City',commands.city(runId));
  city.exited.then(result=>{if(!closing)shutdown('Ramsgate server exited'+(result.error?': '+result.error.message:''),1).catch(()=>{});});
  const deadline=Date.now()+(options.startTimeout||300000);let next=Date.now()+10000;
  while(!closing){
   const m=readJson(marker);
   if(m?.run_id===runId&&alive(m.pid)){emit('City','Ready. Starting the game...');break;}
   if(Date.now()>deadline)throw Error('Ramsgate server did not become ready before the timeout');
   if(Date.now()>next){emit('City','Still starting...');next=Date.now()+10000;}
   await sleep(200);
  }
  if(!closing){
   const game=child('Game',commands.game());emit('Game','Running. Status stays in the launcher.');
   const result=await game.exited;
   await shutdown(result.code===0?'Game closed':'Game process ended with an error',result.code===0?0:1);
  }
  if(shutdownPromise)await shutdownPromise;
 }catch(error){emit('Session',error.message,true);await shutdown('Startup or runtime failure',1);}
 finally{process.removeListener('SIGINT',onSignal);process.removeListener('SIGTERM',onSignal);clearInterval(parentTimer);}
 return exitCode;
}
module.exports={run};
if(require.main===module)run().then(code=>{process.exitCode=code;}).catch(error=>{console.error('STOPPED: '+error.message);process.exitCode=1;});
