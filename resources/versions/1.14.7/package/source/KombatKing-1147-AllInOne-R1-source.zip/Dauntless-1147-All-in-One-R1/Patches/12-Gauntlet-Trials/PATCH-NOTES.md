# Gauntlet access and Trials launches

Supplies Gauntlet season 5 from the shipped tables, personal completed-level saving, next-level access and selected-level forwarding to the server/party. Adds 44 missing Normal/Dauntless Trials destinations while preserving the native matching 22-week rotation.

Included at the user's request. Gauntlet stays available without automatic season resets. The shipped Trials queue repeats weekly from Thursday 2023-02-02 18:00 UTC. It does not use the older 1.6.2 Monday scheduler.

**Validation and limits:** Not yet confirmed in gameplay. Gauntlet Crests, reward grants, guild rewards and guild leaderboards are NOT implemented: its reward arrays are empty. This component is an access/progress repair, not the full online Gauntlet service. Backend/launch/restart tests pass.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
