# Trials store ownership

Store ownership comes from the account inventory rather than captured online ownership. Keeps normal costs, repeatable offers and Champion restrictions. Purchase tokens are account/character-bound, saved and replay-safe.

Includes the final Trials store patch. Trials hunt scheduling and destinations are in patch 12.

**Validation and limits:** Trials store was confirmed working. Automated tests cover unowned cosmetics, equipment, costs, ownership, replays and save failures.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
