// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one season bank anchor: '+a);return s.replace(a,b);}
function patch(bytes){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 const a="const huntpass1147 = require('./huntpass1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,loadCapture,next:c=>trials1147.handle(c)});";
 s=once(s,a,"var huntpassSeasons1147 = require('./huntpass-seasons1147').create(ROOT);\nconst huntpass1147 = require('./huntpass1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,loadCapture,next:c=>trials1147.handle(c)}, {data:huntpassSeasons1147.data,seasons:huntpassSeasons1147});");
 s=once(s,'function saveState() {','function saveStateNative() {');
 s+='\nfunction saveState() { return huntpassSeasons1147 ? huntpassSeasons1147.save(state, saveStateNative) : saveStateNative(); }\n';
 return Buffer.from(s.replaceAll('\n',nl));
}
module.exports={patch};
