from pathlib import Path
import sys,struct,json
sys.path.insert(0,'Mega-Patch-1147-Task04-HuntPass-Fix1/Source');from equipment_asset import Asset
class Script:
 def __init__(self,a,e):
  self.a=a;self.e=e;end=e['start']+e['size']-12
  matches=[p for p in range(e['start']+8,end-4)if struct.unpack_from('<I',a.b,p)[0]==end-p-4]
  matches=[p for p in matches if a.b[p+4] in [0x4c,0x46,0x4e,0x04,0x1b,0x0f,0x14,0x45]];assert matches;self.start=matches[0]+4;self.end=end;self.p=self.start;self.m=0;self.nodes=[]
 def rd(self,fmt,mem=None):
  n=struct.calcsize(fmt);v=struct.unpack_from(fmt,self.a.b,self.p);self.p+=n;self.m+=n if mem is None else mem;return v[0]if len(v)==1 else v
 def name(self):
  ix,num=self.rd('<II',12);return self.a.names[ix]+('_'+str(num-1)if num else'')
 def field(self):
  n=self.rd('<I',0);assert n<20,(self.p,n);names=[self.name()for _ in range(n)];self.m-=n*12;owner=self.rd('<i',8);return f'{self.a.object(owner)}:'+'.'.join(names)
 def expr(self):
  p=self.p;m=self.m;op=self.rd('<B');v=None;ch=[]
  if op in [0x00,0x01,0x02,0x48]:v=self.field()
  elif op in [0x04,0x4e,0x4f,0x51]:ch=[self.expr()]
  elif op in [0x06,0x4c,0x5b]:v=self.rd('<I')
  elif op in [0x07,0x18]:v=self.rd('<I');ch=[self.expr()]
  elif op==0x0f:v=self.field();ch=[self.expr(),self.expr()]
  elif op in [0x14,0x44,0x64,0x5f]:ch=[self.expr(),self.expr()]
  elif op in [0x19,0x1a,0x12]:ch=[self.expr()];v=[self.rd('<I'),self.field()];ch.append(self.expr())
  elif op in [0x1b,0x45]:
   v=self.name()
   while self.a.b[self.p]!=0x16:ch.append(self.expr())
   ch.append(self.expr())
  elif op in [0x1c,0x46,0x68]:
   v=self.a.object(self.rd('<i',8))
   while self.a.b[self.p]!=0x16:ch.append(self.expr())
   ch.append(self.expr())
  elif op==0x1d:v=self.rd('<i')
  elif op==0x1e:v=self.rd('<f')
  elif op==0x34:
   e=self.p
   while self.a.b[e:e+2]!=b'\0\0':e+=2
   v=self.a.b[self.p:e].decode('utf-16le');self.m+=e-self.p+2;self.p=e+2
  elif op==0x1f:
   e=self.a.b.index(0,self.p);v=self.a.b[self.p:e].decode();self.m+=e-self.p+1;self.p=e+1
  elif op==0x20:v=self.a.object(self.rd('<i',8))
  elif op==0x21:v=self.name()
  elif op in [0x24,0x2c]:v=self.rd('<B')
  elif op in [0x13,0x2d,0x2e,0x52,0x54,0x55]:v=self.a.object(self.rd('<i',8));ch=[self.expr()]
  elif op==0x2f:
   v=[self.a.object(self.rd('<i',8)),self.rd('<I')]
   while self.a.b[self.p]!=0x30:ch.append(self.expr())
   ch.append(self.expr())
  elif op in [0x22,0x23]:v=self.rd('<fff')
  elif op==0x31:
   ch=[self.expr()]
   while self.a.b[self.p]!=0x32:ch.append(self.expr())
   ch.append(self.expr())
  elif op==0x38:v=self.rd("<B");ch=[self.expr()]
  elif op==0x63:
   v=self.a.object(self.rd('<i',8));ch=[self.expr()]
   while self.a.b[self.p]!=0x16:ch.append(self.expr())
   ch.append(self.expr())
  elif op in [0x5c,0x62]:ch=[self.expr(),self.expr()]
  elif op==0x61:v=self.name();ch=[self.expr(),self.expr()]
  elif op==0x42:v=self.field();ch=[self.expr()]
  elif op in [0xb,0x15,0x16,0x17,0x25,0x2a,0x26,0x27,0x28,0x30,0x32,0x4d,0x53,0x5a]:pass
  else:raise ValueError(('opcode',hex(op),'file',self.p-1,'memory',m))
  n={'offset':p,'mem':m,'op':hex(op),'v':v,'children':ch,'end':self.p,'memend':self.m};self.nodes.append(n);return n
 def read(self):
  while self.p<self.end:self.expr()
  return self.nodes
