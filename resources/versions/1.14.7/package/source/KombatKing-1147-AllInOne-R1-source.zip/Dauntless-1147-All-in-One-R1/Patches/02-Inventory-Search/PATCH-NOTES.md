# Inventory and name/ID search

Correct catalog-defined storage, equipment/cell/upgrade preservation, equipped-item protection, search by name or ID, two-line dropdown suggestions, keyboard selection and name-based additions. Patches both the bundled launcher and the active launcher update when present.

Consolidates Inventory R2 with the final Inventory Search Fix2. Replaces the old ID-only input behavior. Existing item lists and selected quantities are kept.

**Validation and limits:** Search and additions were confirmed in game/launcher. Current official launcher source and update preservation are also checked automatically.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
