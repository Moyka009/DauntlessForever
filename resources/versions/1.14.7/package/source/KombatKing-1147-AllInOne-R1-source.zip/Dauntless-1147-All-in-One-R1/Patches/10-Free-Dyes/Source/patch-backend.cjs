// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one dye backend anchor');return s.replace(a,b);}
function patch(b){let s=b.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');const next=s.includes('const equipment1147 =')?'equipment1147':s.includes('const bounties1147 =')?'bounties1147':'huntpass1147';const line=s.split('\n').find(l=>l.startsWith('const '+next+' ='));if(!line)throw Error('Previous backend chain missing');s=once(s,line,line+"\nconst dyes1147 = require('./dyes1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,next:c=>"+next+".handle(c)});");s=once(s,'reply = '+next+'.handle(','reply = dyes1147.handle(');return Buffer.from(s.replaceAll('\n',nl));}
module.exports={patch};
