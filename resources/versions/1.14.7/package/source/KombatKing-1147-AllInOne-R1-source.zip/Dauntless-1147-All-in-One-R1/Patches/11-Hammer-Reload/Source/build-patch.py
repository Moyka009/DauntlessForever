from pathlib import Path
import struct,json,hashlib,subprocess,os
from equipment_asset import Asset,fs
from blueprint_script import Script
root=Path(__file__).resolve().parents[1];work=Path(os.environ.get('DAUNTLESS_REFERENCE_WORKSPACE',str(root.parents[2])))/'game_rules1147_work';refs=work/'hammer-reference';rel='Archon/Content/Character/Player/blueprints/reload_ammo_hammer_bpn'
a=Asset(refs/(rel+'.uasset'));ammo=Asset(next(refs.rglob('ammo_bpc.uasset')));s=Script(a,a.exports[0]);s.read()
assert s.m==struct.unpack_from('<I',a.b,s.start-8)[0]==536
context=next(n for n in s.nodes if n['op']=='0x19'and any(c['v']=='AuthReloadWeaponWithAmmoScale'for c in n['children']))
call=context['children'][1];scale,override,terminator=call['children'];assert override['op']=='0x28';assert context['mem']==424 and context['memend']==492
# Copy the name's original serialized hashes from the exact same build's ammo Blueprint.
p=struct.unpack_from('<I',ammo.ua,45)[0];entry=None
for name in ammo.names:
 text,end=fs(ammo.ua,p)
 if text=='AuthReloadNumAmmo':entry=ammo.ua[p:end+4]
 p=end+4
assert entry and 'AuthReloadNumAmmo'not in a.names
new_index=len(a.names);new_call=b'\x45'+struct.pack('<II',new_index,0)+b'\x26'+a.b[scale['offset']:scale['end']]+b'\x16'
old_call=a.b[call['offset']:call['end']];assert len(new_call)==len(old_call)
new_context=a.b[context['offset']:call['offset']]+new_call
# Bytecode field pointers are 8 bytes in memory, serialized as field paths.
flag=b'\x01'+struct.pack('<IIIi',1,a.names.index('FastReloadFailure'),0,2)
raw_delta=5+len(flag)+len(new_context)+5;mem_delta=5+9+(context['memend']-context['mem'])+5
assert (raw_delta,mem_delta)==(123,87)
branch=b'\x07'+struct.pack('<I',context['mem']+mem_delta)+flag
branch+=new_context+b'\x06'+struct.pack('<I',context['memend']+mem_delta)
assert len(branch)==raw_delta
ue=bytearray(a.b)
# Adjust every original absolute branch target; target at the insertion boundary
# still points to the new flag test. Relative Context skip lengths are unchanged.
for n in s.nodes:
 if n['op']in ['0x6','0x7','0x4c','0x5b']and n['v']>context['mem']:
  struct.pack_into('<I',ue,n['offset']+1,n['v']+mem_delta)
struct.pack_into('<I',ue,s.start-8,s.m+mem_delta)
struct.pack_into('<I',ue,s.start-4,s.end-s.start+raw_delta)
ue[context['offset']:context['offset']]=branch
# Append one FName before the import table. All existing name/import/export IDs stay fixed.
u=bytearray(a.ua);name_end=struct.unpack_from('<I',u,45)[0]
for _ in a.names:_,name_end=fs(u,name_end);name_end+=4
assert name_end==struct.unpack_from('<I',u,69)[0]
export_count,export_at=struct.unpack_from('<II',u,57)
for i in range(export_count):
 pos=export_at+i*104;size,offset=struct.unpack_from('<qq',u,pos+28)
 struct.pack_into('<q',u,pos+28,size+(raw_delta if i==0 else 0))
 struct.pack_into('<q',u,pos+36,offset+len(entry)+(raw_delta if i>0 else 0))
for pos in [24,53,61,69,73,81,85,89,165,177,189]:
 value=struct.unpack_from('<I',u,pos)[0]
 if value>=name_end:struct.pack_into('<I',u,pos,value+len(entry))
struct.pack_into('<I',u,41,new_index+1);struct.pack_into('<I',u,117,new_index+1)
bulk=struct.unpack_from('<q',u,169)[0];struct.pack_into('<q',u,169,bulk+len(entry)+raw_delta)
u[name_end:name_end]=entry
out=root/'Source/pak'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.with_suffix('.uasset').write_bytes(u);out.with_suffix('.uexp').write_bytes(ue)
patched=Asset(out.with_suffix('.uasset'));ps=Script(patched,patched.exports[0]);ps.read();assert ps.m==623 and ps.p==ps.end
assert patched.names[:-1]==a.names and patched.names[-1]=='AuthReloadNumAmmo'
assert len(ue)==len(a.b)+123 and len(u)==len(a.ua)+len(entry)
for before,after in zip(a.exports[1:],patched.exports[1:]):assert a.b[before['start']:before['start']+before['size']]==patched.b[after['start']:after['start']+after['size']]
repak=work/'repak/repak_cli-x86_64-unknown-linux-gnu/repak';pak=root/'Source/zzzzzzzzzzzzzzzz_HammerReload1147_P.pak'
subprocess.run([str(repak),'pack','--version','V3','--mount-point','../../../',str(root/'Source/pak'),str(pak)],check=True)
for ext in ['.uasset','.uexp']:
 result=subprocess.check_output([str(repak),'get',str(pak),rel+ext]);assert result==out.with_suffix(ext).read_bytes()
evidence={'game':'1.14.7 CL647472','manifest_sha1':hashlib.sha1((work/'Dauntless_1.14.7.647472.manifest').read_bytes()).hexdigest(),'asset':rel,'source':{ext:hashlib.sha256((refs/(rel+ext)).read_bytes()).hexdigest()for ext in ['.uasset','.uexp']},'script_before_memory_size':536,'script_after_memory_size':623,'inserted_serialized_bytes':123,'new_name':'AuthReloadNumAmmo','name_hash_source':'1.14.7 ammo_bpc.uasset exact serialized FName entry','original_full_refill_context_memory_offset':424,'failure_flag':'FastReloadFailure','failure_montage':'h_mr_ih_activereload_failure_mot has FastReloadFailure=True','behavior':'Failure flag true: AuthReloadNumAmmo(1, original NormalAmmoScale); false: original full reload call, unchanged. Both retain original server guard and validity checks. Shared ammo Blueprint, hammer weapon Blueprint, success notify and pike assets are not replaced.'}
(root/'Source/asset-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
print('Built failed-only branch; full script decoded; unchanged other exports; PAK round trip passed.')
