# Fountain and store supplies

Enables the daily fountain/store gift with Patrol Keys and the normal daily supply rewards. Adds the repeatable free pack containing 25 Bounty Tokens, 25 Ace Chips and 25 Patrol Keys. Uses native 1.14.7 offer fields, persisted claims and replay-safe redemption.

Uses the final Fountain Fix2. The older offer schemas and failed shop fixes are not installed. Daily gift claims reset on the existing UTC-day rule; the three-item supply pack remains repeatable.

**Validation and limits:** Fountain and shop behavior were confirmed working. Automated tests cover gifts, claims, repeat purchases, account ownership and failed-save rollback.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
