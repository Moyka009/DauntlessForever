// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Expected one Gauntlet/Trials backend anchor: '+a);return s.replace(a,b);};
function patch(b){let s=b.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 const candidates=['dyes1147','equipment1147','bounties1147','huntpass1147','mega1147'];
 const next=candidates.find(n=>s.includes('reply = '+n+'.handle('));if(!next)throw Error('Supported backend route chain not found');
 const line=s.split('\n').find(l=>l.startsWith('const '+next+' ='));
 s=once(s,line,line+"\nconst modes1147 = require('./modes1147').create({playerFor,bearerOf,sessions,getPlayers:()=>Object.values(state.players||{}),saveState,next:c=>"+next+".handle(c)});");
 s=once(s,'reply = '+next+'.handle(','reply = modes1147.handle(');
 s=once(s,"function destinationFor(b) {","function destinationFor(b) {\n  const modesDestination = require('./modes1147').destination(b);\n  if (modesDestination) return modesDestination;");
 s=once(s,'const dest = destinationFor(b);',`const dest = destinationFor(b);
    if (!dest.city && dest.url && ['GAUNTLET','TRIALS'].includes(b.gameType) && /^[A-Za-z0-9_]{1,100}$/.test(String(b.playerHuntId || '')) && !/[?]PlayerHuntIds=/.test(dest.url)) {
      dest.url += '?PlayerHuntIds=' + p.accountId + ':' + b.playerHuntId;
    }`);
 s=once(s,'huntId: Array.isArray(b.hunts) && b.hunts.length ? b.hunts[0] : null, playerHuntId: b.playerHuntId || null,','huntId: Array.isArray(b.hunts) && b.hunts.length ? b.hunts[0] : null, playerHuntId: b.playerHuntId || null, gauntletLevel: b.gameType === \'GAUNTLET\' ? b.gauntlet_level : null,');
 s=once(s,'gauntletLevel: null, leaderPlayerId:',"gauntletLevel: cd?.gauntletLevel ?? null, leaderPlayerId:");
 return Buffer.from(s.replaceAll('\n',nl));
}
module.exports={patch};
