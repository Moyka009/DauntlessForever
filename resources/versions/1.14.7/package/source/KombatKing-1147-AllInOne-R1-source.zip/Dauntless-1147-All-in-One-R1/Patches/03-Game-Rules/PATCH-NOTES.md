# Game Rules up to 5x

Choices up to 5x for universal progression, weapon XP, Hunt Pass XP, mastery progress, materials, Rams, Combat Merits, Exploration Merits and Rare Cell Cores. Includes the existing optional core-per-kill and recognized free-crafting toggles. Defaults remain normal rates and toggles off.

Consolidates Game Rules R1 and the final range reduction. Saved individual values above 5 are lowered to 5; lower choices, comments and toggles are preserved. Current settings remain after restore. Universal and individual XP factors can combine, as in the existing module.

**Validation and limits:** Range and backend calculations have automated checks; not every progression/crafting path has been confirmed in gameplay. Scaling does not cover arbitrary character snapshots or Escalation XP. Purchases and spending are not multiplied.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
