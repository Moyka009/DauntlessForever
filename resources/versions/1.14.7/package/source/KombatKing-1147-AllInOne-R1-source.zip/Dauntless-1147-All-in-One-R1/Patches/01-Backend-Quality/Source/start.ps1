# Dauntless Forever - Dauntless 1.14.7 offline package
# Copyright (C) 2026 Addison2k. https://github.com/addison2k/DauntlessForever
# Licence: AGPL-3.0-only. Keep this notice: the licence requires it.
# start.ps1 - "2 - PLAY.bat": starts the local backend, then the game server, then the game, in that order.
# When the game is closed, the server and the backend are shut down again.
# -NoGame (Host Mode, from online-host-1147.ps1 -HostMode): no game window; the backend and the game server stay up
# until data\hostmode_stop appears or the launcher stops Host Mode. If the backend or the game server stops, this
# ends with exit code 1 and the launcher starts Host Mode again (when "Restart by itself" is on). (Oct 17)
param([switch]$NoGame)
if ($NoGame) { & (Join-Path $PSScriptRoot 'host-mode1147.ps1') -NoGame; exit $LASTEXITCODE }
. (Join-Path $PSScriptRoot 'common.ps1')

Say ''
Say '=== Dauntless 1.14.7 offline ===' 'Cyan'
$cfg = Get-Config
if (-not $cfg) { Fail 'set-up has not been run yet. Double-click "1 - SETUP.bat" first.' }
$bin = Join-Path $cfg.GameDir 'Archon\Binaries\Win64'
if ((Hash256 (Join-Path $bin 'EOSSDK-Win64-Shipping.dll')) -ne $StandInHash -or (Hash256 (Join-Path $bin 'dxgi.dll')) -ne $LoaderHash) {
    Fail 'the game folder is missing files this package puts there (maybe the game was updated or verified). Run "1 - SETUP.bat" again.'
}
foreach ($gp in $GamePaks) {
    if ((Hash256 (Join-Path $cfg.GameDir "Archon\Content\Paks\$($gp.Name)")) -ne $gp.Hash) {
        Fail "the $($gp.What) is not in the game folder yet (new in these server files). Run `"1 - SETUP.bat`" again."
    }
}
$node = $cfg.Node
if (-not $node -or -not (Test-Path -LiteralPath $node)) { $node = Find-Node }
if (-not $node) { Fail 'Node.js was not found. Run "1 - SETUP.bat" again.' }
# Windows parts the game needs (Visual C++ runtime, DirectX June 2010). Without them every copy of the game
# closes at once with no log, so say it plainly here instead.
$missing = @('vcruntime140.dll', 'vcruntime140_1.dll', 'msvcp140.dll', 'xinput1_3.dll', 'x3daudio1_7.dll', 'xapofx1_5.dll') |
    Where-Object { -not (Test-Path -LiteralPath (Join-Path $env:WINDIR "System32\$_")) }
if (@($missing).Count -gt 0) { Fail "Windows is missing parts the game needs ($(@($missing) -join ', ')). Run set-up again: it installs them." }
if (-not $NoGame -and @(Get-PlayerGame).Count -gt 0) { Fail 'the game is already running. Close it first (or end Dauntless-Win64-Shipping in Task Manager).' }

# One managed Node process owns the backend and hidden worker scripts.
# The launcher already forwards this script's stdout to What's happening.
& $node (Join-Path $Root 'backend\supervisor-1147.js') --dir $Root
exit $LASTEXITCODE
