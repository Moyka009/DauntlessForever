# All free dyes

Adds one free **All Dyes** pack containing all 475 verified 1.14.7 dye catalog IDs. Replaces the separate dye listings. One purchase grants every missing dye using its correct stack/instance storage, with saved ownership and replay-safe redemption. Existing dyes and their quantities are preserved. The pack shows as owned when all dyes are owned.

Includes the final Free Dyes implementation. The Game Rules range change formerly packaged with it is now in patch 03.

**Validation and limits:** Automated offer/redemption tests pass. The user has not yet confirmed the dyes in game.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.

**Dye pack update:** Run the main Install.cmd over an existing all-in-one install. It upgrades the dye module and its installation record, preserving original restore backups and saves. No separate component install button.

**Pack revision 2:** Removes original/captured dye offers by their dye contents/tags, including product IDs outside our old dye1147 list. The store returns one All Dyes Pack instead. Both the original individual-offer module and first pack revision upgrade through the main Install.cmd. Owned dyes remain unchanged.
