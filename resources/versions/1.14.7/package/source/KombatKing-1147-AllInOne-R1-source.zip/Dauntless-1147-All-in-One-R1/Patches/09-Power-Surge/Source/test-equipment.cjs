'use strict';
const assert=require('assert/strict'),{create}=require('./equipment1147');
const clone=x=>JSON.parse(JSON.stringify(x));
const tests=[],test=(n,f)=>tests.push([n,f]);
const body={accountId:'a',characterId:'c',catalogId:'WP_EB_LERAWR',instanceId:'WP_EB_LERAWR',updateVersion:1,itemData:JSON.stringify({TransmogCatalogID:'None',UnlockedAsTransmog:false,CurrentLevel:1,EquippedWeaponParts:[],CurrentXP:0})};
function fixture(){const item={catalogId:body.catalogId,instanceId:body.instanceId,updateVersion:0,metadata:'preserve'},p={accountId:'a',characters:[{id:'c'}],inventory:{c:{instancedItems:[item],stackedItems:[{catalogId:'CURRENCY_PJM_PRESTIGE_FILLED',quantity:2}]}}},other={accountId:'b'};let saved,fail=false,writes=0;
 const runtime=create({getPlayers:()=>[p,other],sessions:new Map([['auth-a',1]]),bearerOf:r=>r.headers.authorization,playerFor:()=>p,next:()=>({status:404}),saveState(){if(fail)throw Error('disk failed');saved=clone(p);writes++;}});
 return{p,item,other,run:(b=body,auth)=>runtime.handle({service:'dauntless',method:'POST',path:'/inventory/instanceditem',body:clone(b),req:{headers:{authorization:auth}}}),get saved(){return saved;},get writes(){return writes;},setFail(){fail=true;}};
}
test('Captured Ember Cutlass update saves level one and returns the raw saved item',()=>{const f=fixture(),r=f.run();assert.equal(r.status,200);assert.equal(JSON.parse(r.json.itemData).CurrentLevel,1);assert.equal(r.json.updateVersion,1);assert.equal(r.json.metadata,'preserve');assert.equal(f.saved.inventory.c.instancedItems[0].itemData,body.itemData);assert(!('payload' in r.json));});
test('Identical request replay succeeds without another save or cost deduction',()=>{const f=fixture();f.run();f.run();assert.equal(f.writes,1);assert.equal(f.p.inventory.c.stackedItems[0].quantity,2);});
test('The second captured version is accepted while older updates cannot undo it',()=>{const f=fixture();f.run({...body,updateVersion:2});assert.throws(()=>f.run(),e=>e.status===409);assert.equal(f.item.updateVersion,2);});
test('Equal versions with different item data conflict',()=>{const f=fixture();f.run();assert.throws(()=>f.run({...body,itemData:'{"CurrentLevel":0}'}),e=>e.status===409);assert.equal(JSON.parse(f.item.itemData).CurrentLevel,1);});
test('Missing gear does not create a free item',()=>{const f=fixture();assert.throws(()=>f.run({...body,instanceId:'unknown'}),e=>e.status===404);assert.equal(f.writes,0);});
test('Catalog substitution and foreign character/account updates are rejected',()=>{const f=fixture();for(const b of [{...body,catalogId:'OTHER'},{...body,characterId:'foreign'},{...body,accountId:'b'}])assert.throws(()=>f.run(b),e=>[403,409].includes(e.status));assert.equal(f.writes,0);});
test('Signed-in player cannot edit another saved account',()=>{const f=fixture();assert.throws(()=>f.run({...body,accountId:'b'},'auth-a'),e=>e.status===403);});
test('Malformed data and versions do not mutate the item',()=>{const f=fixture(),before=clone(f.p);for(const b of [{...body,updateVersion:-1},{...body,itemData:'invalid'},{...body,itemData:'[]'},{...body,itemData:{}},{...body,characterId:''}])assert.throws(()=>f.run(b),e=>e.status===400);assert.deepEqual(f.p,before);});
test('Failed persistence rolls back every item field',()=>{const f=fixture(),before=clone(f.p);f.setFail();assert.throws(()=>f.run(),/disk failed/);assert.deepEqual(f.p,before);});
for(const [n,f]of tests){f();console.log('PASS '+n);}console.log(JSON.stringify({passed:tests.length,failed:0,native_gameplay:'not tested'}));
