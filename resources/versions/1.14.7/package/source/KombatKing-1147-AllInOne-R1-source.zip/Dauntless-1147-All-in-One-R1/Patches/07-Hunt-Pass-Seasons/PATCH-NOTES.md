# Hunt Pass seasons and Mega pass

One 400-tier Mega pass contains all 2,997 cosmetic-marked 1.14.7 catalog items once. Includes 35 non-Mega season clones with separate progress and both tracks enabled. Supports the launcher version tabs and existing 150-Platinum-per-rank skips.

Consolidates Hunt Pass Fix1 and the final season bank. Hunt Pass availability stays permanent; no annual reset is added. The native UI week-placeholder cap is in patch 08. Sign-in and shared config requests no longer select a player unnecessarily during pass routing.

**Validation and limits:** Hunt Pass access, season selection and Mega pass behavior were confirmed working. Backend reward/switch/restart tests pass. Nine source rewards using six IDs missing in 1.14.7 remain omitted and marked unavailable; no substitute items are silently added.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
