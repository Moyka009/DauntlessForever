# Middleman slots and fusion source

This folder holds the final editable source and data used by this component. It contains no standalone install button.

To assemble the complete runtime from all component folders, run `node Source/build.cjs` from the main all-in-one folder. Then run `python Source/package.py` to refresh integrity hashes and create the ZIP. Node is enough to install the already-built package; Python/build tools are only for developers.

Native assets/helper rebuilding needs the exact original 1.14.7 CL647472 files, the supplied manifest hash checks and the tools named in the Python build script. Set `DAUNTLESS_REFERENCE_WORKSPACE` to a reference workspace containing `game_rules1147_work`; original game files and the SDK are not redistributed. The hammer Blueprint parser, modified cooked notification and native assembly are included where applicable.

Component tests that start with `test-` exercise this final implementation. Shared fresh-install, rollback, launcher, HTTP and package tests are under the main `Tests` folder. See the main `Source/BUILD.md` for reference inputs.
