param([Parameter(Mandatory=$true)][int]$GameProcessId,[Parameter(Mandatory=$true)][string]$GameExe)
$ErrorActionPreference='Stop'
$repairLog=Join-Path (Split-Path $PSScriptRoot -Parent) 'logs\bounty_menu_guard.log'
try {
    if(-not [Environment]::Is64BitProcess){throw 'Menu repair requires 64-bit PowerShell.'}
    $spec=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'menu-repair1147.json') -Raw | ConvertFrom-Json
    if((Get-FileHash -LiteralPath $GameExe -Algorithm SHA256).Hash -ne $spec.source_sha256){throw 'Executable differs from verified 1.14.7 CL647472.'}
    if(-not ('DF1147.MenuRepair' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
namespace DF1147 {
 public static class MenuRepair {
  [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int id);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool ReadProcessMemory(IntPtr h,IntPtr a,byte[] b,UIntPtr n,out UIntPtr count);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool WriteProcessMemory(IntPtr h,IntPtr a,byte[] b,UIntPtr n,out UIntPtr count);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool VirtualProtectEx(IntPtr h,IntPtr a,UIntPtr n,uint protect,out uint old);
  [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr VirtualAllocEx(IntPtr h,IntPtr a,UIntPtr n,uint type,uint protect);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool VirtualFreeEx(IntPtr h,IntPtr a,UIntPtr n,uint type);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool FlushInstructionCache(IntPtr h,IntPtr a,UIntPtr n);
  [DllImport("ntdll.dll")] static extern int NtSuspendProcess(IntPtr h);
  [DllImport("ntdll.dll")] static extern int NtResumeProcess(IntPtr h);
  static byte[] Hex(string s){byte[] b=new byte[s.Length/2];if(s.Length%2!=0)throw new Exception("Invalid hex");for(int i=0;i<b.Length;i++)b[i]=Convert.ToByte(s.Substring(i*2,2),16);return b;}
  static bool Equal(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
  static byte[] Read(IntPtr h,IntPtr a,int n){byte[] b=new byte[n];UIntPtr count;if(!ReadProcessMemory(h,a,b,new UIntPtr((uint)n),out count)||count.ToUInt64()!=(ulong)n)throw new Win32Exception(Marshal.GetLastWin32Error());return b;}
  static void Write(IntPtr h,IntPtr a,byte[] b){uint old,unused;UIntPtr n=new UIntPtr((uint)b.Length),count;if(!VirtualProtectEx(h,a,n,0x40,out old))throw new Win32Exception(Marshal.GetLastWin32Error());try{if(!WriteProcessMemory(h,a,b,n,out count)||count.ToUInt64()!=(ulong)b.Length)throw new Win32Exception(Marshal.GetLastWin32Error());if(!FlushInstructionCache(h,a,n))throw new Win32Exception(Marshal.GetLastWin32Error());}finally{if(!VirtualProtectEx(h,a,n,old,out unused))throw new Win32Exception(Marshal.GetLastWin32Error());}}
  public static string Apply(int id,string exe,string codeHex,int[] fixOffsets,int[] fixRvas,int[] rvas,string[] beforeHex,string[] fixedHex,int[] targets,int[] ops){
   byte[] code=Hex(codeHex);int count=rvas.Length;
   if(count!=12||code.Length!=4224||fixOffsets.Length!=fixRvas.Length||beforeHex.Length!=count||fixedHex.Length!=count||targets.Length!=count||ops.Length!=count)throw new Exception("Invalid repair specification");
   using(Process p=Process.GetProcessById(id)){
    ProcessModule m=null;for(int attempt=0;attempt<50;attempt++){try{m=p.MainModule;if(m!=null)break;}catch(Win32Exception){}System.Threading.Thread.Sleep(100);}
    if(m==null||!String.Equals(System.IO.Path.GetFullPath(m.FileName),System.IO.Path.GetFullPath(exe),StringComparison.OrdinalIgnoreCase))throw new Exception("Client process mismatch");
    if((DateTime.Now-p.StartTime).TotalSeconds>30)throw new Exception("Repair must be applied during client startup");
    long image=m.BaseAddress.ToInt64();IntPtr h=OpenProcess(0xc38,false,id);if(h==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());
    IntPtr page=IntPtr.Zero;bool paused=false,committed=false,rollbackComplete=true;int attempted=0;
    byte[][] before=new byte[count][],after=new byte[count][];
    try {
     for(int i=0;i<count;i++){before[i]=Hex(beforeHex[i]);if(rvas[i]<0||rvas[i]+before[i].Length>m.ModuleMemorySize)throw new Exception("Repair outside executable");if(!Equal(Read(h,new IntPtr(image+rvas[i]),before[i].Length),before[i]))throw new Exception("Repair bytes differ at "+rvas[i].ToString("x"));}
     // Exact-address near allocation keeps all entry jumps within signed rel32 range.
     for(int i=0;i<24;i++){long candidate=image+0x10000000L+i*0x01000000L;page=VirtualAllocEx(h,new IntPtr(candidate),new UIntPtr(8192),0x3000,0x04);if(page!=IntPtr.Zero)break;}
     if(page==IntPtr.Zero)throw new Exception("No nearby code page is available");
     for(int i=0;i<fixOffsets.Length;i++){if(fixOffsets[i]<0||fixOffsets[i]+8>code.Length||fixRvas[i]<0||fixRvas[i]>=m.ModuleMemorySize)throw new Exception("Invalid code pointer");Array.Copy(BitConverter.GetBytes(image+fixRvas[i]),0,code,fixOffsets[i],8);}
     Write(h,page,code);uint prior;if(!VirtualProtectEx(h,page,new UIntPtr(4096),0x20,out prior))throw new Win32Exception(Marshal.GetLastWin32Error());
     if(!Equal(Read(h,page,code.Length),code))throw new Exception("Code page verification failed");
     for(int i=0;i<count;i++){
      if(fixedHex[i].Length>0){after[i]=Hex(fixedHex[i]);}
      else{if(targets[i]<0||targets[i]>=code.Length||ops[i]!=0xe8&&ops[i]!=0xe9)throw new Exception("Invalid entry target");long delta=page.ToInt64()+targets[i]-image-rvas[i]-5;if(delta<Int32.MinValue||delta>Int32.MaxValue)throw new Exception("Entry jump is out of range");after[i]=new byte[before[i].Length];for(int j=0;j<after[i].Length;j++)after[i][j]=0x90;after[i][0]=(byte)ops[i];Array.Copy(BitConverter.GetBytes((int)delta),0,after[i],1,4);}
      if(after[i].Length!=before[i].Length)throw new Exception("Repair size mismatch");
     }
     if(NtSuspendProcess(h)!=0)throw new Exception("Could not pause client for atomic repair");paused=true;
     for(int i=0;i<count;i++)if(!Equal(Read(h,new IntPtr(image+rvas[i]),before[i].Length),before[i]))throw new Exception("Client bytes changed before repair");
     try{for(int i=0;i<count;i++){attempted=i+1;Write(h,new IntPtr(image+rvas[i]),after[i]);if(!Equal(Read(h,new IntPtr(image+rvas[i]),after[i].Length),after[i]))throw new Exception("Entry verification failed");}committed=true;}
     catch{for(int i=attempted-1;i>=0;i--){try{Write(h,new IntPtr(image+rvas[i]),before[i]);if(!Equal(Read(h,new IntPtr(image+rvas[i]),before[i].Length),before[i]))rollbackComplete=false;}catch{rollbackComplete=false;}}throw;}
     return "applied to client pid "+id+"; 12 menu repair points; bounded challenge-menu weeks; weekly season dates cached; closed quest callbacks removed";
    } finally {
     if(paused){if(NtResumeProcess(h)!=0)Console.Error.WriteLine("Menu repair: client resume failed.");}
     // Never release a code page if a failed rollback might still refer to it.
     if(page!=IntPtr.Zero&&!committed&&rollbackComplete)VirtualFreeEx(h,page,UIntPtr.Zero,0x8000);
     CloseHandle(h);
    }
   }
  }
 }
}
'@
    }
    [int[]]$fixOffsets=@($spec.fixups | ForEach-Object {[int]$_.offset})
    [int[]]$fixRvas=@($spec.fixups | ForEach-Object {[int]$_.rva})
    [int[]]$rvas=@($spec.patches | ForEach-Object {[int]$_.rva})
    [string[]]$before=@($spec.patches | ForEach-Object {[string]$_.before})
    [string[]]$after=@($spec.patches | ForEach-Object {if($_.after){[string]$_.after}else{''}})
    [int[]]$targets=@($spec.patches | ForEach-Object {[int]$_.target_offset})
    [int[]]$ops=@($spec.patches | ForEach-Object {[int]$_.op})
    $result=[DF1147.MenuRepair]::Apply($GameProcessId,$GameExe,[string]$spec.code,$fixOffsets,$fixRvas,$rvas,$before,$after,$targets,$ops)
    [IO.Directory]::CreateDirectory((Split-Path $repairLog -Parent)) | Out-Null
    [IO.File]::WriteAllText($repairLog,((Get-Date -Format o)+' '+$result+[Environment]::NewLine))
    Write-Host ('Menu repair: '+$result)
} catch {
    $reason='Menu repair NOT applied: '+$_.Exception.Message
    [IO.Directory]::CreateDirectory((Split-Path $repairLog -Parent)) | Out-Null
    [IO.File]::WriteAllText($repairLog,((Get-Date -Format o)+' '+$reason+[Environment]::NewLine))
    Write-Warning $reason
}
