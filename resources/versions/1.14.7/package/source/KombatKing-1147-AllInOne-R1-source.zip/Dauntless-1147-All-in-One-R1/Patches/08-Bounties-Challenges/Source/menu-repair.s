.intel_syntax noprefix
.text
.global closed,cleanup,compact
# Returns AL=1 only for a widget owned by a destructed ArchonScreen.
closed:
 mov r10,rcx
 mov edx,64
 mov rax,QWORD PTR [rip+screen_class]
 mov rax,QWORD PTR [rax]
 test rax,rax
 jz open
outer_loop:
 test r10,r10
 jz open
 mov r11,QWORD PTR [r10+0x10]
 mov r8d,64
class_loop:
 test r11,r11
 jz next_outer
 cmp r11,rax
 je found_screen
 mov r11,QWORD PTR [r11+0x40]
 dec r8d
 jnz class_loop
 jmp open
next_outer:
 mov r10,QWORD PTR [r10+0x20]
 dec edx
 jnz outer_loop
open:
 xor eax,eax
 ret
found_screen:
 movzx eax,BYTE PTR [r10+0x3d0]
 ret

# Called in place of JournalScreen's call to its base NativeDestruct.
# Preserve the base call and then remove closed-screen bindings from normal bounties.
cleanup:
 push rbx
 push rsi
 push rdi
 sub rsp,32
 mov rbx,rcx
 call QWORD PTR [rip+base_destruct]
 lea rcx,[rbx+0x530]
 call QWORD PTR [rip+weak_get]
 test rax,rax
 jz cleanup_end
 mov rsi,rax
 mov edi,0xe0
cleanup_next:
 lea rcx,[rsi+rdi]
 mov rdx,rbx
 call compact
 add edi,16
 cmp edi,0x160
 jb cleanup_next
 lea rcx,[rsi+0x1f0]
 mov rdx,rbx
 call compact
 lea rcx,[rsi+0x200]
 mov rdx,rbx
 call compact
cleanup_end:
 add rsp,32
 pop rdi
 pop rsi
 pop rbx
 ret

# Stable compact FScriptDelegate[16]. Retain capacity and other screens' bindings.
# RCX=&invocation array, RDX=closed screen. No allocations and no delegate broadcasts.
compact:
 push rbx
 push rsi
 push rdi
 push r12
 push r13
 push r14
 push r15
 sub rsp,32
 mov rbx,rcx
 mov r12,rdx
 mov rsi,QWORD PTR [rcx]
 mov r13d,DWORD PTR [rcx+8]
 test rsi,rsi
 jz compact_end
 test r13d,r13d
 jle compact_end
 cmp r13d,4096
 ja compact_end
 cmp r13d,DWORD PTR [rcx+12]
 ja compact_end
 xor edi,edi
 xor r14d,r14d
compact_next:
 mov r15d,edi
 shl r15,4
 lea rcx,[rsi+r15]
 call QWORD PTR [rip+weak_get]
 test rax,rax
 jz compact_drop
 mov ecx,64
compact_outer:
 cmp rax,r12
 je compact_drop
 mov rax,QWORD PTR [rax+0x20]
 test rax,rax
 jz compact_keep
 dec ecx
 jnz compact_outer
compact_keep:
 mov rax,QWORD PTR [rsi+r15]
 mov rdx,QWORD PTR [rsi+r15+8]
 mov r10d,r14d
 shl r10,4
 mov QWORD PTR [rsi+r10],rax
 mov QWORD PTR [rsi+r10+8],rdx
 inc r14d
compact_drop:
 inc edi
 cmp edi,r13d
 jb compact_next
 mov DWORD PTR [rbx+8],r14d
compact_end:
 add rsp,32
 pop r15
 pop r14
 pop r13
 pop r12
 pop rdi
 pop rsi
 pop rbx
 ret

.global background_fallback
background_fallback:
 cmp QWORD PTR [rsi+0x10],0
 je missing_background
 push rax
 mov rax,QWORD PTR [rip+log_verbosity]
 cmp BYTE PTR [rax],bpl
 pop rax
 jmp QWORD PTR [rip+background_continue]
missing_background:
 jmp QWORD PTR [rip+background_skip]
# RDX = current FDateTime*, R8 = start output*, R9 = end output*.
# Cache only date boundaries, not the countdown, rewards, or mutable progress.
.global season_dates,season_original,season_cache
season_dates:
 xor eax,eax
 mov r11d,1
 lock cmpxchg DWORD PTR [rip+season_cache],r11d
 jne season_original
 push rbx
 push rsi
 push rdi
 push r12
 push r13
 sub rsp,32
 mov rbx,rcx
 mov rsi,rdx
 mov rdi,r8
 mov r12,r9
 mov r13,QWORD PTR [rdx]
 lea rcx,[rbx+0x428]
 call QWORD PTR [rip+weak_get]
 test rax,rax
 jz season_uncached
 mov r10,rax
 cmp DWORD PTR [rip+season_cache+4],1
 jne season_miss
 cmp QWORD PTR [rip+season_cache+8],rbx
 jne season_miss
 mov rax,QWORD PTR [rbx+0x428]
 cmp QWORD PTR [rip+season_cache+16],rax
 jne season_miss
 mov rax,QWORD PTR [rbx+0x648]
 cmp QWORD PTR [rip+season_cache+24],rax
 jne season_miss
 mov eax,DWORD PTR [rbx+0x650]
 cmp DWORD PTR [rip+season_cache+32],eax
 jne season_miss
 mov rax,QWORD PTR [r10+0x1b4]
 cmp QWORD PTR [rip+season_cache+40],rax
 jne season_miss
 mov rax,QWORD PTR [r10+0x1bc]
 cmp QWORD PTR [rip+season_cache+48],rax
 jne season_miss
 mov eax,DWORD PTR [r10+0x1d0]
 cmp DWORD PTR [rip+season_cache+56],eax
 jne season_miss
 mov rax,QWORD PTR [r10+0x1c8]
 cmp QWORD PTR [rip+season_cache+64],rax
 jne season_miss
 mov rax,r13
 sub rax,QWORD PTR [rip+season_cache+72]
 jc season_miss
 cmp rax,600000000
 jae season_miss
 cmp r13,QWORD PTR [rip+season_cache+80]
 jl season_miss
 cmp r13,QWORD PTR [rip+season_cache+88]
 jge season_miss
 mov rax,QWORD PTR [rip+season_cache+80]
 mov QWORD PTR [rdi],rax
 mov rax,QWORD PTR [rip+season_cache+88]
 mov QWORD PTR [r12],rax
 inc QWORD PTR [rip+season_cache+104]
 mov eax,1
 jmp season_return
season_miss:
 mov DWORD PTR [rip+season_cache+4],0
 mov QWORD PTR [rip+season_cache+8],rbx
 mov rax,QWORD PTR [rbx+0x428]
 mov QWORD PTR [rip+season_cache+16],rax
 mov rax,QWORD PTR [rbx+0x648]
 mov QWORD PTR [rip+season_cache+24],rax
 mov eax,DWORD PTR [rbx+0x650]
 mov DWORD PTR [rip+season_cache+32],eax
 mov rax,QWORD PTR [r10+0x1b4]
 mov QWORD PTR [rip+season_cache+40],rax
 mov rax,QWORD PTR [r10+0x1bc]
 mov QWORD PTR [rip+season_cache+48],rax
 mov eax,DWORD PTR [r10+0x1d0]
 mov DWORD PTR [rip+season_cache+56],eax
 mov rax,QWORD PTR [r10+0x1c8]
 mov QWORD PTR [rip+season_cache+64],rax
 mov rcx,rbx
 mov rdx,rsi
 mov r8,rdi
 mov r9,r12
 call season_original
 inc QWORD PTR [rip+season_cache+112]
 test al,al
 jz season_return
 mov r10,QWORD PTR [rdi]
 mov r11,QWORD PTR [r12]
 test r10,r10
 jle season_return
 cmp r10,r11
 jge season_return
 cmp r13,r10
 jl season_return
 cmp r13,r11
 jge season_return
 mov QWORD PTR [rip+season_cache+80],r10
 mov QWORD PTR [rip+season_cache+88],r11
 mov QWORD PTR [rip+season_cache+72],r13
 mov DWORD PTR [rip+season_cache+4],1
 jmp season_return
season_uncached:
 mov DWORD PTR [rip+season_cache+4],0
 mov rcx,rbx
 mov rdx,rsi
 mov r8,rdi
 mov r9,r12
 call season_original
season_return:
 mov DWORD PTR [rip+season_cache],0
 add rsp,32
 pop r13
 pop r12
 pop rdi
 pop rsi
 pop rbx
 ret
season_original:
 mov QWORD PTR [rsp+0x18],rbx
 jmp QWORD PTR [rip+season_body]
# UI-only safety bound: at most 52 empty weekly header groups.
# Saved challenge groups are inserted by the original loop after these placeholders.
.global menu_week_count
menu_week_count:
 sub rsp,40
 call QWORD PTR [rip+total_week_count]
 mov ecx,52
 cmp eax,ecx
 cmovg eax,ecx
 add rsp,40
 ret

.global panel_refresh
panel_refresh:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz panel_refresh_closed
 .byte 0x40,0x57,0x41,0x54,0x48,0x81,0xec,0x88,0x1,0x0,0x0
 jmp QWORD PTR [rip+panel_refresh_return]
panel_refresh_closed:
 ret

.global journal_cta
journal_cta:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz journal_cta_closed
 .byte 0x48,0x89,0x5c,0x24,0x8
 jmp QWORD PTR [rip+journal_cta_return]
journal_cta_closed:
 ret

.global selection_assets
selection_assets:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz selection_assets_closed
 .byte 0x48,0x89,0x5c,0x24,0x10
 jmp QWORD PTR [rip+selection_assets_return]
selection_assets_closed:
 ret

.global selection_draft
selection_draft:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz selection_draft_closed
 .byte 0x40,0x53,0x56,0x48,0x81,0xec,0x88,0x0,0x0,0x0
 jmp QWORD PTR [rip+selection_draft_return]
selection_draft_closed:
 ret

.global panel_assets
panel_assets:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz panel_assets_closed
 .byte 0x48,0x89,0x5c,0x24,0x10
 jmp QWORD PTR [rip+panel_assets_return]
panel_assets_closed:
 ret

.global draft_timeout
draft_timeout:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz draft_timeout_closed
 .byte 0x48,0x89,0x5c,0x24,0x10
 jmp QWORD PTR [rip+draft_timeout_return]
draft_timeout_closed:
 ret

.global huntpass_progress
huntpass_progress:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz huntpass_progress_closed
 .byte 0x40,0x53,0x57,0x48,0x81,0xec,0x8,0x2,0x0,0x0
 jmp QWORD PTR [rip+huntpass_progress_return]
huntpass_progress_closed:
 ret

.global objective_legend
objective_legend:
 push rcx
 push rdx
 push r8
 push r9
 sub rsp,40
 call closed
 add rsp,40
 pop r9
 pop r8
 pop rdx
 pop rcx
 test al,al
 jnz objective_legend_closed
 .byte 0x48,0x89,0x5c,0x24,0x18
 jmp QWORD PTR [rip+objective_legend_return]
objective_legend_closed:
 ret

.balign 8
.global total_week_count
total_week_count: .quad 0
.global season_body
season_body: .quad 0
.global log_verbosity
log_verbosity: .quad 0
.global background_continue
background_continue: .quad 0
.global background_skip
background_skip: .quad 0
.global screen_class
screen_class: .quad 0
.global base_destruct
base_destruct: .quad 0
.global weak_get
weak_get: .quad 0
.global panel_refresh_return
panel_refresh_return: .quad 0
.global journal_cta_return
journal_cta_return: .quad 0
.global selection_assets_return
selection_assets_return: .quad 0
.global selection_draft_return
selection_draft_return: .quad 0
.global panel_assets_return
panel_assets_return: .quad 0
.global draft_timeout_return
draft_timeout_return: .quad 0
.global huntpass_progress_return
huntpass_progress_return: .quad 0
.global objective_legend_return
objective_legend_return: .quad 0

.org 4096
.global season_cache
season_cache: .zero 128
