# Power surge saving

Adds the missing native POST /inventory/instanceditem save route. Saves the item data and version for the existing equipment instance; identical replays are accepted, stale/conflicting versions rejected and failed writes rolled back.

Includes the final equipment-save fix originally supplied with Bounties Fix2. The consolidation keeps it in its own source folder.

**Validation and limits:** Power surge was confirmed working. Automated tests cover saved item data, replay, stale updates, ownership and restart.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
