# RDX = current FDateTime*, R8 = start output*, R9 = end output*.
# Cache only date boundaries, not the countdown, rewards, or mutable progress.
.global season_dates,season_original,season_cache
season_dates:
 xor eax,eax
 mov r11d,1
 lock cmpxchg DWORD PTR [rip+season_cache],r11d
 jne season_original
 push rbx
 push rsi
 push rdi
 push r12
 push r13
 sub rsp,32
 mov rbx,rcx
 mov rsi,rdx
 mov rdi,r8
 mov r12,r9
 mov r13,QWORD PTR [rdx]
 lea rcx,[rbx+0x428]
 call QWORD PTR [rip+weak_get]
 test rax,rax
 jz season_uncached
 mov r10,rax
 cmp DWORD PTR [rip+season_cache+4],1
 jne season_miss
 cmp QWORD PTR [rip+season_cache+8],rbx
 jne season_miss
 mov rax,QWORD PTR [rbx+0x428]
 cmp QWORD PTR [rip+season_cache+16],rax
 jne season_miss
 mov rax,QWORD PTR [rbx+0x648]
 cmp QWORD PTR [rip+season_cache+24],rax
 jne season_miss
 mov eax,DWORD PTR [rbx+0x650]
 cmp DWORD PTR [rip+season_cache+32],eax
 jne season_miss
 mov rax,QWORD PTR [r10+0x1b4]
 cmp QWORD PTR [rip+season_cache+40],rax
 jne season_miss
 mov rax,QWORD PTR [r10+0x1bc]
 cmp QWORD PTR [rip+season_cache+48],rax
 jne season_miss
 mov eax,DWORD PTR [r10+0x1d0]
 cmp DWORD PTR [rip+season_cache+56],eax
 jne season_miss
 mov rax,QWORD PTR [r10+0x1c8]
 cmp QWORD PTR [rip+season_cache+64],rax
 jne season_miss
 mov rax,r13
 sub rax,QWORD PTR [rip+season_cache+72]
 jc season_miss
 cmp rax,600000000
 jae season_miss
 cmp r13,QWORD PTR [rip+season_cache+80]
 jl season_miss
 cmp r13,QWORD PTR [rip+season_cache+88]
 jge season_miss
 mov rax,QWORD PTR [rip+season_cache+80]
 mov QWORD PTR [rdi],rax
 mov rax,QWORD PTR [rip+season_cache+88]
 mov QWORD PTR [r12],rax
 inc QWORD PTR [rip+season_cache+104]
 mov eax,1
 jmp season_return
season_miss:
 mov DWORD PTR [rip+season_cache+4],0
 mov QWORD PTR [rip+season_cache+8],rbx
 mov rax,QWORD PTR [rbx+0x428]
 mov QWORD PTR [rip+season_cache+16],rax
 mov rax,QWORD PTR [rbx+0x648]
 mov QWORD PTR [rip+season_cache+24],rax
 mov eax,DWORD PTR [rbx+0x650]
 mov DWORD PTR [rip+season_cache+32],eax
 mov rax,QWORD PTR [r10+0x1b4]
 mov QWORD PTR [rip+season_cache+40],rax
 mov rax,QWORD PTR [r10+0x1bc]
 mov QWORD PTR [rip+season_cache+48],rax
 mov eax,DWORD PTR [r10+0x1d0]
 mov DWORD PTR [rip+season_cache+56],eax
 mov rax,QWORD PTR [r10+0x1c8]
 mov QWORD PTR [rip+season_cache+64],rax
 mov rcx,rbx
 mov rdx,rsi
 mov r8,rdi
 mov r9,r12
 call season_original
 inc QWORD PTR [rip+season_cache+112]
 test al,al
 jz season_return
 mov r10,QWORD PTR [rdi]
 mov r11,QWORD PTR [r12]
 test r10,r10
 jle season_return
 cmp r10,r11
 jge season_return
 cmp r13,r10
 jl season_return
 cmp r13,r11
 jge season_return
 mov QWORD PTR [rip+season_cache+80],r10
 mov QWORD PTR [rip+season_cache+88],r11
 mov QWORD PTR [rip+season_cache+72],r13
 mov DWORD PTR [rip+season_cache+4],1
 jmp season_return
season_uncached:
 mov DWORD PTR [rip+season_cache+4],0
 mov rcx,rbx
 mov rdx,rsi
 mov r8,rdi
 mov r9,r12
 call season_original
season_return:
 mov DWORD PTR [rip+season_cache],0
 add rsp,32
 pop r13
 pop r12
 pop rdi
 pop rsi
 pop rbx
 ret
season_original:
 mov QWORD PTR [rsp+0x18],rbx
 jmp QWORD PTR [rip+season_body]
