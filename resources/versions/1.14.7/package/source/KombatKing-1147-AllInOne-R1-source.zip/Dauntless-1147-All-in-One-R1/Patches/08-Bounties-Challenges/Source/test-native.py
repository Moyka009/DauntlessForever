from pathlib import Path
import ctypes as c,json,mmap,struct
root=Path(__file__).resolve().parents[1];spec=json.loads((root/'Source/menu-repair1147.json').read_text());hold=[];checks=0
def alloc(size=0x900):
 b=c.create_string_buffer(size);hold.append(b);return c.addressof(b)
def q(a,v):c.c_uint64.from_address(a).value=v
def d(a,v):c.c_int32.from_address(a).value=v
def obj(cls=0,outer=0,closed=0):
 a=alloc();q(a+0x10,cls);q(a+0x20,outer);c.c_uint8.from_address(a+0x3d0).value=closed;return a
def bridge(mem,off,target):
 # SysV four-argument entry -> Windows ABI and shadow space.
 code=bytes.fromhex('4989c94989d04889f24889f94883ec28')+b'\xe8'+struct.pack('<i',target-off-21)+bytes.fromhex('4883c428c3')
 mem[off:off+len(code)]=code
for run in range(3):
 mem=mmap.mmap(-1,0x8000000,prot=7);base=c.addressof(c.c_char.from_buffer(mem));stub=0x7000000;code=bytearray.fromhex(spec['code'])
 for f in spec['fixups']:struct.pack_into('<Q',code,f['offset'],base+f['rva'])
 mem[stub:stub+len(code)]=code
 screenclass=obj();derived=obj();q(derived+0x40,screenclass);otherclass=obj();q(base+0x6d625b8,screenclass)
 screen=obj(derived);tree=obj(otherclass,screen);panel=obj(otherclass,tree)
 for i,p in enumerate(spec['patches'][:8]):
  name=p['name'];start=stub+spec['symbols'][name];r=p['rva']+len(bytes.fromhex(p['before']))
  # Original function remainder checks that all integer arguments survive the guard.
  undo={'panel_refresh':'4881c488010000415c5f','selection_draft':'4881c4880000005e5b','huntpass_progress':'4881c4080200005f5b'}.get(name,'')
  sentinel=bytes.fromhex(undo+'4889d04c01c04c01c8c3');mem[r:r+len(sentinel)]=sentinel
  entry=0x1000+i*0x100;bridge(mem,entry,start);f=c.CFUNCTYPE(c.c_uint64,c.c_void_p,c.c_uint64,c.c_uint64,c.c_uint64)(base+entry)
  assert f(panel,123,456,789)==1368;checks+=1
  c.c_uint8.from_address(screen+0x3d0).value=1;assert f(panel,123,456,789)==1;checks+=1 # AL indicates closed; void callback return is ignored.
  c.c_uint8.from_address(screen+0x3d0).value=0;assert f(panel,123,456,789)==1368;checks+=1
  q(base+0x6d625b8,0);assert f(panel,123,456,789)==1368;checks+=1;q(base+0x6d625b8,screenclass)
  del f
 # Stand-ins for the two verified native helpers. Get resolves a synthetic weak ref.
 mem[0x287aa20:0x287aa24]=bytes.fromhex('488b01c3')
 mem[0x1e4c030:0x1e4c038]=bytes.fromhex('c681d003000001c3')
 component=alloc();q(screen+0x530,component)
 live=obj(derived);child=obj(otherclass,tree);cycle=obj(otherclass);q(cycle+0x20,cycle)
 entries=[(live,10),(screen,20),(child,30),(0,40),(cycle,50),(live,60)]
 arrays=[]
 for off in list(range(0xe0,0x160,16))+[0x1f0,0x200]:
  a=alloc(16*len(entries));arrays.append(a)
  for i,(o,n) in enumerate(entries):q(a+i*16,o);q(a+i*16+8,n)
  q(component+off,a);d(component+off+8,len(entries));d(component+off+12,len(entries))
 bridge(mem,0x3000,stub+spec['symbols']['cleanup']);f=c.CFUNCTYPE(None,c.c_void_p)(base+0x3000);f(screen)
 assert c.c_uint8.from_address(screen+0x3d0).value==1;checks+=1
 for off,a in zip(list(range(0xe0,0x160,16))+[0x1f0,0x200],arrays):
  assert c.c_int32.from_address(component+off+8).value==3
  assert [c.c_uint64.from_address(a+i*16+8).value for i in range(3)]==[10,50,60]
  assert c.c_int32.from_address(component+off+12).value==6;checks+=1
 f(screen);assert c.c_int32.from_address(component+0xe8).value==3;checks+=1
 q(screen+0x530,0);f(screen);checks+=1;del f
 # Empty paths retain the existing brush; valid pending paths retain native load behavior.
 mem[0x1fa95f2:0x1fa95f8]=bytes.fromhex('b864000000c3')
 normal=bytes.fromhex('0f92c00fb6c005c8000000c3');mem[0x1fa947a:0x1fa947a+len(normal)]=normal
 target=stub+spec['symbols']['background_fallback'];off=0x4000
 pro=bytes.fromhex('55bd030000004883ec20')
 wrapper=pro+b'\xe8'+struct.pack('<i',target-off-len(pro)-5)+bytes.fromhex('4883c4205dc3')
 mem[off:off+len(wrapper)]=wrapper
 f=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_void_p)(base+off);soft=alloc()
 assert f(0,soft)==100;checks+=1
 q(soft+0x10,12345);c.c_uint8.from_address(base+0x6d286d0).value=2
 assert f(0,soft)==201;checks+=1
 c.c_uint8.from_address(base+0x6d286d0).value=5;assert f(0,soft)==200;checks+=1;del f

 # Cache tests execute the actual new native code with native clock/pass stand-ins.
 owner=obj(derived);hp=alloc();q(owner+0x428,hp);q(owner+0x648,123);d(owner+0x650,7)
 q(hp+0x1b4,1);q(hp+0x1bc,2);d(hp+0x1d0,3);q(hp+0x1c8,99999)
 q(owner+0x700,1);q(owner+0x708,10000000000000);c.c_uint8.from_address(owner+0x710).value=1
 # Native function body preserves the displaced prologue's ABI and supplies exact dates.
 fake=bytes.fromhex('488b8100070000498900488b810807000049890148ff81180700000fb68110070000c3')
 mem[0x1a0bf95:0x1a0bf95+len(fake)]=fake
 bridge(mem,0x5000,stub+spec['symbols']['season_dates'])
 f=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_void_p,c.c_void_p,c.c_void_p)(base+0x5000)
 now=alloc();begin=alloc();end=alloc();q(now,10000)
 def calls():return c.c_uint64.from_address(owner+0x718).value
 def query():
  assert f(owner,now,begin,end)&255==1
  assert c.c_uint64.from_address(begin).value==c.c_uint64.from_address(owner+0x700).value
  assert c.c_uint64.from_address(end).value==c.c_uint64.from_address(owner+0x708).value
 query();assert calls()==1;checks+=1
 for i in range(200):q(now,10000+i);query()
 assert calls()==1;checks+=1
 # Each mutable source field invalidates immediately.
 for address in [hp+0x1b4,hp+0x1bc,hp+0x1c8,owner+0x648]:
  old=c.c_uint64.from_address(address).value;q(address,old+1);n=calls();query();assert calls()==n+1;checks+=1
 for address in [hp+0x1d0,owner+0x650]:
  old=c.c_int32.from_address(address).value;d(address,old+1);n=calls();query();assert calls()==n+1;checks+=1
 n=calls();q(now,700000000);query();assert calls()==n+1;checks+=1
 n=calls();q(now,600000000);query();assert calls()==n+1;checks+=1
 # Contention bypasses cache instead of waiting or deadlocking.
 cache=base+stub+spec['symbols']['season_cache'];d(cache,1);n=calls();query();assert calls()==n+1 and c.c_int32.from_address(cache).value==1;checks+=1;d(cache,0)
 # No live Hunt Pass component: original fallback always runs.
 q(owner+0x428,0);n=calls();query();query();assert calls()==n+2;checks+=1;q(owner+0x428,hp)
 # A failed native query is never turned into a successful cached result.
 c.c_uint8.from_address(owner+0x710).value=0;d(hp+0x1d0,100);n=calls()
 assert f(owner,now,begin,end)&255==0
 assert f(owner,now,begin,end)&255==0
 assert calls()==n+2;checks+=1
 c.c_uint8.from_address(owner+0x710).value=1
 # Crossing the cached season end invalidates despite unexpired TTL.
 q(owner+0x708,600000001);d(hp+0x1d0,101);query();n=calls();q(now,600000002);query();assert calls()==n+1;checks+=1
 del f
 # Execute the local menu-only 52-week bound through the same Windows ABI.
 fake_count=bytes.fromhex('8b810007000048ff8118070000c3');mem[0x1a04f60:0x1a04f60+len(fake_count)]=fake_count
 bridge(mem,0x6000,stub+spec['symbols']['menu_week_count'])
 count_query=c.CFUNCTYPE(c.c_int32,c.c_void_p)(base+0x6000)
 for total in [-1,0,1,12,13,14,52,53,3767,4122,2147483647]:
  for limit in [0,13,52]:
   d(owner+0x700,total);d(owner+0x670,limit);q(owner+0x718,0)
   wanted=min(total,52)
   assert count_query(owner)==wanted,(total,limit)
   assert c.c_uint64.from_address(owner+0x718).value==1
   checks+=1
 del count_query
 mem.close()
print(json.dumps({'passed':checks,'failed':0,'x64_code':'executed at three allocated bases','windows_and_gameplay':'not executed'}))
