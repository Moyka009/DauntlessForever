// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one Hunt Pass anchor: '+a.slice(0,90));return s.replace(a,b);}
function patch(bytes){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 const a="const trials1147 = require('./trials1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,next:c=>middleman1147.handle(c)});";
 s=once(s,a,a+"\nconst huntpass1147 = require('./huntpass1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,loadCapture,next:c=>trials1147.handle(c)});");s=once(s,'reply = trials1147.handle(','reply = huntpass1147.handle(');s=once(s,"note:'trials1147: '+e.message","note:'huntpass1147: '+e.message");
 s=once(s,'function applyInventory(inv, body) {','function applyInventory(inv, body) {\n  body = huntpass1147.inventory(inv, body);');
 const start=s.indexOf('function grantProgress(c) {'),end=s.indexOf('function saveBounties(c) {');if(start<0||end<=start)throw Error('Missing progression functions');let functions=s.slice(start,end);
 functions=once(functions,"c.body && typeof c.body === 'object' ? c.body : {}","huntpass1147.progressBody(c.body && typeof c.body === 'object' ? c.body : {})");
 functions=once(functions,'function grantProgress(c) {','function grantProgressNative(c) {');
 functions=once(functions,'saveState();\n  return J(wrapped({ progress_tracks: tracks, objectives }),','huntpass1147.settle(p); saveState();\n  return J(wrapped({ progress_tracks: tracks.map(t=>trackOut(p,t.progression_id,p.progress.tracks[t.progression_id])), objectives }),');
 functions=once(functions,'function grantTrack(c) {','function grantTrackNative(c) {');
 functions=once(functions,'const id = decodeURIComponent(c.match[1]);','const id = decodeURIComponent(c.match[1]);\n  huntpass1147.assertDelta(id, Number(c.match[2]));');
 functions=once(functions,' saveState();\n  return J(wrapped(trackOut(p, id, cur)),',' huntpass1147.settle(p); saveState();\n  return J(wrapped(trackOut(p, id, cur)),');
 functions+="function grantProgress(c) { const p=playerFor(c.req); return huntpass1147.atomic(p,()=>grantProgressNative(c)); }\nfunction grantTrack(c) { const p=playerFor(c.req); return huntpass1147.atomic(p,()=>grantTrackNative(c)); }\n";
 s=s.slice(0,start)+functions+s.slice(end);return Buffer.from(s.replaceAll('\n',nl));
}
module.exports={patch};
