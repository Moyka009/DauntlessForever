import os
# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import json,hashlib,collections
ROOT=Path(__file__).resolve().parents[1];WORK=Path(os.environ.get('DAUNTLESS_REFERENCE_WORKSPACE',str(ROOT.parents[2])))
SRC=WORK/'audit/inspected/1.6.2/1.6.2/seasons';OUT=ROOT/'Source/seasons'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
catfile=ROOT.parent/'02-Inventory-Search/Source/catalog-1147.json';cat={i['id']:i for i in json.loads(catfile.read_text())['items']}
index=json.loads((SRC/'index.json').read_text());entries=[];audit=[]
mega=json.loads((ROOT/'Source/huntpass1147-data.json').read_text());mega.update(key='mega',title='Mega Hunt Pass',kind='mega');(OUT/'mega.json').write_text(json.dumps(mega,indent=2,ensure_ascii=False)+'\n')
entries.append({'key':'mega','title':'Mega Hunt Pass','kind':'mega','levels':400,'file':'mega.json','doc':'docs/mega.md','save_key':'mega','xp_per_level':100})
rows=['# Mega Hunt Pass','', '400 tiers. All 2,997 cosmetic-marked items in the 1.14.7 catalog occur once.','Both tracks unlocked. 100 XP per tier. Existing Mega XP is preserved.','Five-dye packs and matching armour sets keep each tier to at most six cards.','','| Tier | Rewards |','| --- | --- |']
for rank,ids in mega['rewards'].items():
 labels=[]
 for i in ids:labels.append(mega['bundle_names'][i]['name'] if i in mega['bundles'] else mega['items'][i]['name'] or i)
 rows.append('| '+rank+' | '+'; '.join(s.replace('|','/') for s in labels)+' |')
(OUT/'docs/mega.md').write_text('\n'.join(rows)+'\n')
for entry in index['seasons']:
 if entry['kind']=='mega':continue
 src=SRC/entry['file'];original=json.loads(src.read_text());key=entry['key'];items={};grants={};omitted=[];cards=0
 assert original['xp_per_level']==100 and not original.get('xp_curve')
 docs=['# '+entry['title'],'','1.14.7 clone of the 1.6.2 '+entry['kind']+' pass. Original tier order and quantities are retained.','Both tracks unlocked automatically. Progress is saved separately for this season.','The in-game heading says Hunt Pass Seasons; levels and rewards follow the launcher selection.','','| Tier | Free rewards | Premium rewards |','| --- | --- | --- |']
 for rank in range(1,entry['levels']+1):
  orig=original['rewards'].get(str(rank),{});row={};labels={}
  for track in ['free','premium']:
   row[track]=[];labels[track]=[]
   for id,qty in orig.get(track,[]):
    assert isinstance(qty,int) and qty>0
    if id not in cat:
     omitted.append({'rank':rank,'track':track,'catalog_id':id,'quantity':qty});labels[track].append('Unavailable in 1.14.7: '+id);continue
    i=cat[id];items[id]={'kind':i['storage'],'name':i['name'],'source':i['source'],'cosmetic':bool(i.get('cosmetic'))};row[track].append([id,qty]);cards+=1;labels[track].append((i['name'] or id)+' x'+str(qty))
  grants[str(rank)]=row;docs.append('| '+str(rank)+' | '+'; '.join(labels['free']).replace('|','/')+' | '+'; '.join(labels['premium']).replace('|','/')+' |')
 data={'revision':'season1147-'+key+'-v1','pass_id':'season27','key':key,'title':entry['title'],'kind':entry['kind'],'levels':entry['levels'],'xp_per_level':100,'start_date':'2020-01-01T00:00:00+00:00','end_date':'2099-01-01T00:00:00+00:00','items':items,'bundles':{},'bundle_names':{},'rewards':{rank:[i for t in ['free','premium'] for i,q in row[t]] for rank,row in grants.items()},'grants':grants,'unavailable_rewards':omitted,'source':{'game':'1.6.2 layout; 1.14.7 item catalog','file':src.name,'sha256':sha(src)}}
 (OUT/(key+'.json')).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n');(OUT/'docs'/(key+'.md')).write_text('\n'.join(docs)+'\n')
 entries.append({'key':key,'title':entry['title'],'kind':entry['kind'],'levels':entry['levels'],'file':key+'.json','doc':'docs/'+key+'.md','save_key':key,'xp_per_level':100})
 audit.append({'key':key,'levels':entry['levels'],'source_sha256':sha(src),'grantable_reward_entries':cards,'unavailable_rewards':omitted})
assert len(entries)==36 and len(audit)==35 and collections.Counter(x['kind'] for x in entries)=={'mega':1,'original':10,'reimagined':11,'vault':8,'event':6}
(OUT/'index.json').write_text(json.dumps({'default':'mega','game':'1.14.7 CL647472','seasons':entries},indent=2)+'\n')
(ROOT/'Source/season-audit.json').write_text(json.dumps({'catalog_sha256':sha(catfile),'total_seasons':36,'kinds':dict(collections.Counter(x['kind'] for x in entries)),'mega_cosmetics':2997,'clones':audit},indent=2)+'\n')
print(json.dumps({'seasons':36,'clones':35,'kinds':dict(collections.Counter(x['kind'] for x in entries)),'unavailable_unique_ids':sorted({i['catalog_id'] for x in audit for i in x['unavailable_rewards']})}))
