// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one equipment route anchor: '+a);return s.replace(a,b);}
function patch(bytes){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 const next=s.includes('const bounties1147 =')?'bounties1147':'huntpass1147';
 const anchor='// ---------------------------------------------------------------- HTTP';
 const declaration="const equipment1147 = require('./equipment1147').create({playerFor,bearerOf,sessions,getPlayers:()=>Object.values(state.players||{}),saveState,next:c=>"+next+".handle(c)});\n";
 // Insert directly before the reply dispatch, after every previous module is initialized.
 const marker=next==='bounties1147'?"const bounties1147 = require('./bounties1147').create({playerFor,bearerOf,sessions,getPlayers:()=>Object.values(state.players||{}),saveState,loadCapture,next:c=>huntpass1147.handle(c)});":"const huntpass1147 = require('./huntpass1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,loadCapture,next:c=>trials1147.handle(c)}, {data:huntpassSeasons1147.data,seasons:huntpassSeasons1147});";
 s=once(s,marker,marker+'\n'+declaration);s=once(s,'reply = '+next+'.handle(','reply = equipment1147.handle(');return Buffer.from(s.replaceAll('\n',nl));
}
module.exports={patch};
