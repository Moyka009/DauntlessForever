# UI-only safety bound: at most 52 empty weekly header groups.
# Saved challenge groups are inserted by the original loop after these placeholders.
.global menu_week_count
menu_week_count:
 sub rsp,40
 call QWORD PTR [rip+total_week_count]
 mov ecx,52
 cmp eax,ecx
 cmovg eax,ecx
 add rsp,40
 ret
