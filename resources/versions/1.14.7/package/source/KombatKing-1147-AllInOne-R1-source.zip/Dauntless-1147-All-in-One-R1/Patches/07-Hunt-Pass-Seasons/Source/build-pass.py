import os
# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import json,struct,hashlib,random,re,collections,sys,datetime
from equipment_asset import Asset
WORKSPACE=Path(os.environ.get('DAUNTLESS_REFERENCE_WORKSPACE',str(Path(__file__).resolve().parents[4])))
ROOT=Path(__file__).resolve().parents[1]
ASSETS=WORKSPACE/'game_rules1147_work/assets'
OUT=WORKSPACE/'huntpass1147_work/pak'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fstring(s):
 if s.isascii():
  b=s.encode('ascii')+b'\0';return struct.pack('<i',len(b))+b
 b=s.encode('utf-16le')+b'\0\0';return struct.pack('<i',-(len(b)//2))+b
def text(s,key):return struct.pack('<Ib',0,0)+fstring('Mega1147')+fstring(key)+fstring(s)
def entries(a):
 pos,_=a.properties(a.exports[0]['start']);assert struct.unpack_from('<I',a.b,pos)[0]==0;count_at=pos+4;count=struct.unpack_from('<I',a.b,count_at)[0];pos=count_at+4;rows=[]
 for _ in range(count):
  start=pos;name,pos=a.name(pos);props=pos;pos,_=a.properties(pos);rows.append((name,a.b[start:props],props,pos))
 assert pos==len(a.b)-4
 return count_at,rows

def rewrite(a,start,end,values):
 out=bytearray();pos=start
 while pos<end:
  at=pos;t=a.tag(pos);pos=t['end'];raw=a.b[at:pos]
  if t['name'] not in values:out.extend(raw);continue
  value=values[t['name']];header=bytearray(a.b[at:t['start']])
  if t['type']=='BoolProperty':assert t['size']==0;header[24]=int(value);payload=b''
  elif t['type']=='TextProperty':payload=text(value,'hp400_'+t['name']+'_'+hashlib.sha1(value.encode()).hexdigest()[:12])
  elif t['type']=='IntProperty':payload=struct.pack('<i',value)
  elif t['type']=='StrProperty':payload=fstring(value)
  elif t['type']=='StructProperty' and t['struct']=='DateTime':payload=struct.pack('<q',value)
  else:raise AssertionError(t)
  struct.pack_into('<I',header,16,len(payload));out.extend(header);out.extend(payload)
 return bytes(out)

def write_table(a,count_at,rows,relative):
 b=a.b[:count_at]+struct.pack('<I',len(rows))+b''.join(rows)+a.b[-4:];u=bytearray(a.ua);n,at=struct.unpack_from('<II',u,57);assert n==1
 assert struct.unpack_from('<q',u,169)[0]==len(a.ua)+len(a.b)-4
 struct.pack_into('<q',u,at+28,len(b)-4);struct.pack_into('<q',u,169,len(u)+len(b)-4)
 dst=OUT/relative;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(u);dst.with_suffix('.uexp').write_bytes(b)
 checked=Asset(dst);_,check_rows=entries(checked);assert len(check_rows)==len(rows)
 return checked

EXPECTED={'Archon/Content/Gameplay/Backend/Catalogs/containers_storeoffers_cores.uasset': '8e0388ce4c02701470b43c3ab6192115b2114c07dbeeba13660a430709688793', 'Archon/Content/Gameplay/Backend/Catalogs/containers_storeoffers_cores.uexp': 'd8415f22a064d76e6c58d6c15e45973f8cda5486d2257faaf6248772a7642024', 'Archon/Content/Gameplay/hunt_pass/hunt_pass_season_table.uasset': '805f65b9ebea1da8886daafe4a0eb4318d993e438d506605a4bc66613fbbf57d', 'Archon/Content/Gameplay/hunt_pass/hunt_pass_season_table.uexp': '881a388e1f9de37974c7ecd13e8083574c7f096bb2fd944d2d72c0f3c80d6f58'}
for relative_path,digest in EXPECTED.items():
 assert sha(ASSETS/relative_path)==digest, 'Not the verified 1.14.7 asset: '+relative_path

catfile=ROOT.parent/'02-Inventory-Search/Source/catalog-1147.json'
cat=json.loads(catfile.read_text());items=sorted((x for x in cat['items'] if x.get('cosmetic')),key=lambda x:x['id']);byid={i['id']:i for i in items};assert len(items)==len(byid)==2997
used=set();cards=[];bundles={};bundle_names={}
def add_pack(members,label,kind):
 assert members and len(members)==len(set(members))
 for item in members:assert item not in used;used.add(item)
 alias='CONTAINER_1P_UNSEEN_ARMOUR_'+str(647472001+len(bundles));bundles[alias]=members;bundle_names[alias]={'name':label,'kind':kind};cards.append(alias)

dyes=[x['id'] for x in items if x['source']=='dyes_item_catalog.uasset'];assert len(dyes)==475
for at in range(0,len(dyes),5):add_pack(dyes[at:at+5],'Five Dyes — Set '+str(at//5+1),'dyes')
sets=collections.defaultdict(list)
for i in items:
 if i['source']=='Gear_Catalogs/armour_cosmetic_catalog.uasset':sets[re.sub(r'_(HELM|CHEST|ARMS|LEGS)(?=_|$)','_SLOT',i['id'])].append(i['id'])
for key,members in sorted(sets.items()):
 if len(members)>1:
  base=key.removeprefix('AR_').replace('_SLOT','').replace('_',' ').title();add_pack(members,base+' — '+str(len(members))+' armour pieces','armour')
for i in items:
 if i['id'] not in used:cards.append(i['id']);used.add(i['id'])
assert used==set(byid) and len(cards)==2339 and len(bundles)==207
random.Random(647472).shuffle(cards)
rewards={str(n):[] for n in range(1,401)}
for n,card in enumerate(cards):rewards[str(n*400//len(cards)+1)].append(card)
assert all(1<=len(v)<=6 for v in rewards.values())
expanded=[i for row in rewards.values() for card in row for i in bundles.get(card,[card])];assert len(expanded)==len(set(expanded))==2997 and set(expanded)==set(byid)

relative='Archon/Content/Gameplay/Backend/Catalogs/containers_storeoffers_cores.uasset'
a=Asset(ASSETS/relative)
count_at,rows=entries(a);template=next(x for x in rows if x[0]=='CONTAINER_1P_UNSEEN_ARMOUR');name_index=struct.unpack_from('<I',template[1])[0];patched=[r[1]+a.b[r[2]:r[3]] for r in rows]
for alias,members in bundles.items():
 number=int(alias.rsplit('_',1)[1])+1
 values={'DisplayName':bundle_names[alias]['name'],'Description':'Mega Hunt Pass reward pack. Awards: '+', '.join(byid[i]['name'] or i for i in members)+'.'}
 patched.append(struct.pack('<II',name_index,number)+rewrite(a,template[2],template[3],values))
write_table(a,count_at,patched,relative)

relative='Archon/Content/Gameplay/hunt_pass/hunt_pass_season_table.uasset';a=Asset(ASSETS/relative);count_at,rows=entries(a);patched=[]
def ticks(d):return int((d-datetime.datetime(1,1,1,tzinfo=datetime.timezone.utc)).total_seconds())*10000000
start=ticks(datetime.datetime(2026,10,17,tzinfo=datetime.timezone.utc));end=ticks(datetime.datetime(2099,1,1,tzinfo=datetime.timezone.utc))
for name,key,begin,finish in rows:
 values={'SeasonTitle':'Hunt Pass Seasons','OverallSeasonName':'Hunt Pass Seasons','SeasonDescription':'Play the season selected in your launcher. Both reward tracks are unlocked.','StartDate':start,'EndDate':end,'ProgressionMultiplier':1,'bMustClaimRewards':False,'PremiumGatingEntitlement':'season27_premium'} if name=='HuntPass_Season27' else {}
 patched.append(key+rewrite(a,begin,finish,values))
write_table(a,count_at,patched,relative)

result={'revision':'mega1147-400-v1','pass_id':'season27','levels':400,'xp_per_level':100,'start_date':'2026-10-17T00:00:00+00:00','end_date':'2099-01-01T00:00:00+00:00','rewards':rewards,'bundles':bundles,'bundle_names':bundle_names,'items':{i['id']:{'kind':i['storage'],'name':i['name'],'source':i['source']} for i in items}}
p=ROOT/'Source/huntpass1147-data.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
audit={'manifest':'Dauntless_1.14.7.647472.manifest','manifest_sha1':'aa70748e4c0a776a991f2bac10ad342adaa31476','catalog_sha256':sha(catfile),'cosmetics':2997,'dyes':475,'five_dye_packs':95,'matching_armour_packs':112,'reward_cards':2339,'tiers':400,'tier_card_counts':dict(collections.Counter(map(len,rewards.values()))),'bundle_rows':207,'duplicate_cosmetics':0,'omitted_cosmetics':0,'native_asset_inputs':[]}
for rel in ['Archon/Content/Gameplay/Backend/Catalogs/containers_storeoffers_cores.uasset','Archon/Content/Gameplay/hunt_pass/hunt_pass_season_table.uasset']:
 for ext in ['.uasset','.uexp']:
  source=(ASSETS/rel).with_suffix(ext);audit['native_asset_inputs'].append({'file':str(Path(rel).with_suffix(ext)),'sha256':sha(source)})
(ROOT/'Source/reward-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))
