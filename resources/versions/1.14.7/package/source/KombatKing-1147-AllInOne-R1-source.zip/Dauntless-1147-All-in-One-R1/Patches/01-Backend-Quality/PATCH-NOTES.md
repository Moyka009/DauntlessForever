# Backend and save protection

Atomic saves, previous-save recovery, inventory transaction replay protection, account ownership checks, hidden managed solo startup, clean shutdown and bounded normal runtime logs.

Consolidates Backend Quality Fix2 and merges it into current official package 2026-10-17.12. Keeps current relay port handling, player names, host IDs, character travel and official Host Mode. The host-only startup path keeps the current official startup flow.

**Validation and limits:** Backend behavior and process supervision have automated tests. The combined current-package build needs a Windows launch check.

Install this component through the single **Install.cmd** in the main folder. Check and restore also run from the main folder. There is no separate component installer.

Source is in `Source`. License: AGPL-3.0-only; see `LICENSE-AGPL-3.0.txt`.
