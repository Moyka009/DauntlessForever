// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one Trials backend anchor');return s.replace(a,b);}
function patch(bytes){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 const a="const middleman1147 = require('./middleman1147').create({playerFor,bearerOf,sessions,inventoryOf,applyInventory,saveState,next:c=>mega1147.handle(c)});";
 s=once(s,a,a+"\nconst trials1147 = require('./trials1147').create({playerFor,bearerOf,sessions,inventoryOf,saveState,next:c=>middleman1147.handle(c)});");s=once(s,'reply = middleman1147.handle(','reply = trials1147.handle(');s=once(s,"note:'middleman1147: '+e.message","note:'trials1147: '+e.message");return Buffer.from(s.replaceAll('\n',nl));}
module.exports={patch};
