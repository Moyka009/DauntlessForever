DAUNTLESS 1.14.7 ALL-IN-ONE R1

INSTALL
1. Have the current official Dauntless Forever 1.14.7 server files installed and
   complete the official game setup once. No previous community patches or custom
   backend are required. This ZIP supplies its complete consolidated backend.
2. Stop Dauntless and its backend/server copies, then close the launcher.
3. Extract the whole ZIP to a folder you can keep.
4. Double-click Install.cmd in the main folder.
5. Open the launcher and start 1.14.7 normally.

There is ONE install button. Check-Installed.cmd and Restore.cmd are also in the
main folder. The Patches folders contain notes, source and licenses, not separate
installers. Read PATCH-LIST.md for the full summary and known limits.

The default active package is:
  %LOCALAPPDATA%\DauntlessForever\versions\1.14.7
The default launcher is:
  C:\DauntlessForever
The installer asks for a location only if it cannot find it. The game path comes
from the package's existing config.json. Do not point it at the 1.6.2 package.

WHAT IS CHECKED
Exact 1.14.7 executable and original PAK hashes, official setup metadata and native
DLL hashes, known package files, launcher compatibility, active update checksums,
all-in-one integrity and conflicting PAK overlays. All files are prepared before
installation changes anything. A normal write failure rolls the entire operation
back. A pending journal after power loss blocks another install for recovery.
This release was checked against official server package 2026-10-17.12. A newer
unrecognized release or edited managed file stops safely for comparison.

SAVES / SETTINGS / RESTORE
Installation does not replace or reset your save. The complete prior managed files
are backed up under the active package's backup\all-in-one1147-r1 folder. Keep that
folder. Restore.cmd returns those prior files while preserving current saves and
rule selections. Values above 5 are lowered to 5 on installation; lower choices and
toggles are kept. Existing season selection and launcher update preferences remain.
If an official update replaces a managed file, Check-Installed reports the change.
Restore refuses to overwrite an unknown later edit. Original individual-patch
backups are retained. After this bundle is installed, use its main check/restore
rather than the old individual patch installers.

GAUNTLET / TESTING LIMITS
Patch 12 is included. Gauntlet access, launch level and personal progress are
implemented. Crests/reward grants, guild rewards and guild leaderboards are not.
Its season reward arrays are empty. It needs an in-game test. Free dyes and some
Game Rules paths also await gameplay checks; bounty claim timing was deferred.
Other listed features were confirmed in their prior patches. Automated testing
of the consolidated package does not replace a Windows/in-game launch check.

This patch does not include the optional diagnostic recorders. It retains the
normal operational logs used by the backend, server and UI helper. It does not
change the game executable or replace the official native server/sign-in DLLs.

SOURCE / LICENSE
Every Patches folder contains Source, PATCH-NOTES.md and LICENSE-AGPL-3.0.txt.
Main installer/build/test source is under Source and Tests. AGPL-3.0-only.

DYE PACK UPDATE
The store now has ONE free All Dyes pack, replacing individual dye listings.
Existing all-in-one install: close the game/server and launcher, extract this updated ZIP, and run its main Install.cmd again.
The installer updates the dye module and its record while preserving saves, owned dyes, other components, and first-install restore backups.
Restart the backend/game after installing so the store reloads.

1.14.7 DYE PACK REVISION 2
One free All Dyes Pack replaces both the individual patch listings and original/captured dye listings.
Run this updated main Install.cmd over the existing all-in-one, then relaunch the backend/game.
Check-Installed.cmd also confirms that the current dye pack module is installed.
