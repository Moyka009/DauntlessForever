# Loader 1.14.7 - Modded mode build (Oct 19, 2026)

Source of `bin/dxgi.dll` in the Dauntless Forever 1.14.7 server files. AGPL-3.0-only (LICENSE-AGPL-3.0.txt).
MinHook by Tsuda Kageyu (BSD-2-Clause, minhook/LICENSE.txt).

Oct 19 (SigGuard 2): the significance guard also checks the vtable slot and the class pointer, and guards the second site (PostSignificance thunk exe+0x1D815E0) with an assembly hook that keeps every argument register.

Base: Loader1147-SigGuard-source (released loader BAA60615: fix5 + KombatKing's equipment fix R1 + owner-only
replication; client: significance guard and startup messages). Its rebuild has an identical .text section.

Added (client: player's game only):
- Boss Health Bar (from loader 2c-fix5 + 4c by Addison2k): with D1147_CLIENT_BOSSBAR=1 a click-through overlay shows
  the nearest behemoth's health and its parts' health (windowed or borderless window mode). Log: <D1147_DIR>\logs\client.log
- Boss bar position: Ctrl+Alt+arrow keys move it while it shows, Ctrl+Alt+Home resets; saved in <D1147_DIR>\data\bossbar_pos.txt.
- UE4SS: with -dfmods on the game's command line it loads <exe folder>\ue4ss\UE4SS.dll (no dwmapi.dll proxy).
Added (server copies): with D1147_SERVER_MODS=1 they load UE4SS the same way.
All of it is off unless the start scripts ask for it (launcher Mods page, data\mods.txt).

Build (Zig 0.17.0):

    zig c++ -target x86_64-windows-gnu -shared -O2 -o dxgi.dll d1147.cpp minhook/hook.c minhook/buffer.c minhook/trampoline.c minhook/hde/hde64.c -luser32 -lkernel32 -lgdi32
