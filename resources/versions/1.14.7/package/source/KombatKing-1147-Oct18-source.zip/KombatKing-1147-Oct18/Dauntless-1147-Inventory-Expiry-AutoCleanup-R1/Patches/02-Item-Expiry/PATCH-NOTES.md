# Item expiry update

- Update installer compatibility to official 1.14.7 package 2026-10-18.5.
- Retain the V3 overlay SHA256 c71f64758b7b70dc523da66fcec47319b330cc8d72e425ac94265ff4c15c029d.
- Verify byte-for-byte rebuild from original 1.14.7 manifest assets.
- Confirm only six ExpiryEventId fields change; all other catalog fields and asset sizes remain identical.
- Retain independent Install/Check/Restore, overlap checks and preservation of saves/other components.
