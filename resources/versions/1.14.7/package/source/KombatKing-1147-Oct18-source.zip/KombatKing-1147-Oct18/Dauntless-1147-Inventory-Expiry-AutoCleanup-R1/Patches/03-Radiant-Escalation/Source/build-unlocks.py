# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import json,struct,sys,hashlib
from equipment_asset import Asset
from pak import make_pak,Pak
root=Path(__file__).resolve().parents[1];source=root/'Source/Original';dest=root/'Source/Built';evidence=[]
for name,prefix in [('player_hunts_table','CR19_PlayerHunt_Escalation_Glitter_'),('matchmaker_hunts_table','CR19_MatchmakerHunt_Escalation_Glitter_')]:
 rel=Path('Gameplay/hunts')/(name+'.uasset');a=Asset(source/rel);o,_=a.properties(0);count_at=o+4;count=struct.unpack_from('<I',a.b,count_at)[0];o+=8;rows=[]
 def rewrite(start,end,parent=''):
  out=bytearray();pos=start
  while pos<end:
   at=pos;t=a.tag(at);pos=t['end'];raw=a.b[at:pos];here=parent+'/'+t['name']
   if here=='/Unlock/PlayerJourneyMapNodes':continue
   if t['name']=='None':out.extend(raw);break
   header=bytearray(a.b[at:t['start']]);payload=a.b[t['start']:pos]
   if here=='/Unlock/FeatureFlag':payload=struct.pack('<i',0)
   elif here=='/Unlock/QuestRequirementCondition':payload=struct.pack('<II',a.names.index('EQuestRequirementCondition::AllRequired'),0)
   elif here=='/Unlock':payload=rewrite(t['start'],pos,here)
   struct.pack_into('<I',header,16,len(payload));out.extend(header);out.extend(payload)
  return bytes(out)
 changed=[]
 for _ in range(count):
  start=o;rid,o=a.name(o);props=o;o,fields=a.properties(o);raw=a.b[start:props]+(rewrite(props,o) if rid.startswith(prefix) else a.b[props:o]);rows.append(raw)
  if rid.startswith(prefix):changed.append(rid)
 assert len(changed)==3 and o==len(a.b)-4
 b=a.b[:count_at+4]+b''.join(rows)+a.b[-4:];u=bytearray(a.ua);n,at=struct.unpack_from('<II',u,57);assert n==1;assert struct.unpack_from('<q',u,169)[0]==len(a.ua)+len(a.b)-4
 struct.pack_into('<q',u,at+28,len(b)-4);struct.pack_into('<q',u,169,len(u)+len(b)-4)
 d=dest/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(u);d.with_suffix('.uexp').write_bytes(b)
 check=Asset(d);o,_=check.properties(0);o+=8
 for i in range(count):
  rid,o=check.name(o);o,fields=check.properties(o)
  if rid.startswith(prefix):
   assert not any(f['path'].startswith('/Unlock/PlayerJourneyMapNodes') for f in fields)
   assert next(f['value'] for f in fields if f['path']=='/Unlock/FeatureFlag')==0
 evidence.append({'table':name,'changed_rows':changed,'original_sha256':hashlib.sha256(a.ua+a.b).hexdigest(),'patched_sha256':hashlib.sha256(bytes(u)+b).hexdigest()})
# Expose the two existing native Slayer's Path nodes; retain their costs and links.
rel=Path('Gameplay/PlayerJourney/player_journey_table.uasset');a=Asset(source/rel);ue=bytearray(a.b);o,_=a.properties(0);count=struct.unpack_from('<I',a.b,o+4)[0];o+=8;nodes=[]
for _ in range(count):
 rid,o=a.name(o)
 while True:
  t=a.tag(o);o=t['end']
  if t['name']=='None':break
  if rid in ['Escalation.Easy.Radiant','Escalation.Hard.Radiant'] and t['name']=='RequiredFeatureFlag':
   assert t['type']=='ObjectProperty';struct.pack_into('<i',ue,t['start'],0);nodes.append(rid)
assert len(nodes)==2
d=dest/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(a.ua);d.with_suffix('.uexp').write_bytes(ue)
evidence.append({'table':'player_journey_table','changed_rows':nodes,'change':'RequiredFeatureFlag=0 only; native costs (50/100 Combat Merits), node links and saved status preserved'})
files={str(f.relative_to(dest)).replace('\\','/'):f.read_bytes() for f in dest.rglob('*') if f.is_file()}
folder=root/'Payload/paks';folder.mkdir(exist_ok=True);pak=folder/'zzzzzzzzzzzzzzzzzz_RadiantEscalation1147_P.pak';make_pak(files,pak)
p=Pak(pak)
for name,b in files.items():assert p.extract(name)==b
(root/'Source/unlock-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');print('Built six assets: six hunt gates and two existing Slayer Path node flags; V3 archive.')
