# Inventory source

rebuild.cjs reproduces catalog-1147.json from catalog-before.json and Native/player_role_catalog.json. Run it with --check for byte-for-byte validation. The native decoder and original extraction builder are included.

items.js is the installed inventory helper. patch-base.cjs, patch-launcher.cjs and the two runtime text fragments define the search UI transformation. asar.cjs handles archive packing and integrity. The shared Source/launcher.cjs and Source/install.cjs manage bundled/active launchers, component selection, backup and rollback.

Tests/search-ui.cjs in the main bundle tests the actual transformed renderer. test-inventory.cjs tests actual helper save behavior. Main Source/package.cjs refreshes delivery integrity; there is no separate build.cjs/package.py requirement.
