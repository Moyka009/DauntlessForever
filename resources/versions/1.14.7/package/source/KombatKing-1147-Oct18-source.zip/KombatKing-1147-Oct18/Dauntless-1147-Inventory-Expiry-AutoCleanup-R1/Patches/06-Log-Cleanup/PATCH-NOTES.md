# Automatic log cleanup update

- Add a guarded tools/common.ps1 startup hook and tools/auto-cleanup-logs1147.cjs.
- Skip automatic deletion while the local backend is listening.
- Retain newest five files/folders per known group and all logs from the past 24 hours.
- Preserve current client engine, server/recorder logs and latest client/server ZIPs.
- Skip symbolic links, linked log folders, recently updated descendants and unavailable/locked entries.
- Restrict cleanup to recognized run folders, timestamped server logs and archived client/server ZIPs inside the active package.
- Keep independent Restore and manual cleanup; no scheduled Windows task or packet recorder is added.
