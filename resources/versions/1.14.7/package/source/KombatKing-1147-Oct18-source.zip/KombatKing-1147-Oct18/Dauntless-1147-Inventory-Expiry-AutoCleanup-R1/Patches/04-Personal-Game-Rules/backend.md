# Backend and file changes

Replaces only the game-rules module/data and rule definitions with the private versions; recorder-1147.js stays official except when Radiant is selected separately. Official server/client scripts are rebuilt with dev preparation and native helper attachment. Existing official ability activation remains in dxgi.dll, which this patch does not replace. Source/native and the build inputs document the exact CL647472 signatures. Game Rules and source comments retain their original licenses.

The shared installer composes overlapping launch/backend files from reviewed official inputs for the currently selected patches. Removing one component rebuilds those files with the other selected components retained. Official native DLLs are verified and retained.
