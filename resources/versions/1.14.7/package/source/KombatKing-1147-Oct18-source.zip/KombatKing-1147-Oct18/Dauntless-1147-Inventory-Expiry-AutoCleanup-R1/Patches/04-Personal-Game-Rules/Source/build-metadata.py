# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import hashlib,json,sys
import pefile
root=Path(__file__).resolve().parents[1];aio=root.parent/'Dauntless-1147-All-in-One-R1';sha=lambda b:hashlib.sha256(b).hexdigest()
exe=Path(sys.argv[1]);assert sha(exe.read_bytes())=='f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b'
p=pefile.PE(str(exe),fast_load=True)
checks={0x2861880:'4055565741544155',0x1aece40:'40534883ec40',0x2564ab0:'48895c2408488974',0x18d53c5:'80bbf0000000030f852b010000',0x18d54ec:'4a3914c07506ff8bc8070000'}
for r,h in checks.items():assert p.get_data(r,len(bytes.fromhex(h)))==bytes.fromhex(h),(hex(r),p.get_data(r,len(bytes.fromhex(h))).hex())
dll=root/'Payload/tools/DevRules1147.dll';d=pefile.PE(str(dll));export=next(x for x in d.DIRECTORY_ENTRY_EXPORT.symbols if x.name==b'DevRulesStatus1147')
health=json.loads((root/'Source/health-audit.json').read_text());healthHashes={str(int(v['factor']))if float(v['factor']).is_integer()else str(v['factor']):v['sha256']for v in health['variants']}
(root/'Payload/tools/dev-native1147.json').write_text(json.dumps({'exe_sha256':sha(exe.read_bytes()),'dll_sha256':sha(dll.read_bytes()),'status_rva':export.address,'health_hashes':healthHashes},indent=2))
spec=json.loads((aio/'Source/compatibility.json').read_text());names=['rules.json','backend/game-rules1147.js','backend/game-rules1147-data.json','tools/server-1147.ps1','tools/play-1147.ps1']
(root/'Source/compatibility.json').write_text(json.dumps({'exe_sha256':spec['exe_sha256'],'manifest_sha1':spec['manifest_sha1'],'baseline':{n:sha((aio/'Payload/package'/n).read_bytes())for n in names},'health_hashes':list(healthHashes.values()),'original_paks':spec['original_paks']},indent=2))
(root/'Source/native-audit.json').write_text(json.dumps({'game':'1.14.7 CL647472','exe_sha256':sha(exe.read_bytes()),'manifest_sha1':spec['manifest_sha1'],'sdk_library_id':'libfile_4347169aad38819188a3c460b3426083','sdk_fields':{'player_ASC':'0xc50','actor_owner':'0xe0','spawned_attributes':'0x140','part_fields':['0xec','0xf0'],'stagger_fields':['0xd8','0xd0'],'wound_fields':['0xdc','0xe4'],'core_fields':['0xf4','0xf8'],'damage_data_size':'0x70','damage_override':'0x138','damage_return':'0x160'},'code_checks':{hex(r):h for r,h in checks.items()},'allocator':{'rva':'0x2564ab0','verified':'Unique re-found allocator wrapper; GMalloc initialization, argument forwarding and vtable +0x20 tail jump verified.'},'escalation':{'exec_wrapper':'0x23a51f0','native_getter':'0x1aece40','model':'Native getter sums bonuses and returns zero when none; replacement returns (1 + original boost) * capped rule rate - 1.'},'resupply':{'authority_check':'0x18d53c5','decrement':'0x18d54f2','character_field':'0x7c8','replacement':'six NOPs in new local server memory; preserves authority/class checks'},'windows_native_gameplay':'not executed; required','built_dll_sha256':sha(dll.read_bytes())},indent=2))
# Only patcher/source/payload files are covered; test outputs are regenerated separately.
paths=[x for x in root.rglob('*')if x.is_file()and x.name!='Integrity.json'and x.suffix not in ['.pyc']and '__pycache__'not in x.parts and 'Validation'not in x.parts]
(root/'Integrity.json').write_text(json.dumps({str(p.relative_to(root)).replace('\\','/'):sha(p.read_bytes())for p in sorted(paths)},indent=2))
print('Native signatures, DLL export and metadata verified')
