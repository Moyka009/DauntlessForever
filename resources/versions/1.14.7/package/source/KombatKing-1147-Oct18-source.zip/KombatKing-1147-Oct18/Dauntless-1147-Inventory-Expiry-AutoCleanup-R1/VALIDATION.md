# Validation — 18 October 2026

Target: launcher 0.2.10, official server package 2026-10-18.5, Dauntless 1.14.7 CL647472. Official source commit and Git blob/SHA256 checks are in Source/official-audit.json.

Passed automated checks:

- 10 actual inventory-helper checks: correct native storage, own-account isolation, preserved upgrades/cells/parts, invalid batch refusal, equipped deletion guard, wrong-list repair, exact prior-save backups, all six Omnicells and current travel fingerprint protection.
- 4 renderer checks using its actual transformed inventory function in a DOM fixture: two-line Gil suggestions and keyboard selection, adding Gilded Marks by name, six Omnicell names/native IDs, and Escape clearing.
- 4 automatic-cleanup checks: preview; running-backend skip; newest-five/24-hour/link/current-log/current-ZIP/save protection and harmless repetition; invalid roots/settings refusal.
- 13 installer checks, including all 64 component selection combinations, independent restores, default three-component installation, active app-update archive/checksum handling, current metadata, Windows CRLF compatibility, private settings, unknown-file refusal and injected write/restore rollback.
- Current-upgrade checks using the actual earlier All-in-One R2 installer and receipt: upgrade preserves all existing selections and old backup bytes; restores retain the current official recorder; failed upgrade rolls back files, receipt and restore baselines.
- 10 actual HTTP checks with the complete current official backend plus existing Radiant composition: sign-in, progression GET/POST, stale-save refusal, party invitation/acceptance, group travel, heroic gating, existing Gauntlet and persistence after restart.
- Native expiry overlay rebuilds byte-for-byte from hash-verified original 1.14.7 manifest assets. Exactly six expiry fields change; all other decoded fields and asset sizes are identical.
- Search metadata rebuilds byte-for-byte with 5,805 entries. Syntax checks passed for 40 JavaScript and 24 JSON files, seven PowerShell wrappers and the composed cleanup startup hook. All 16 delivery PAKs use V3 with verified entry SHA1 and index hashes.

Tests use isolated fixture saves/logs and the exact original EXE for hash checks. No user save/log was altered during development.

Native Windows gameplay, Electron rendering in the user's launcher and actual Windows PowerShell execution are not claimed as tested here. The renderer is exercised with a DOM fixture, the backend over localhost HTTP, and PowerShell is checked statically. Other native Radiant/gameplay limitations remain unchanged.
