// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function patch(text){const anchor="$GameArgs = '-EpicPortal -AUTH_TYPE=accountportal -AUTH_LOGIN=unused -AUTH_PASSWORD=unused'";if(text.split(anchor).length!==2)throw Error('Official client arguments anchor missing');return text.replace(anchor,anchor+`\n# Keep a predictable live engine log without blocking the client on pipe reads.\n$ClientEngineLog = Join-Path $Root 'logs\\client_engine.log'\nNew-Item -ItemType Directory -Force (Split-Path -Parent $ClientEngineLog) | Out-Null\n$GameArgs += ' -abslog="' + $ClientEngineLog + '" -FORCELOGFLUSH -LOGTIMES'\n`);}
module.exports={patch};
