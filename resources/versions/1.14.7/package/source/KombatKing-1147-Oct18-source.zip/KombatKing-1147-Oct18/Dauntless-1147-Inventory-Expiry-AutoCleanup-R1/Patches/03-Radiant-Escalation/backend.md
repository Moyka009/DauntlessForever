# Backend and file changes

Source/patch-current.cjs patches the exact official 2026-10-18.5 recorder. It adds Radiant destination selection, fills the native player-hunt ID before the official join route, wraps Radiant progression requests and ensures missing path entries. It deliberately reuses the official group-wide PlayerHuntIds handling and party-follow path instead of adding a second travel implementation. Runtime progression uses radiant1147.js and its inspected native definitions. Other hunts, seasons, equipment, Trials/Gauntlet and party functions stay in the official chain.

The shared installer composes overlapping launch/backend files from reviewed official inputs for the currently selected patches. Removing one component rebuilds those files with the other selected components retained. Official native DLLs are verified and retained.
