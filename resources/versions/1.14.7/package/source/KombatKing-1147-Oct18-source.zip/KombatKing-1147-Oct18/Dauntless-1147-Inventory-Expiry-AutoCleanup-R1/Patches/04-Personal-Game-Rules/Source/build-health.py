# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import struct,json,hashlib
from equipment_asset import Asset
from pak import make_pak,Pak
root=Path(__file__).resolve().parents[1];source=root/'Source/HealthOriginal/player_health_as.uasset';a=Asset(source)
end,_=a.properties(0);assert struct.unpack_from('<II',a.b,end)==(0,22);o=end+8;positions=[]
for _ in range(22):
 name,o=a.name(o)
 while True:
  t=a.tag(o);o=t['end']
  if t['name']=='None':break
  if name in ['ArchonHealthAttributeSet.CurrentHealth','ArchonHealthAttributeSet.MaxHealth'] and t['name']=='BaseValue':
   assert t['type']=='FloatProperty' and struct.unpack_from('<f',a.b,t['start'])[0]==1000;positions.append(t['start'])
assert len(positions)==2 and o==len(a.b)-4
choices=[float(c[0])for r in json.loads((root/'Payload/rules.json').read_text())['rules']if r['key']=='health'for c in r['choices']]
out=root/'Payload/tools/dev-health1147';out.mkdir(exist_ok=True)
proof=[]
for factor in choices:
 ue=bytearray(a.b)
 for at in positions:struct.pack_into('<f',ue,at,1000*factor)
 assert all(x==y or any(at<=i<at+4 for at in positions)for i,(x,y)in enumerate(zip(a.b,ue)))
 key=str(int(factor))if factor.is_integer()else str(factor);pak=out/('health-'+key+'.pak')
 files={'game/abilities/player/player_health_as.uasset':a.ua,'game/abilities/player/player_health_as.uexp':bytes(ue)};make_pak(files,pak)
 check=Pak(pak);assert set(check.rows)==set(files)
 for n,b in files.items():assert check.extract(n)==b
 proof.append({'factor':factor,'starting_health':1000*factor,'changed_float_offsets':positions,'sha256':hashlib.sha256(pak.read_bytes()).hexdigest()})
(root/'Source/health-audit.json').write_text(json.dumps({'game':'1.14.7 CL647472','source':json.loads((source.parent/'provenance.json').read_text()),'source_assets_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in source.parent.iterdir()if p.suffix in ['.uasset','.uexp']},'verification':'Manifest-verified CDN chunks, original entry stored SHA1, decoded table, exactly two BaseValue floats changed, every variant PAK round trip. No complete source PAK hash was computed.','variants':proof,'native_gameplay':'pending'},indent=2))
print('Health variants verified:',len(proof))
