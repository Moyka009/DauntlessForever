// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Radiant current-release anchor missing: '+a.slice(0,90));return s.replace(a,b);}
function patch(buffer){let s=buffer.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 s=once(s,'function destinationFor(b) {',"function destinationFor(b) {\n  const radiantDestination = require('./radiant1147').destination(b);\n  if (radiantDestination) return radiantDestination;");
 // Retain the official party-follow code and its group-wide PlayerHuntIds implementation.
 s=once(s,'const p = playerFor(c.req); const b = c.body || {};\n    const dest = destinationFor(b);',"const p = playerFor(c.req); const b = require('./radiant1147').prepare(c.body || {},p);\n    const dest = destinationFor(b);");
 const marker=s.split('\n').find(l=>l.startsWith('const modes1147 ='));if(!marker)throw Error('Official modes chain missing');
 s=once(s,marker,marker+"\nconst radiant1147 = require('./radiant1147').create({playerFor,bearerOf,sessions,getPlayers:()=>Object.values(state.players||{}),saveState,next:c=>modes1147.handle(c)});");
 s=once(s,'  return m;\n}\nfunction savePjm(c) {',"  if (key === 'main') require('./radiant1147').ensurePath(m);\n  return m;\n}\nfunction savePjm(c) {");s=once(s,'reply = modes1147.handle(','reply = radiant1147.handle(');return Buffer.from(s.replaceAll('\n',nl));}
module.exports={patch};
