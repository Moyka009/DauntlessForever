// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path');
const toggles=new Set(['free_crafting','rare_core_kill','unlimited_resupply']);
function parse(defs,text){const values=Object.fromEntries(defs.rules.map(r=>[r.key,Number(r.default)]));for(const line of text.replace(/^\uFEFF/,'').split(/\r?\n/)){
 if(!line.trim()||line.trim().startsWith('#'))continue;
 const m=/^\s*([a-z_]+)\s*=\s*([0-9.]+)\s*$/.exec(line),r=m&&defs.rules.find(r=>r.key===m[1]);if(!r||!r.choices.some(c=>Number(c[0])===Number(m[2])))throw Error('Invalid dev rule: '+line);values[m[1]]=Number(m[2]);
}return values;}
function read(root,env=process.env){const defs=JSON.parse(fs.readFileSync(path.join(root,'rules.json'),'utf8').replace(/^\uFEFF/,''));
 if(env.DF_HOSTING==='1'||env.RECORDER_PUBLIC_HOST||env.RECORDER_BIND&&!['127.0.0.1','localhost','::1'].includes(env.RECORDER_BIND))throw Error('Personal dev rules require solo play. Stop hosting and use the normal Play button.');
 const file=path.join(root,'data/rules.txt');return parse(defs,fs.existsSync(file)?fs.readFileSync(file,'utf8'):'');}
function prepare(root,game){const s=read(root),data=path.join(root,'data');fs.mkdirSync(data,{recursive:true});
 const derived={...s,escalation_rate:Math.min(100,s.universal_xp*s.escalation_xp)};
 const target=path.join(data,'dev-rules1147.env'),temp=target+'.tmp-'+process.pid;fs.writeFileSync(temp,Object.entries(derived).map(([k,v])=>k+'='+v).join('\n')+'\n');fs.renameSync(temp,target);
 const src=path.join(root,'tools/dev-health1147','health-'+s.health+'.pak'),dest=path.join(game,'Archon/Content/Paks/zzzzzzzzzzzzzzzzzz_DevHealth1147_P.pak');
 const b=fs.readFileSync(src),spec=JSON.parse(fs.readFileSync(path.join(root,'tools/dev-native1147.json'),'utf8'));if(require('crypto').createHash('sha256').update(b).digest('hex')!==spec.health_hashes[String(s.health)])throw Error('Health asset integrity mismatch');const magic=b.lastIndexOf(Buffer.from([0xe1,0x12,0x6f,0x5a]));if(magic<0||b.readUInt32LE(magic+4)!==3)throw Error('Unsupported health PAK format; use the repaired V3 package');const tmp=dest+'.tmp-'+process.pid;fs.writeFileSync(tmp,b);fs.renameSync(tmp,dest);return target;
}
module.exports={parse,read,prepare,toggles};
if(require.main===module){try{const[root,game]=process.argv.slice(2);console.log(prepare(root,game));}catch(e){console.error(e.message);process.exitCode=1;}}
