# Automatic cleanup files

No backend route changes. Installs tools/auto-cleanup-logs1147.cjs and appends a marked invocation to the reviewed tools/common.ps1. The hook resolves the configured Node runtime, runs automatic cleanup, preserves LASTEXITCODE and treats cleanup failures as nonfatal. The previous manual tools/cleanup-logs1147.cjs remains available.

The cleaner validates the active package root, checks the local backend port, groups only known logs/upload archives, retains five newest per group and a 24-hour minimum age, and skips linked/recent trees. Fixed current log/archive names are not deletion candidates. There is no recurring background process.

The existing All-in-One R2 component-06 receipt is updated transactionally with the hook and helper records. Restore removes those records' changes and composes other selected patches. Install/Restore do not delete logs; actual cleanup deletions are reported when the cleaner runs and cannot be reversed by Restore.cmd.
