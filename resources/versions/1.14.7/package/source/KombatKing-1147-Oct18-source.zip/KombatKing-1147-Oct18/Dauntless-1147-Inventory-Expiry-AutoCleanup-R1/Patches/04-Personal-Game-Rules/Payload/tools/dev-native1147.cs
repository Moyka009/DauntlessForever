// SPDX-License-Identifier: AGPL-3.0-only
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
public static class DevNative1147 {
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr VirtualAllocEx(IntPtr h,IntPtr address,UIntPtr size,uint type,uint protection);
 [DllImport("kernel32.dll")] static extern bool VirtualFreeEx(IntPtr h,IntPtr address,UIntPtr size,uint type);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool WriteProcessMemory(IntPtr h,IntPtr address,byte[] data,UIntPtr size,out UIntPtr written);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr CreateRemoteThread(IntPtr h,IntPtr attributes,UIntPtr stack,IntPtr start,IntPtr param,uint flags,IntPtr id);
 [DllImport("kernel32.dll")] static extern uint WaitForSingleObject(IntPtr h,uint timeout);
 [DllImport("kernel32.dll")] static extern bool GetExitCodeThread(IntPtr h,out uint code);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
 [DllImport("kernel32.dll",CharSet=CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr h,string name);
 static uint Call(IntPtr process,IntPtr function,IntPtr arg){IntPtr t=CreateRemoteThread(process,IntPtr.Zero,UIntPtr.Zero,function,arg,0,IntPtr.Zero);if(t==IntPtr.Zero)throw new Exception("Native initialization thread failed.");try{if(WaitForSingleObject(t,15000)!=0)throw new Exception("Native initialization timed out; server is stopped.");uint result;if(!GetExitCodeThread(t,out result))throw new Exception("Native initialization status unavailable.");return result;}finally{CloseHandle(t);}}
 static IntPtr RemoteLoadLibrary(Process remote){IntPtr local=GetProcAddress(GetModuleHandle("kernel32.dll"),"LoadLibraryW");using(Process self=Process.GetCurrentProcess()){foreach(ProcessModule module in self.Modules){long offset=local.ToInt64()-module.BaseAddress.ToInt64();if(offset<0||offset>=module.ModuleMemorySize)continue;foreach(ProcessModule other in remote.Modules)if(String.Equals(other.ModuleName,module.ModuleName,StringComparison.OrdinalIgnoreCase))return new IntPtr(other.BaseAddress.ToInt64()+offset);}}throw new Exception("Windows loader address could not be resolved.");}
 public static void Load(int pid,string exe,string dll,int statusRva){
 if(!Environment.Is64BitProcess)throw new Exception("64-bit PowerShell is required.");
 using(Process p=Process.GetProcessById(pid)){
 ProcessModule main=null;for(int attempt=0;attempt<40;attempt++){try{main=p.MainModule;if(main!=null)break;}catch(System.ComponentModel.Win32Exception){}Thread.Sleep(100);p.Refresh();}
 if(main==null||!String.Equals(Path.GetFullPath(main.FileName),Path.GetFullPath(exe),StringComparison.OrdinalIgnoreCase)||(DateTime.Now-p.StartTime).TotalSeconds>30)throw new Exception("Unexpected server process.");
 IntPtr h=OpenProcess(0x43a,false,pid);if(h==IntPtr.Zero)throw new Exception("Cannot open new local server.");IntPtr memory=IntPtr.Zero;bool completed=false;
 try{byte[] name=System.Text.Encoding.Unicode.GetBytes(Path.GetFullPath(dll)+"\0");memory=VirtualAllocEx(h,IntPtr.Zero,new UIntPtr((uint)name.Length),0x3000,4);if(memory==IntPtr.Zero)throw new Exception("Native path allocation failed.");UIntPtr n;if(!WriteProcessMemory(h,memory,name,new UIntPtr((uint)name.Length),out n)||n.ToUInt64()!=(ulong)name.Length)throw new Exception("Native path write failed.");Call(h,RemoteLoadLibrary(p),memory);completed=true;
 IntPtr address=IntPtr.Zero;for(int attempt=0;attempt<100;attempt++){p.Refresh();foreach(ProcessModule module in p.Modules)if(String.Equals(Path.GetFullPath(module.FileName),Path.GetFullPath(dll),StringComparison.OrdinalIgnoreCase)){address=new IntPtr(module.BaseAddress.ToInt64()+statusRva);break;}if(address!=IntPtr.Zero&&Call(h,address,IntPtr.Zero)==1)return;Thread.Sleep(100);}
 throw new Exception("Dev native helper did not report ready; server is stopped.");
 }finally{if(memory!=IntPtr.Zero&&completed)VirtualFreeEx(h,memory,UIntPtr.Zero,0x8000);CloseHandle(h);}
 }}
}
