# Rebuild

From the package folder:

```
python Source/build-unlocks.py
node -e "const fs=require('fs');fs.writeFileSync('Payload/backend/recorder-1147.js',require('./Source/patch-backend.cjs').patch(fs.readFileSync('Source/recorder-before.js')))"
```

Copy `Source/radiant1147.js` and `Source/radiant1147-data.json` to `Payload/backend` after editing. Refresh `Integrity.json` with SHA256 for all included files except itself and Python caches before installation.

`node Tests/test.cjs` also needs the matching executable at the reference path documented in that test, only for installer version-verification tests. `node Tests/runtime.cjs` needs the previous complete all-in-one Payload/package folder, selected with `DAUNTLESS_CURRENT_AIO_PACKAGE`. This input is not an official update and is not installed by the tests.

The original cooked table inputs were recovered from the 1.14.7 CL647472 manifest. CDN chunks and stored PAK entries were SHA1-checked before decoding. Whole original PAKs were not downloaded/rehashed for this add-on. Native map/boss binaries and a new loader DLL are not redistributed.
