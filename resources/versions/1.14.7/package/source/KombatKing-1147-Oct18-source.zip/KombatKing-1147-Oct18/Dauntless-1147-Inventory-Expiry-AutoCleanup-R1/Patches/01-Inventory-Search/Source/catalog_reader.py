# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import sys,struct,json
sys.path.insert(0,str(Path(__file__).resolve().parent))
from equipment_asset import Asset,fs

def table(p):
 a=Asset(p);e=a.exports[0];pos,_=a.properties(e['start']);assert struct.unpack_from('<I',a.b,pos)[0]==0;pos+=4;count=struct.unpack_from('<I',a.b,pos)[0];pos+=4;rows=[]
 for i in range(count):
  key,pos=a.name(pos);pos,fields=a.properties(pos)
  for x in fields:
   if x['type']=='ObjectProperty':x['object']=a.object(x['value'])
  rows.append({'id':key,'fields':fields})
 assert pos==e['start']+e['size'],(p.name,pos,e['start']+e['size'])
 return {'asset':str(p),'rows':rows,'count':count,'row_struct':a.object(a.decode()[0]['fields'][0]['value'])}
if __name__=='__main__':
 for p in sys.argv[1:]:
  t=table(Path(p));print(t['asset'],t['count'],t['row_struct']);print(json.dumps(t['rows'][:1],indent=2)[:9000])
