# Build and evidence

Target: 1.14.7 CL647472, EXE SHA256 `f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b`, manifest SHA1 `aa70748e4c0a776a991f2bac10ad342adaa31476`.

The supplied DLL is already built. Installation requires no compiler. For a rebuild, use Zig 0.17.0:

```sh
zig c++ -target x86_64-windows-gnu -shared -O2 -o Payload/tools/DevRules1147.dll Source/Native/DevRules1147.cpp Source/Native/minhook/hook.c Source/Native/minhook/buffer.c Source/Native/minhook/trampoline.c Source/Native/minhook/hde/hde64.c -lkernel32 -lbcrypt
```

Place optional .lib/.pdb outputs in Source/BuildSymbols, not Payload. Rebuild health variants with `python3 Source/build-health.py`; its exact original 1.14.7 assets and provenance are included. The builder verifies that only two BaseValue floats change.

`build-metadata.py` requires Python pefile, the verified EXE, and the current 1.14.7 all-in-one folder alongside this add-on. It checks the native signatures, finds the DLL's status export, updates health/DLL hashes and records known base-file hashes. Run it after source/payload changes, before packaging:

```sh
python3 Source/build-metadata.py /path/to/Dauntless1147.exe
node Tests/rules.cjs
node Tests/install.cjs /path/to/Dauntless1147.exe
python3 Tests/native-host.py
```

The installer tests use a real hash-matched EXE through a hard link; game verification is not stubbed. They use copied package fixtures, not a running Windows launcher. The native host test compiles the actual array-copy routine extracted from the DLL source and tests it with a controlled allocator. Address/undefined-behavior sanitizers run; LeakSanitizer is disabled because the container prevents its process inspection, and allocation ownership/counts are checked explicitly.

PowerShell and C# files were parsed with tree-sitter grammars. That is syntax checking, not Windows execution or a C# runtime integration test.

Per-version source identities and signatures are in native-audit.json; health-table details are in health-audit.json. The original health assets were read from Archon_24-WindowsClient.pak using the 1.14.7 manifest's CDN chunks. Chunk SHA1 and stored entry SHA1 were checked; Oodle data was decoded for table inspection. A full source PAK checksum was not recomputed. No 1.6.2 asset is installed.

Scoped attribute math derives from the community 1.6.2 helper; resupply source derives from Addison2k's AGPL 1.6.2 helper, originally based on KombatKing's resupply work, with addresses and checks re-found for 1.14.7. MinHook retains its own included license. Existing source copyright comments are retained. No runtime notice file is installed.
