# Updated patch list

Default main Install updates three components for official 1.14.7 package 2026-10-18.5 and launcher 0.2.10:

1. Inventory search: retain name/ID filtering, two-line suggestions, keyboard selection, name-based adding and catalog-aware inventory storage; add six native Omnicells for 5,805 searchable entries.
2. Item expiry: retain the verified V3 native overlay for five Season 11A potions and the Springtide egg token. Rebuilt byte-for-byte against original 1.14.7 manifest assets; only six expiry fields differ.
3. Automatic log cleanup: add a shared-tool startup hook and a guarded cleaner. Retain newest five per group and the past 24 hours; preserve current engine logs, server/recorder files and latest ZIPs; skip active backend, recent descendants and links.

Existing selected Radiant, personal rules and client engine logging remain selected and keep separate component controls. Current official party, equipment, Hunt Pass and local-character travel protections are retained. The Trials shop expansion files are not changed.

The installer accepts the current official package metadata, migrates existing All-in-One R2 records, preserves old backups and saves fresh current official restore baselines. Main Restore removes the three requested components; individual restores remain available.

No standalone NOTICE.txt or new packet recorder. Each component includes source, patch notes, backend.md and AGPL-3.0-only license.
