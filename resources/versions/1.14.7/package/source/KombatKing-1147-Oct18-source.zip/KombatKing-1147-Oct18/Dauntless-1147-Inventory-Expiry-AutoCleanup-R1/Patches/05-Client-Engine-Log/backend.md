# Backend and file changes

No backend changes. Only the composed client launch arguments change. The log should be written while the native game is running; actual Windows log production still needs a launch test.

The shared installer composes overlapping launch/backend files from reviewed official inputs for the currently selected patches. Removing one component rebuilds those files with the other selected components retained. Official native DLLs are verified and retained.
