// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),base=require('./patch-base.cjs');
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one suggestion anchor: '+a.slice(0,80));return s.replace(a,b);}
function patchFile(name,bytes){bytes=base.patchFile(name,bytes);let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 if(name==='src/main/main.js'){
  s=once(s,`  const clean = {};
  for (const [k, n] of Object.entries(changes || {})) if (/^[A-Z0-9_]{3,80}$/.test(k) && Number.isFinite(Number(n))) clean[k] = Math.max(0, Math.floor(Number(n)));`, `  const clean = {}, catalogIds = new Set();
  if (v.id === '1.14.7') {
    try {
      const meta = JSON.parse(fs.readFileSync(path.join(v.dataDir, 'tools', 'catalog-1147.json'), 'utf8').replace(/^\\uFEFF/, ''));
      if (meta.game === '1.14.7 CL647472' && Array.isArray(meta.items)) for (const it of meta.items)
        if (it && typeof it.id === 'string' && /^[A-Za-z0-9_-]{3,80}$/.test(it.id)) catalogIds.add(it.id);
    } catch {}
  }
  for (const [k, n] of Object.entries(changes || {})) if ((/^[A-Z0-9_]{3,80}$/.test(k) || catalogIds.has(k)) && Number.isFinite(Number(n))) clean[k] = Math.max(0, Math.floor(Number(n)));`);
 }else if(name==='src/renderer/index.html'){
  s=once(s,'<input id="item-search" type="search"', '<div class="item-search-field"><input id="item-search" role="combobox" aria-autocomplete="list" aria-controls="item-search-suggestions" aria-expanded="false" type="search"');
  s=once(s,'aria-describedby="item-search-count"><button', 'aria-describedby="item-search-count"><div id="item-search-suggestions" class="item-search-suggestions" role="listbox" aria-label="Matching items" hidden></div></div><button');
  s=once(s,'Add another item by its ID','Add another item by name or ID');
  s=once(s,'id="item-add-id" placeholder="CURRENCY_NOTES"','id="item-add-id" placeholder="Gilded Marks or CURRENCY_MARKS_GILDED" aria-label="Item name or ID"');
  s=once(s,"IDs are the game's catalog names (capital letters, digits and _). An ID the game doesn't know does nothing in game and can be removed again here.",'Use a full item name, choose a search suggestion, or enter an item ID. Then add it to the list and save your changes.');
 }else if(name==='src/renderer/app.js'){
  s=once(s,"let itemSearchQuery = '', itemSearchLimit = 100;", "let itemSearchQuery = '', itemSearchLimit = 100, itemSearchOpen = false, itemSearchActive = -1;");
  s=once(s,"const clearSearch = () => { itemSearchQuery = ''; itemSearchLimit = 100;", "const clearSearch = () => { itemSearchQuery = ''; itemSearchOpen = false; itemSearchActive = -1; itemSearchLimit = 100;");
  s=once(s,'itemSearchQuery = search.value; itemSearchLimit = 100; renderItems(false);','itemSearchQuery = search.value; itemSearchLimit = 100; itemSearchOpen = !!itemSearchQuery.trim(); itemSearchActive = -1; renderItems(false);');
  s=once(s,'  const known = new Set();',fs.readFileSync(path.join(__dirname,'dropdown-runtime.txt'),'utf8')+'  const known = new Set();');
  const addStart = s.indexOf("    const id = $('item-add-id').value.trim().toUpperCase(), q =");
  const addEnd = s.indexOf('    const have = ch.items[id] || 0;', addStart);
  if(addStart < 0 || addEnd < addStart) throw Error('Missing name / ID add anchors');
  s = s.slice(0, addStart) + fs.readFileSync(path.join(__dirname,'name-add-runtime.txt'),'utf8') + s.slice(addEnd);
  s=once(s,"  $('item-add-btn').onclick = () => {","  $('item-add-id').onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); $('item-add-btn').onclick(); } };\n  $('item-add-btn').onclick = () => {");

 }else if(name==='src/renderer/styles.css'){
  s+=`\n/* Two-line inventory suggestions */
.item-search-field { position: relative; flex: 1; min-width: 0; }
.item-search-field input { width: 100%; box-sizing: border-box; }
.item-search-suggestions { position: absolute; top: calc(100% + 6px); left: 0; right: 0; z-index: 10; max-height: 320px; overflow-y: auto; border: 1px solid var(--line-2); border-radius: 8px; background: var(--bg-2); box-shadow: 0 8px 24px #0008; }
.item-search-suggestions[hidden] { display: none; }
.item-search-option { display: flex; flex-direction: column; gap: 4px; padding: 10px 12px; cursor: pointer; border-bottom: 1px solid var(--line); }
.item-search-option:last-child { border-bottom: 0; }
.item-search-option:hover, .item-search-option.selected { background: var(--bg); box-shadow: inset 3px 0 var(--ember); }
.item-search-name { color: var(--ink); font-size: 14px; font-weight: 600; }
.item-search-id { color: var(--ink-3); font-size: 11px; overflow-wrap: anywhere; }
.item-search-hint { padding: 10px 12px; color: var(--ink-3); font-size: 12px; }
@media (max-width: 600px) { .item-search-field { flex-basis: 100%; } }
`;
 }
 return Buffer.from(s.replaceAll('\n',nl));
}
module.exports={patchFile};
