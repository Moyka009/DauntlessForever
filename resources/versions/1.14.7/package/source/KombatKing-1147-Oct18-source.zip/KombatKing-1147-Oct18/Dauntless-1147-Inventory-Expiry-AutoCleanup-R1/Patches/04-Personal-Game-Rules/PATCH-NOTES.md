# Personal Game Rules patch notes

Keeps all 19 personal controls, including damage, incoming damage, health, XP and rewards, with 0.1–100x multiplier choices. Keeps solo-only enforcement. All 14 health overlays use V3. Repair retains current valid private settings; restoring returns shared settings to supported public choices.

- Ported to the verified current official 0.2.10 source/package.
- Uses shared transactional install/restore with independent selection.
- Adds no standalone NOTICE.txt.
- Official features already integrated by Addison are not reinstalled.
