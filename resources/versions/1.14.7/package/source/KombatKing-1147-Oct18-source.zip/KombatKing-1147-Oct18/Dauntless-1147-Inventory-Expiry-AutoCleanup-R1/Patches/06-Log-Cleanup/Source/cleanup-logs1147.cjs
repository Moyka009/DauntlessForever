// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path');
function clean(root,{keep=5,ageHours=24,now=Date.now(),dryRun=false}={}){
 if(!Number.isInteger(keep)||keep<1||!Number.isFinite(ageHours)||ageHours<1)throw Error('Invalid retention settings');root=fs.realpathSync(root);
 const groups=new Map();
 for(const dir of ['logs','upload']){
  const folder=path.join(root,dir);if(!fs.existsSync(folder))continue;if(fs.lstatSync(folder).isSymbolicLink())throw Error('Refusing linked log folder');
  for(const name of fs.readdirSync(folder)){
   const p=path.join(folder,name),s=fs.lstatSync(p);if(s.isSymbolicLink())continue;
   let group=null;
   if(dir==='logs'&&s.isDirectory()&&/^run[_-]/i.test(name))group='client runs';
   else if(dir==='logs'&&s.isDirectory()&&/^server_run[_-]/i.test(name))group='server runs';
   else if(dir==='logs'&&s.isFile()&&/^server_[0-9]+(?:_engine)?(?:[_-].*)?\.(?:log|txt)$/i.test(name))group=name.replace(/[_-][0-9]{8}.*$/,'').replace(/\.(log|txt)$/i,'');
   else if(dir==='upload'&&s.isFile()&&/^server_logs(?:[_-].*)?\.zip$/i.test(name))group='server archives';
   else if(dir==='upload'&&s.isFile()&&/^client_logs(?:[_-].*)?\.zip$/i.test(name))group='client archives';
   if(group){const key=dir+'/'+group;if(!groups.has(key))groups.set(key,[]);groups.get(key).push({p,time:s.mtimeMs});}
  }
 }
 const removed=[];for(const entries of groups.values())for(const item of entries.sort((a,b)=>b.time-a.time).slice(keep)){
  if(now-item.time<ageHours*3600000)continue;
  // Skip folders containing any recently changed file or links rather than touch a live run.
  function safe(p){const s=fs.lstatSync(p);if(s.isSymbolicLink()||now-s.mtimeMs<ageHours*3600000)return false;return !s.isDirectory()||fs.readdirSync(p).every(n=>safe(path.join(p,n)));}
  if(!safe(item.p))continue;if(!dryRun)fs.rmSync(item.p,{recursive:true});removed.push(path.relative(root,item.p));
 }
 return{dry_run:dryRun,removed,kept_per_group:keep,minimum_age_hours:ageHours,client_engine_preserved:true};
}
if(require.main===module){try{console.log(JSON.stringify(clean(process.argv[2]||path.resolve(__dirname,'..'),{dryRun:process.argv.includes('--preview')}),null,2));}catch(e){console.error(e.message);process.exitCode=1;}}
module.exports={clean};
