# Build and validation guide

The three default components are 01 Inventory Search, 02 Item Expiry and 06 Log Cleanup. All component buttons delegate to Source/install.cjs. The remaining component folders provide compatibility controls for previously installed Radiant, personal rules and client logging. Source/Official is verified against commit 5a8fe6e4f334ea86904476a117a4785af4632e8f.

Inventory: run `node Patches/01-Inventory-Search/Source/rebuild.cjs --check` to reproduce the 5,805-entry metadata from the included baseline and native role table. The original table decoder/build_catalog.py remains included as historical native extraction source. patch-base.cjs and patch-launcher.cjs transform the four current launcher files; asar.cjs repacks integrity hashes and launcher.cjs patches bundled/active update archives and their checksum pointer.

Expiry: Source/build.py validates the original 1.14.7 manifest and asset hashes, changes only six ExpiryEventId FNames, builds V3 and optionally round-trips through repak. Tests/expiry-overlay.py validates the delivered payload directly with original asset files, without requiring repak. Supply the original Catalogs folder as its argument.

Cleanup: Patches/06-Log-Cleanup/Source/auto-cleanup-logs1147.cjs contains the automatic/manual guarded cleanup API. patch-common.cjs appends its PowerShell startup invocation, preserving the caller's LASTEXITCODE. The retained cleanup-logs1147.cjs is the earlier manual utility.

Tests/install.cjs uses an external official reference checkout and exact original EXE under DAUNTLESS_REFERENCE_WORKSPACE (default: parent folder). It covers all 64 component combinations, rollback, update ASAR checksums, current metadata and default three-component behavior. Tests/current-upgrade.cjs additionally needs the earlier All-in-One R2 folder and tests its actual receipt, updated baselines, partial restore and failed-upgrade rollback. Tests/runtime.cjs uses a full official backend reference; in the audit workspace it overlays the current official backend before starting actual localhost HTTP services.

Tests/search-ui.cjs exercises the patched renderer's real inventory function using a small DOM fixture. Patches/01-Inventory-Search/Source/test-inventory.cjs exercises actual helper edits and the current travel fingerprint guard. Tests/automatic-cleanup.cjs uses isolated old/recent/log/link fixtures and a listening backend port. These checks do not launch the Windows game.

Run `node Source/package.cjs` after intentional source/documentation edits to normalize Windows line endings and regenerate Integrity.json. ZIP the complete folder excluding __pycache__ and *.pyc files. Native Windows gameplay/PowerShell execution remains a separate validation step.
