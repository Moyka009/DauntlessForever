# Automatic log cleanup

Runs through the package's shared startup tools before a new local backend. A running backend causes cleanup to be skipped.

Keeps the newest five per known log/archive group and everything younger than 24 hours. Also keeps current client_engine.log, fixed server/recorder logs and the latest server_logs.zip/client_logs.zip. Linked trees and any folder with recent descendants are skipped. Saves, save backups and unrelated files are outside its scope.

Use Install/Check/Restore in this folder for component 06. Main Install also enables inventory search and item expiry. Install does not delete logs immediately; cleanup runs on the next package tool/game launch. The main Clean-Old-Logs.cmd can also run cleanup manually after stopping everything.

Restore removes the automatic hook/helper while retaining other components. It cannot recover previously deleted logs. Keep the whole extracted bundle together for its shared installer.
