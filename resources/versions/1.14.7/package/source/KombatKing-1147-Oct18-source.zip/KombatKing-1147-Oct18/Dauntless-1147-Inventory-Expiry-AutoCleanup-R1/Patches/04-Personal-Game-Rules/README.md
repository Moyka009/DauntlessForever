# Personal Game Rules — launcher 0.2.10 / game 1.14.7

Keeps all 19 personal controls, including damage, incoming damage, health, XP and rewards, with 0.1–100x multiplier choices. Keeps solo-only enforcement. All 14 health overlays use V3. Repair retains current valid private settings; restoring returns shared settings to supported public choices.

Run this folder's Install.cmd, Check.cmd or Restore.cmd. Keep the whole extracted All-in-One folder together: these buttons use the shared source and restore engine in the main folder. Each component can be installed or restored independently, including after the main Install.cmd installed all of them. Close the game, servers and launcher before changing patches.

Requires official 1.14.7 server package 2026-10-18.5 and completed official Set up. Player saves are retained. A different patch's Restore does not remove this one. Sources and the AGPL-3.0-only license are included.

Automated validation is listed in the main Validation folder. Native Windows gameplay has not been run here.
