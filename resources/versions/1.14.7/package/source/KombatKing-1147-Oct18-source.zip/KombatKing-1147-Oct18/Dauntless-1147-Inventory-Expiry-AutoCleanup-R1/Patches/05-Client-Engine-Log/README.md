# Live client engine log — launcher 0.2.10 / game 1.14.7

Adds a stable live logs\client_engine.log target using Unreal's -abslog, -FORCELOGFLUSH and -LOGTIMES launch options. Keeps official client startup, exit handling and log collection. Does not add packet recording or blocking output pipes.

Run this folder's Install.cmd, Check.cmd or Restore.cmd. Keep the whole extracted All-in-One folder together: these buttons use the shared source and restore engine in the main folder. Each component can be installed or restored independently, including after the main Install.cmd installed all of them. Close the game, servers and launcher before changing patches.

Requires official 1.14.7 server package 2026-10-18.5 and completed official Set up. Player saves are retained. A different patch's Restore does not remove this one. Sources and the AGPL-3.0-only license are included.

Automated validation is listed in the main Validation folder. Native Windows gameplay has not been run here.
