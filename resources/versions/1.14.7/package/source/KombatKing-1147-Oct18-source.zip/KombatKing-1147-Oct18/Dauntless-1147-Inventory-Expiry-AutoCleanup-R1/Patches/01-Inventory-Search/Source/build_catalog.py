# SPDX-License-Identifier: AGPL-3.0-only
"""Build editable inventory metadata from decoded original 1.14.7 tables."""
import sys, json, re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from catalog_reader import table

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('quest1147/assets/Archon/Content/Gameplay/Backend/Catalogs')
out = Path(__file__).resolve().parents[1] / 'Payload/catalog-1147.json'
entries = {}
errors = []
for file in sorted(root.rglob('*.uasset')):
    if any(s in file.stem for s in ['composite', 'obsolete', 'bow_', 'player_role']):
        continue
    try:
        rows = table(file)['rows']
    except Exception as e:
        errors.append([file.stem, str(e)])
        continue
    for row in rows:
        fields = {f['path']: f.get('value') for f in row['fields']}
        if not isinstance(fields.get('/IsStackable'), bool):
            continue
        id = row['id']
        if not re.fullmatch(r'[A-Za-z0-9_-]{3,80}', id):
            continue
        text = fields.get('/DisplayName') or {}
        name = text.get('source', '') if isinstance(text, dict) else ''
        if re.search(r"don't use|do not use|deprecated|test only", name, re.I) or '_PAX' in id:
            continue
        kind = (fields.get('/GenericItemData/Kind') or '').split('::')[-1]
        cosmetic = any(s in file.stem for s in ['cosmetic_catalog', 'dyes_item', 'emotes_', 'emojis_', 'banner_', 'flare_', 'title_', 'character_creator', 'accessory_', 'glider_', 'minipet_'])
        cat = ('Cosmetics' if cosmetic else 'Weapons' if file.stem.startswith('weapon_') and 'part' not in file.stem else 'Weapon parts' if 'weapon_part' in file.stem else 'Armour' if 'armour_gameplay' in file.stem else 'Lanterns' if 'lantern_gameplay' in file.stem else 'Cells' if 'cell_catalog' in file.stem or 'cells_v2' in file.stem else 'Curiosities' if kind == 'Curiosity' else 'Currencies and tokens' if kind in ['Currency', 'Token'] else 'Consumables and materials')
        m = re.search(r'Level_(\d+)', str(fields.get('/StartingUpgradeLevel', 'Level_00')))
        entries[id] = {'id': id, 'name': name or id, 'group': cat, 'storage': 'stack' if fields['/IsStackable'] else 'instance', 'cosmetic': cosmetic, 'singleton': cosmetic or not fields['/IsStackable'], 'level': int(m[1]) if m else 0, 'source': str(file.relative_to(root)).replace('\\', '/')}
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps({'game': '1.14.7 CL647472', 'items': list(entries.values())}, indent=2) + '\n')
print(json.dumps({'entries': len(entries), 'cosmetics': sum(x['cosmetic'] for x in entries.values()), 'decode_errors': errors}))
