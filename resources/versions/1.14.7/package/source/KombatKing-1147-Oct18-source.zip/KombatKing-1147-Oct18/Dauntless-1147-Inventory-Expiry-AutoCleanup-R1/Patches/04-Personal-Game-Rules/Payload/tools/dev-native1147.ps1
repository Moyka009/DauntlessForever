# SPDX-License-Identifier: AGPL-3.0-only
param([Parameter(Mandatory=$true)][int]$ServerPid,[Parameter(Mandatory=$true)][string]$GameExe,[Parameter(Mandatory=$true)][string]$Package)
$ErrorActionPreference='Stop'
try {
    $spec=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'dev-native1147.json') -Raw | ConvertFrom-Json
    if((Get-FileHash -LiteralPath $GameExe -Algorithm SHA256).Hash -ne $spec.exe_sha256){throw 'Requires the verified 1.14.7 CL647472 executable.'}
    $dll=Join-Path $PSScriptRoot 'DevRules1147.dll'
    if((Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash -ne $spec.dll_sha256){throw 'Dev helper failed its integrity check.'}
    if(-not ('DevNative1147' -as [type])){Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'dev-native1147.cs') -Raw)}
    [DevNative1147]::Load($ServerPid,$GameExe,$dll,[int]$spec.status_rva)
    $derived=Get-Content -LiteralPath (Join-Path $Package 'data\dev-rules1147.env')
    if($derived -contains 'unlimited_resupply=1') {
        if(-not ('DevResupply1147' -as [type])){Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'dev-resupply1147.cs') -Raw)}
        [DevResupply1147]::Apply($ServerPid,$GameExe)
    }
    Write-Host 'Personal dev native rules ready.' 
} catch {
    Stop-Process -Id $ServerPid -Force -ErrorAction SilentlyContinue
    throw ('Personal dev rules stopped this server: '+$_.Exception.Message)
}
