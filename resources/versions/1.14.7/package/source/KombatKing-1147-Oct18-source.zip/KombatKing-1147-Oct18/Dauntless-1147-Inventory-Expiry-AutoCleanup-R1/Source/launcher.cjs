// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),{unpack,pack,hash}=require('../Patches/01-Inventory-Search/Source/asar.cjs'),{patchFile}=require('../Patches/01-Inventory-Search/Source/patch-launcher.cjs');
const changed=['src/main/main.js','src/renderer/app.js','src/renderer/index.html','src/renderer/styles.css'];
function cmp(a,b){a=String(a).replace(/^v/,'').split('.').map(x=>parseInt(x,10)||0);b=String(b).replace(/^v/,'').split('.').map(x=>parseInt(x,10)||0);for(let i=0;i<Math.max(a.length,b.length);i++)if((a[i]||0)!==(b[i]||0))return (a[i]||0)<(b[i]||0)?-1:1;return 0;}
function dataRoot(env){if(env.DL_DATA_DIR)return path.resolve(env.DL_DATA_DIR);if(!env.LOCALAPPDATA)throw Error('LOCALAPPDATA is missing');const old=path.join(env.LOCALAPPDATA,'DauntlessOffline');return fs.existsSync(path.join(old,'launcher.json'))||fs.existsSync(path.join(old,'versions'))?old:path.join(env.LOCALAPPDATA,'DauntlessForever');}
function patchArchive(b){const a=unpack(b),files=new Map(a.files);
 const html=files.get(changed[2])?.toString('utf8')||'',main=files.get(changed[0])?.toString('utf8')||'';
 if(html.includes('id="item-search-suggestions"')&&main.includes('catalogIds = new Set()')&&files.get(changed[1])?.includes(Buffer.from('itemSearchOpen'))&&files.get(changed[3])?.includes(Buffer.from('.item-search-suggestions')))return b;
 for(const n of changed){if(!files.has(n))throw Error('Launcher missing '+n);files.set(n,patchFile(n,files.get(n)));}
 const result=pack(a.header,files),check=unpack(result);
 for(const[n,v]of a.files)if(!changed.includes(n)&&!check.files.get(n).equals(v))throw Error('Unexpected launcher change: '+n);
 for(const[n,v]of check.files)if(n.endsWith('.js'))new vm.Script(v.toString('utf8'),{filename:n});
 if(!check.files.get(changed[2]).includes(Buffer.from('id="item-search-suggestions"')))throw Error('Inventory dropdown missing');return result;
}
function prepare(launcher,env){const bundle=path.join(launcher,'resources/app.asar');if(!fs.existsSync(bundle))throw Error('Launcher app.asar not found: '+bundle);
 const original=fs.readFileSync(bundle),version=JSON.parse(unpack(original).files.get('package.json')).version,root=dataRoot(env),pointer=path.join(root,'app-update/current.json');
 let active=bundle,cur=null;
 if(env.DF_NO_APP_UPDATE!=='1'&&fs.existsSync(pointer)){
  cur=JSON.parse(fs.readFileSync(pointer,'utf8').replace(/^\uFEFF/,''));
  if(cur.version&&!cur.bad&&cmp(cur.version,version)>0&&(!cur.minShell||cmp(version,cur.minShell)>=0)&&Number(cur.tries||0)<2){
   if(!/^v?\d+(\.\d+){1,3}([-+][A-Za-z0-9.-]+)?$/.test(cur.version))throw Error('Invalid launcher update version');active=path.join(root,'app-update',cur.version,'app.asar');if(!fs.existsSync(active)||hash(fs.readFileSync(active))!==String(cur.sha256||'').toLowerCase())throw Error('Active launcher update checksum differs');
  }
 }
 const targets=[...new Set([bundle,active])],plan=targets.map(p=>({path:p,after:patchArchive(fs.readFileSync(p)),kind:'launcher'}));
 if(active!==bundle){const updated=plan.find(x=>x.path===active),next={...cur,sha256:hash(updated.after)};plan.push({path:pointer,after:Buffer.from(JSON.stringify(next,null,1)),kind:'pointer',version:cur.version,beforeChecksum:cur.sha256,installedChecksum:next.sha256});}
 return{plan,active};
}
module.exports={prepare,patchArchive,dataRoot,cmp};
