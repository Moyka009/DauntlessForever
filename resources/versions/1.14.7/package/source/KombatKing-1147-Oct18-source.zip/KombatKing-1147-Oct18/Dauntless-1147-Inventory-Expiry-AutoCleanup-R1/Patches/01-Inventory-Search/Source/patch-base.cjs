// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Expected one inventory search anchor: '+a.slice(0,100));return s.replace(a,b);}
function patchFile(name,bytes){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 // Consolidated upgrade: skip the base stage only when that file already has its search change.
 if (name==='src/main/main.js'&&s.includes('itemCatalog, save, running:'))return bytes;
 if (name==='src/renderer/index.html'&&s.includes('id="item-search"'))return bytes;
 if (name==='src/renderer/app.js'&&s.includes("let itemSearchQuery = '', itemSearchLimit = 100;"))return bytes;
 if (name==='src/renderer/styles.css'&&s.includes('.item-search-bar'))return bytes;

 if(name==='src/main/main.js'){
  const a="  return { groups: catalog.groups || [], save, running: R.isRunning(v.id) };";
  s=once(s,a,`  let itemCatalog = [];
  if (v.id === '1.14.7') {
    try {
      const meta = JSON.parse(fs.readFileSync(path.join(v.dataDir, 'tools', 'catalog-1147.json'), 'utf8').replace(/^\\uFEFF/, ''));
      if (meta.game === '1.14.7 CL647472' && Array.isArray(meta.items))
        itemCatalog = meta.items.filter(i => i && typeof i.id === 'string').map(i => ({ id: i.id, name: i.name || i.id, group: i.group || '' }));
    } catch {}
  }
  return { groups: catalog.groups || [], itemCatalog, save, running: R.isRunning(v.id) };`);
 }else if(name==='src/renderer/index.html'){
  s=once(s,'    <div id="item-groups"></div>',`    <div class="item-search-bar">
      <label for="item-search">Search inventory</label>
      <div class="item-search-controls"><input id="item-search" type="search" placeholder="Search by item name or ID" autocomplete="off" spellcheck="false" aria-describedby="item-search-count"><button class="ghost" id="item-search-clear" type="button">Clear search</button></div>
      <p class="small" id="item-search-count" role="status" aria-live="polite"></p>
    </div>
    <div id="item-groups"></div>`);
  s=once(s,'      <div class="season-list" id="item-other"></div>',`      <div class="season-list" id="item-other"></div>
      <button class="ghost" id="item-search-more" type="button" hidden>Show 100 more</button>`);
 }else if(name==='src/renderer/styles.css'){
  s+='\n/* Inventory name / ID search */\n.item-search-bar { margin: 18px 0; }\n.item-search-bar > label { display: block; margin-bottom: 8px; color: var(--ink-2); font-size: 13px; }\n.item-search-controls { display: flex; gap: 8px; align-items: center; }\n.item-search-controls input { flex: 1; min-width: 0; background: var(--bg); color: var(--ink); border: 1px solid var(--line-2); border-radius: 6px; padding: 10px 12px; font: inherit; font-size: 14px; }\n.item-search-controls input:focus { outline: 2px solid var(--ember); outline-offset: 2px; }\n.item-search-controls button { flex: 0 0 auto; }\n#item-search-count { min-height: 20px; margin: 8px 0 0; }\n#item-search-more { margin-top: 12px; }\n@media (max-width: 600px) { .item-search-controls { flex-wrap: wrap; } .item-search-controls input { flex-basis: 100%; } }\n';
 }else if(name==='src/renderer/app.js'){
  const a='const fmtN = n => Number(n || 0).toLocaleString(\'en-US\');';
  s=once(s,a,a+`
let itemSearchQuery = '', itemSearchLimit = 100;
const itemSearchText = value => String(value || '').normalize('NFKD').replace(/[\\u0300-\\u036f]/g, '').toLowerCase().replace(/_/g, ' ');
const itemMatchesSearch = (id, name) => itemSearchText(itemSearchQuery).trim().split(/\\s+/).filter(Boolean).every(term => itemSearchText(id + ' ' + (name || '')).includes(term));
`);
  s=once(s,'  const known = new Set();',`  const search = $('item-search');
  if (search.value !== itemSearchQuery) search.value = itemSearchQuery;
  const clearSearch = () => { itemSearchQuery = ''; itemSearchLimit = 100; renderItems(false); search.focus(); };
  search.oninput = () => { itemSearchQuery = search.value; itemSearchLimit = 100; renderItems(false); };
  search.onkeydown = e => { if (e.key === 'Escape') { e.preventDefault(); clearSearch(); } };
  $('item-search-clear').onclick = clearSearch;
  $('item-search-clear').disabled = !itemSearchQuery;
  const searching = !!itemSearchQuery.trim(), matched = new Set();
  const labels = new Map((cur.d.itemCatalog || []).map(i => [i.id, i]));
  const displayName = id => labels.get(id)?.name || id.replace(/_/g, ' ').toLowerCase().replace(/\\b\\w/g, c => c.toUpperCase());
  const known = new Set();`);
  const a2=`  for (const g of cur.d.groups) {
    const h = document.createElement('h2'); h.className = 'list-head'; h.textContent = g.title; host.appendChild(h);
    const list = document.createElement('div'); list.className = 'season-list';
    for (const it of g.items) { known.add(it.id); list.appendChild(row(it.id, it.name, it.blurb)); }
    host.appendChild(list);
  }
  renderGear(cur, ch, note);
  const other = $('item-other'); other.innerHTML = '';
  const otherIds = [...new Set([...Object.keys(ch.items), ...Object.keys(itemPending)])].filter(id => !known.has(id)).sort();
  for (const id of otherIds) other.appendChild(row(id, id.replace(/_/g, ' ').toLowerCase().replace(/\\b\\w/g, c => c.toUpperCase()), ''));
  $('item-more-n').textContent = otherIds.length;`;
  s=once(s,a2,`  for (const g of cur.d.groups) {
    for (const it of g.items) known.add(it.id);
    const shown = g.items.filter(it => itemMatchesSearch(it.id, it.name + ' ' + (labels.get(it.id)?.name || '')));
    if (!shown.length) continue;
    const h = document.createElement('h2'); h.className = 'list-head'; h.textContent = g.title; host.appendChild(h);
    const list = document.createElement('div'); list.className = 'season-list';
    for (const it of shown) { matched.add(it.id); list.appendChild(row(it.id, it.name, it.blurb)); }
    host.appendChild(list);
  }
  renderGear(cur, ch, note);
  if (Array.isArray(ch.gear)) {
    const names = new Map((cur.d.save.gearCatalog || []).map(g => [g[0], g[1]]));
    for (const g of ch.gear) if (itemMatchesSearch(g.id, names.get(g.id) || g.id)) matched.add(g.id);
  }
  const other = $('item-other'); other.innerHTML = '';
  const otherIds = [...new Set([...Object.keys(ch.items), ...Object.keys(itemPending), ...(searching ? labels.keys() : [])])]
    .filter(id => !known.has(id) && itemMatchesSearch(id, displayName(id))).sort((a, b) => displayName(a).localeCompare(displayName(b)) || a.localeCompare(b));
  for (const id of otherIds) matched.add(id);
  const shownIds = searching ? otherIds.slice(0, itemSearchLimit) : otherIds;
  for (const id of shownIds) other.appendChild(row(id, displayName(id), labels.get(id)?.group || ''));
  $('item-more-n').textContent = otherIds.length;
  if (searching) $('item-more').open = true;
  const more = $('item-search-more'); more.hidden = !searching || shownIds.length >= otherIds.length;
  more.onclick = () => { itemSearchLimit += 100; renderItems(false); };
  const hiddenMatches = otherIds.length - shownIds.length;
  $('item-search-count').textContent = !searching ? 'Search by name or ID. Choose amounts, then save your changes.'
    : !matched.size ? 'No matching items. Try another name or item ID.'
    : hiddenMatches ? 'Showing ' + (matched.size - hiddenMatches) + ' of ' + matched.size + ' matching items. Use Show 100 more below.'
    : matched.size + ' matching item' + (matched.size === 1 ? '' : 's') + '.';`);
  s=once(s,"  const owned = ch.gear.map(g =>", "  const owned = ch.gear.filter(g => itemMatchesSearch(g.id, (names.get(g.id) || [g.id, g.id])[1])).map(g =>");
  s=once(s,"  if (!owned.length) host.innerHTML = '<div class=\"season-row\"><div class=\"season-kind\">No gear yet.</div></div>';", "  if (!owned.length) host.innerHTML = '<div class=\"season-row\"><div class=\"season-kind\">' + (itemSearchQuery.trim() ? 'No matching gear.' : 'No gear yet.') + '</div></div>';");
 }else throw Error('Unexpected launcher file: '+name);
 return Buffer.from(s.replaceAll('\n',nl));
}
module.exports={patchFile};
