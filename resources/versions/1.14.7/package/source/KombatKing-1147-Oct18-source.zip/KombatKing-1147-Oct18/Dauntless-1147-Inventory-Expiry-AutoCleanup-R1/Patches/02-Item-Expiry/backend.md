# Item expiry files

No backend changes. Installs Archon/Content/Paks/zzzzzzzzzzzzzzzz_ItemExpiry1147_P.pak, format V3. The overlay replaces quick_item_catalog and Token_Catalogs/tokens_general_catalog asset pairs, clearing only the six recorded ExpiryEventId FNames.

The original 1.14.7 CL647472 manifest SHA1 is aa70748e4c0a776a991f2bac10ad342adaa31476. Original asset SHA256 values, field offsets, before/after values and payload hash are in this folder's source/manifest. Tests/expiry-overlay.py reproduces the delivered bytes from those originals.

The current official equipment overlay affects a different weapon catalog. The shared installer checks extra overlays for conflicts, uses the exact game build and supports independent removal without modifying inventory or other selected components.
