// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),root=__dirname,read=n=>JSON.parse(fs.readFileSync(path.join(root,n)));
const data=read('catalog-before.json'),roles=read('Native/player_role_catalog.json').rows,names={PR_BASTION:'Bastion',PR_DISCIPLINE:'Discipline',PR_ICEBORNE:'Iceborne',PR_TEMPEST:'Tempest',PR_DARKNESS:'Revenant',PR_FRANK:'Artificer'};
for(const r of roles){assert.equal(r.fields.find(f=>f.path==='/IsStackable').value,false);assert(names[r.id]);assert(!data.items.some(i=>i.id===r.id));data.items.push({id:r.id,name:names[r.id],group:'Omnicells',storage:'instance',cosmetic:false,singleton:true,level:0,source:'Gear_Catalogs/player_role_catalog.uasset'});}
assert.equal(data.items.length,5805);const bytes=Buffer.from(JSON.stringify(data,null,2)+'\n');if(process.argv.includes('--check'))assert(fs.readFileSync(path.join(root,'catalog-1147.json')).equals(bytes));else fs.writeFileSync(path.join(root,'catalog-1147.json'),bytes);console.log('PASS all 5805 catalog entries reproduced, including six native Omnicells.');
