# Inventory name/ID search

Updated for launcher 0.2.10 and official 1.14.7 package 2026-10-18.5. Search by item name or ID, choose a two-line suggestion, set the amount and save. The 5,805-entry catalog now includes all six native Omnicells.

Use this folder's Install, Check and Restore buttons for component 01, or main Install for inventory, expiry and automatic cleanup together. Keep the complete extracted bundle together.

The helper edits your own account, uses native stack/instance storage, keeps exact prior-save backups and refuses editing while the backend is running. Existing equipment upgrades/cells/parts are preserved. The current official local-travel fingerprint guard remains intact.
