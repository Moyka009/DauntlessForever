# Inventory search update

- Update compatibility to official 1.14.7 package 2026-10-18.5 and verified launcher 0.2.10 source.
- Retain name/ID search, two-line dropdown, keyboard selection, name-based adds and version selection.
- Add Bastion, Discipline, Iceborne, Tempest, Revenant and Artificer using actual PR_* equipment IDs; metadata now contains 5,805 entries.
- Retain native storage, singleton limits, own-account isolation, equipment data and prior-save backups.
- Verify current official travel code protects edited inventory from an older pending host save.
- Patch bundled and active launcher-update archives with matching checksum updates.
- Keep independent Install/Check/Restore and existing component selections.
