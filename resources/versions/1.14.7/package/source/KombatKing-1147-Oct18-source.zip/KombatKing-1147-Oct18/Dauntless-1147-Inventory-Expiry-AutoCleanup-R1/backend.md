# Backend and file changes

Baseline: launcher source 0.2.10 and official 1.14.7 server package 2026-10-18.5, commit 5a8fe6e4f334ea86904476a117a4785af4632e8f. Source/Official and Source/official-audit.json identify the exact reviewed inputs.

The three requested components do not add backend endpoints or alter Trials data. Inventory changes tools/items.js, its native item metadata and four launcher inventory files. Item expiry installs the existing V3 asset overlay. Automatic cleanup adds tools/auto-cleanup-logs1147.cjs and appends a guarded invocation to tools/common.ps1; it preserves the existing manual cleanup helper.

When an existing installation also has Radiant selected, the shared installer composes that existing module onto the current official recorder. Personal rules and client logging are likewise retained if already selected. Their implementation is documented in their component backend.md files.

The installer reuses the All-in-One R2 receipt so shared files and earlier selections remain coordinated. Current official restore baselines are written to new backup files when their hashes changed, preserving earlier backup bytes. This prevents an updated Radiant restore from rolling the current official recorder back to an older package. Caught write/receipt failures roll back files, new backup writes and the receipt.

Main Install/Check/Restore now target inventory, expiry and cleanup by default, retaining other selections. Every component can still be managed separately. Unknown edits and interrupted transactions are refused; official updates that match the reviewed current baseline can be recomposed.

Installation does not edit player saves, account keys, Trials expansion files or existing personal choices. The current travel fingerprint protection remains intact. Automatic cleanup operates only inside known log/upload groups, preserves recent/current files, and does not touch saves or backups. Restore stops future cleanup but cannot recover logs already deleted.
