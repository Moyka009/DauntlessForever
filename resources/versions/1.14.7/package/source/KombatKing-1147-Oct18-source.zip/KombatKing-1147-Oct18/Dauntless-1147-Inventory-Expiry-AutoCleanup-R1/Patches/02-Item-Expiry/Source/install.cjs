// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const main=require('../../../Source/install.cjs');
function install(root,launcher,action='install',options={}){return main.install(root,launcher,action,{...options,component:'02'});}
module.exports={install};
if(require.main===module){try{const result=install(process.argv[3],process.argv[4],process.argv[2]);console.log(JSON.stringify(result,null,2));if(process.argv[2]==='check'&&!result.installed)process.exitCode=1;}catch(e){console.error(e.message);process.exitCode=1;}}
