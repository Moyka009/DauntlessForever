// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function patch(bytes){let text=bytes.toString('utf8');const marker='# KK-AUTO-LOG-CLEANUP-1147-R1';if(text.includes(marker))return Buffer.from(text);if(!text.includes('function Get-Config')||!text.includes('function Find-Node'))throw Error('Unexpected 1.14.7 common.ps1');const nl=text.includes('\r\n')?'\r\n':'\n';
 const hook=`
# KK-AUTO-LOG-CLEANUP-1147-R1
# AGPL-3.0-only. Run before a new local backend; the helper skips a running backend.
& {
    $cleanupPriorExit1147 = $global:LASTEXITCODE
    try {
        $cleanupConfig1147 = Get-Config
        if ($cleanupConfig1147) {
            $cleanupNode1147 = $cleanupConfig1147.Node
            if (-not $cleanupNode1147 -or -not (Test-Path -LiteralPath $cleanupNode1147)) { $cleanupNode1147 = Find-Node }
            $cleanupFile1147 = Join-Path $PSScriptRoot 'auto-cleanup-logs1147.cjs'
            if ($cleanupNode1147 -and (Test-Path -LiteralPath $cleanupFile1147)) {
                & $cleanupNode1147 $cleanupFile1147 $Root --auto | Out-Host
            }
        }
    } catch { Say ("Automatic log cleanup skipped: " + $_.Exception.Message) 'Yellow' }
    finally { $global:LASTEXITCODE = $cleanupPriorExit1147 }
}
`;
 return Buffer.from(text+hook.replace(/\n/g,nl));
}
module.exports={patch};
