# Live client engine log patch notes

Adds a stable live logs\client_engine.log target using Unreal's -abslog, -FORCELOGFLUSH and -LOGTIMES launch options. Keeps official client startup, exit handling and log collection. Does not add packet recording or blocking output pipes.

- Ported to the verified current official 0.2.10 source/package.
- Uses shared transactional install/restore with independent selection.
- Adds no standalone NOTICE.txt.
- Official features already integrated by Addison are not reinstalled.
