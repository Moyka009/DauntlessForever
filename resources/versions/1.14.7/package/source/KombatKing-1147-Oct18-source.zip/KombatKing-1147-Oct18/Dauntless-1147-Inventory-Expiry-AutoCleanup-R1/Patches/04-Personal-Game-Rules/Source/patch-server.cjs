// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function quotedFilters(text){return text.replaceAll('-Include *.log, *.txt, *.xml, *.runtime-xml',"-Include '*.log', '*.txt', '*.xml', '*.runtime-xml'").replaceAll('-Include *.log, *.xml, *.runtime-xml, *.txt',"-Include '*.log', '*.xml', '*.runtime-xml', '*.txt'");}
function patch(text){
 const prepare=`# Personal dev settings: refuse hosted use and prepare inputs before any server starts.\n$ErrorActionPreference = 'Stop'\n$devNode = $cfg.Node\nif (-not $devNode -or -not (Test-Path -LiteralPath $devNode)) { $devNode = Find-Node }\n$env:DF_PERSONAL1147_FILE = & $devNode (Join-Path $PSScriptRoot 'dev-rules1147.cjs') $WorkDir $cfg.GameDir\nif ($LASTEXITCODE -ne 0) { throw 'Personal dev rule preparation failed.' }\n`;
 const anchor='# environment for the server copy only';if(text.split(anchor).length!==2)throw Error('Unsupported server launch script');text=text.replace(anchor,prepare+anchor);
 for(const variable of ['p','hp']){const re=new RegExp('(^[ \\t]*\\$'+variable+' = Start-Process[^\\r\\n]+)(\\r?\\n)','m');if(!re.test(text))throw Error('Server launch anchor missing: '+variable);text=text.replace(re,(_,line,nl)=>line+nl+`    & (Join-Path $PSScriptRoot 'dev-native1147.ps1') -ServerPid $${variable}.Id -GameExe $exe -Package $WorkDir`+nl);}
 return quotedFilters(text);
}
function patchPlay(text){const anchor=". (Join-Path $PSScriptRoot 'common.ps1')";if(text.split(anchor).length!==2)throw Error('Unsupported client launch script');return quotedFilters(text.replace(anchor,anchor+"\nif ($JoinHost -or $EosDirOverride -or $env:DF_HOSTING -eq '1') { throw 'Personal dev rules are solo-only. Restore the personal patch before joining or hosting.' }\n"));}
module.exports={patch,patchPlay};
