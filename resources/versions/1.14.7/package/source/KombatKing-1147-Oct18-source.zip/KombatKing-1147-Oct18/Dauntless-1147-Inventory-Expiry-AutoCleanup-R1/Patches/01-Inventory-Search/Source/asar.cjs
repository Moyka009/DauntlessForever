// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const crypto=require('crypto'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function unpack(bytes){
 if(bytes.length<16||bytes.readUInt32LE(0)!==4)throw Error('Invalid ASAR header');
 const headerSize=bytes.readUInt32LE(4),payloadSize=bytes.readUInt32LE(8),jsonSize=bytes.readUInt32LE(12),base=8+headerSize;
 if(headerSize!==payloadSize+4||jsonSize+4>payloadSize||base>bytes.length)throw Error('Invalid ASAR bounds');
 const header=JSON.parse(bytes.subarray(16,16+jsonSize).toString('utf8')),files=new Map();
 function walk(tree,prefix=''){for(const[n,e]of Object.entries(tree.files||{})){if(!n||n.includes('/')||n.includes('\\')||n==='.'||n==='..')throw Error('Invalid ASAR path');const name=prefix+n;
  if(e.files)walk(e,name+'/');else{
   if(e.unpacked||e.link||e.offset===undefined||!Number.isSafeInteger(e.size)||e.size<0||!/^\d+$/.test(e.offset))throw Error('Unsupported ASAR entry: '+name);
   const off=Number(e.offset);if(!Number.isSafeInteger(off)||base+off+e.size>bytes.length)throw Error('ASAR file exceeds archive');
   const data=bytes.subarray(base+off,base+off+e.size);
   if(e.integrity){const i=e.integrity;if(i.algorithm!=='SHA256'||hash(data)!==i.hash||!Number.isSafeInteger(i.blockSize)||i.blockSize<1)throw Error('ASAR integrity mismatch: '+name);const blocks=[];for(let n=0;n<data.length;n+=i.blockSize)blocks.push(hash(data.subarray(n,n+i.blockSize)));if(JSON.stringify(blocks)!==JSON.stringify(i.blocks))throw Error('ASAR block mismatch: '+name);}
   files.set(name,data);
  }
 }}walk(header);return{header,files};
}
function pack(header,files){header=JSON.parse(JSON.stringify(header));const payload=[];let offset=0;
 function walk(tree,prefix=''){for(const[n,e]of Object.entries(tree.files)){const name=prefix+n;if(e.files)walk(e,name+'/');else{const data=files.get(name);if(!Buffer.isBuffer(data))throw Error('Missing ASAR file: '+name);e.offset=String(offset);e.size=data.length;offset+=data.length;payload.push(data);
  if(e.integrity){const size=e.integrity.blockSize,blocks=[];for(let n=0;n<data.length;n+=size)blocks.push(hash(data.subarray(n,n+size)));e.integrity={algorithm:'SHA256',hash:hash(data),blockSize:size,blocks};}
 }}}walk(header);
 const json=Buffer.from(JSON.stringify(header)),padding=(4-json.length%4)%4,head=Buffer.alloc(16+json.length+padding);
 head.writeUInt32LE(4,0);head.writeUInt32LE(head.length-8,4);head.writeUInt32LE(head.length-12,8);head.writeUInt32LE(json.length,12);json.copy(head,16);
 return Buffer.concat([head,...payload]);
}
module.exports={unpack,pack,hash};
