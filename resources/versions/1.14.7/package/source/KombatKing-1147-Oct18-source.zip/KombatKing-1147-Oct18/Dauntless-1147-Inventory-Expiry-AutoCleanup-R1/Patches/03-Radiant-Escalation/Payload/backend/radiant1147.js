// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const data=require('./radiant1147-data.json'),clone=x=>JSON.parse(JSON.stringify(x));
const fail=(status,message)=>{const e=Error(message);e.status=status;throw e;};
const object=x=>x&&typeof x==='object'&&!Array.isArray(x),integer=(x,min,max)=>Number.isSafeInteger(x)&&x>=min&&x<=max;
const empty=()=>({escalation_level:0,next_level_xp:data.levels[0],talents_progress:[],unlock_progress:[],update_version:0});
function hunt(b){if(!object(b)||!Array.isArray(b.hunts))return null;return data.hunts[b.hunts[0]]||null;}
function destination(b){const h=hunt(b);if(!h)return null;if(b.gameMode!=='ISLAND'||b.gameType!=='ESCALATION')fail(400,'Radiant hunt requires ISLAND/ESCALATION');if(b.hunts.length!==1)fail(400,'Select a single Radiant Escalation queue');return{city:false,label:'Radiant Escalation '+h.modeSpec,url:data.map+'?MaxPlayers=4?TODClass='+data.tod+'?HuntID='+b.hunts[0]};}
function prepare(b,p){const h=hunt(b);if(!h)return b;destination(b);if(b.playerHuntId&&b.playerHuntId!==h.playerHuntId)fail(400,'Radiant hunt and difficulty do not match');if(h.minLevel>Number(p.escalation?.[data.season]?.escalation_level||0))fail(403,'Heroic Radiant requires escalation talent level '+h.minLevel);return {...b,playerHuntId:h.playerHuntId};}
function travel(dest,b,p){const h=hunt(b);if(!h)return dest;if(!/^[A-Z2-7]{26}$/.test(p.accountId))fail(400,'Invalid Radiant account');return{...dest,url:dest.url+'?PlayerHuntIds='+p.accountId+':'+h.playerHuntId};}
function validate(src){
 if(!object(src)||!integer(src.escalation_level,0,25)||!integer(src.next_level_xp,0,10000)||!integer(src.update_version,0,2147483647))fail(400,'Invalid Radiant level, XP or update version');
 const level=src.escalation_level,xp=src.next_level_xp;if(level<25&&xp>data.levels[level])fail(400,'Radiant remaining XP exceeds the native level requirement');
 if(!Array.isArray(src.talents_progress)||src.talents_progress.length>64||!Array.isArray(src.unlock_progress)||src.unlock_progress.length>128)fail(400,'Invalid Radiant talent/reward list');
 const seen=new Set();let spent=0;const talents=src.talents_progress.map(t=>{const def=data.talents[t?.talent_id];if(!object(t)||!def||seen.has(t.talent_id)||!integer(t.rank,0,def.costs.length))fail(400,'Invalid or duplicate Radiant talent');seen.add(t.talent_id);spent+=def.costs.slice(0,t.rank).reduce((a,b)=>a+b,0);return{talent_id:t.talent_id,rank:t.rank};});
 if(spent>level)fail(400,'Radiant talents spend more points than earned');seen.clear();
 const unlocks=src.unlock_progress.map(u=>{if(!object(u)||typeof u.reward_id!=='string'||!/^[A-Za-z0-9_]{1,128}$/.test(u.reward_id)||typeof u.collected!=='boolean'||seen.has(u.reward_id))fail(400,'Invalid Radiant reward progress');seen.add(u.reward_id);return{reward_id:u.reward_id,collected:u.collected};});
 return{escalation_level:level,next_level_xp:xp,talents_progress:talents,unlock_progress:unlocks,update_version:src.update_version};
}
function ensurePath(map){
 for(const id of ['Escalation.Easy.Radiant','Escalation.Hard.Radiant'])if(!map.nodes[id])map.nodes[id]={node_id:id,node_status:0,objectives:[]};
 return map;
}
function create(ctx){
 const ok=s=>({status:200,json:{code:null,message:'OK',payload:clone(s)},note:'Radiant Escalation saved state'});
 function account(c,id){const p=ctx.getPlayers().find(p=>p.accountId===id);if(!p)fail(404,'Radiant account not found');const token=ctx.bearerOf(c.req);if(token&&ctx.sessions.has(token)&&ctx.playerFor(c.req)!==p)fail(403,'Radiant account does not match session');return p;}
 function normalized(p){const cur=p.escalation?.[data.season];if(!cur)return empty();const copy=clone(cur);
  // Retain the level of the old default stub, but give it a valid native XP countdown.
  if(copy.escalation_level===1&&copy.next_level_xp===0&&!(copy.talents_progress||[]).length&&!(copy.unlock_progress||[]).length)copy.next_level_xp=data.levels[1];
  return copy;
 }
 function handle(c){const m=/^\/escalation\/ESC_SEASON_6\/([A-Z2-7]{26})\/?$/.exec(c.path);if(c.service!=='progression'||!m||!['GET','POST'].includes(c.method))return ctx.next(c);const p=account(c,m[1]),cur=normalized(p);
  if(c.method==='GET')return ok(cur);
  const src=object(c.body?.payload)?c.body.payload:c.body,next=validate(src);
  if(next.update_version<(cur.update_version||0)||next.escalation_level<cur.escalation_level||(next.escalation_level===cur.escalation_level&&next.next_level_xp>cur.next_level_xp))return{status:409,json:{code:'stale_escalation',message:'Reload current Radiant progress',payload:clone(cur)},note:'Rejected stale Radiant snapshot; saved progress retained'};
  // Collected rewards cannot become uncollected when another server sends an older snapshot.
  for(const u of cur.unlock_progress||[])if(u.collected){const found=next.unlock_progress.find(x=>x.reward_id===u.reward_id);if(found)found.collected=true;else next.unlock_progress.push(clone(u));}
  if(JSON.stringify(next)===JSON.stringify(cur))return ok(cur);
  const before=p.escalation?clone(p.escalation):undefined;p.escalation??={};p.escalation[data.season]=next;
  try{ctx.saveState();}catch(e){if(before===undefined)delete p.escalation;else p.escalation=before;throw e;}
  return ok(next);
 }
 return{handle};
}
module.exports={create,destination,prepare,travel,empty,validate,ensurePath,data};
