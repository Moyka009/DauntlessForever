// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=path.resolve(__dirname,'..'),ids=['01','02','03','04','05','06'],defaultIds=['01','02','06'],folders=fs.readdirSync(path.join(base,'Patches')).sort(),hash=b=>crypto.createHash('sha256').update(b).digest('hex'),read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'')),bytes=p=>fs.existsSync(p)?fs.readFileSync(p):null;
const src=id=>path.join(base,'Patches',folders.find(f=>f.startsWith(id+'-'))),official=n=>fs.readFileSync(path.join(__dirname,'Official',n)),walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
function write(p,b){if(path.basename(p).toLowerCase()==='notice.txt')throw Error('Standalone notice writes are prohibited');if(b===null){fs.rmSync(p,{force:true});return;}fs.mkdirSync(path.dirname(p),{recursive:true});const t=p+'.aio-'+crypto.randomUUID();try{fs.writeFileSync(t,b,{flag:'wx'});fs.renameSync(t,p);}finally{fs.rmSync(t,{force:true});}}
function verify(){for(const[n,h]of Object.entries(read(path.join(base,'Integrity.json')).files)){if(path.isAbsolute(n)||n.split('/').includes('..')||hash(fs.readFileSync(path.join(base,n)))!==h)throw Error('Bundle integrity mismatch: '+n);}}
function setup(root,launcher,game){const m=read(path.join(__dirname,'version.json'));if(hash(fs.readFileSync(path.join(game,m.exeRel)))!==m.exeSha256.toLowerCase())throw Error('Requires Dauntless 1.14.7 CL647472');
 const metadata=[path.join(root,'version.json'),path.join(launcher,'resources/versions/1.14.7/version.json')].filter(p=>fs.existsSync(p));if(!metadata.length)throw Error('Official 1.14.7 launcher metadata is missing');const cmp=require('./launcher.cjs').cmp,active=metadata.map(read).reduce((a,b)=>cmp(a.package?.packageVersion||'',b.package?.packageVersion||'')>=0?a:b);if(active.package.packageVersion!==m.package.packageVersion)throw Error('This patch requires official 1.14.7 server files '+m.package.packageVersion+' from launcher 0.2.10; run the official update and Set up first');
 for(const item of m.package.installedFiles){const b=bytes(path.join(game,item.rel));if(!b||hash(b)!==item.sha256.toLowerCase())throw Error('Complete official Set up first; installed file differs: '+item.rel);}
 if(!fs.existsSync(path.join(root,'eos/eos_offline.ini'))||!fs.existsSync(path.join(root,'captures')))throw Error('Complete official Set up first');
}
function compose(selected,root,game){const has=id=>selected.includes(id),map=new Map(),put=(n,b,extra={})=>map.set(n,{rel:n,after:b,...extra});
 let server=official('tools/server-1147.ps1').toString(),play=official('tools/play-1147.ps1').toString();
 if(has('01'))for(const n of ['items.js','catalog-1147.json'])put('tools/'+n,fs.readFileSync(path.join(src('01'),'Source',n)));
 if(has('02')){const m=read(path.join(src('02'),'manifest.json'));put('paks/'+m.pak,fs.readFileSync(path.join(src('02'),'Payload',m.pak)),{pak:true});}
 if(has('03')){
  const s=src('03');put('backend/recorder-1147.js',require(path.join(s,'Source/patch-current.cjs')).patch(official('backend/recorder-1147.js')));
  for(const n of ['radiant1147.js','radiant1147-data.json'])put('backend/'+n,fs.readFileSync(path.join(s,'Payload/backend',n)));
  for(const n of fs.readdirSync(path.join(s,'Payload/paks')))put('paks/'+n,fs.readFileSync(path.join(s,'Payload/paks',n)),{pak:true});
 }
 const settings=bytes(path.join(root,'data/rules.txt'))||Buffer.alloc(0);let nextSettings=settings;
 if(has('04')){
  const s=src('04'),defs=read(path.join(s,'Payload/rules.json')),helper=require(path.join(s,'Payload/tools/dev-rules1147.cjs')),values=helper.parse(defs,settings.toString());
  for(const p of walk(path.join(s,'Payload'))){const n=path.relative(path.join(s,'Payload'),p).replaceAll('\\','/');put(n,fs.readFileSync(p));}
  const patch=require(path.join(s,'Source/patch-server.cjs'));server=patch.patch(server);play=patch.patchPlay(play);
  nextSettings=Buffer.from('# Personal 1.14.7 rules. Restart the game and servers to apply.\r\n'+defs.rules.map(r=>r.key+'='+values[r.key]).join('\r\n')+'\r\n');
  put('data/dev-rules1147.env',Buffer.from(Object.entries({...values,escalation_rate:Math.min(100,values.universal_xp*values.escalation_xp)}).map(([k,v])=>k+'='+v).join('\n')+'\n'),{mutable:true});
  put('paks/zzzzzzzzzzzzzzzzzz_DevHealth1147_P.pak',fs.readFileSync(path.join(s,'Payload/tools/dev-health1147','health-'+values.health+'.pak')),{pak:true,health:true});
 }
 if(has('05'))play=require(path.join(src('05'),'Source/patch.cjs')).patch(play);
 if(has('04'))put('tools/server-1147.ps1',Buffer.from(server));if(has('04')||has('05'))put('tools/play-1147.ps1',Buffer.from(play));
 if(has('06')){
  put('tools/cleanup-logs1147.cjs',fs.readFileSync(path.join(src('06'),'Source/cleanup-logs1147.cjs')));
  put('tools/auto-cleanup-logs1147.cjs',fs.readFileSync(path.join(src('06'),'Source/auto-cleanup-logs1147.cjs')));
  put('tools/common.ps1',require(path.join(src('06'),'Source/patch-common.cjs')).patch(official('tools/common.ps1')));
 }
 return{files:map,settings:nextSettings};
}
function restoreSettings(current){const defs=JSON.parse(official('rules.json')),picked={};for(const l of current.toString().split(/\r?\n/)){const m=/^\s*([a-z_]+)\s*=\s*([0-9.]+)\s*$/.exec(l);if(m)picked[m[1]]=Number(m[2]);}return Buffer.from(defs.rules.map(r=>{const choices=r.choices.map(c=>Number(c[0])),v=picked[r.key]??Number(r.default);return r.key+'='+choices.reduce((a,b)=>Math.abs(b-v)<Math.abs(a-v)?b:a);}).join('\r\n')+'\r\n');}
function install(root,launcher,action='install',options={}){
 if(!['install','restore','check','clean'].includes(action))throw Error('Unknown operation');verify();root=fs.realpathSync(root);launcher=fs.realpathSync(launcher);const component=options.component||'all';if(component!=='all'&&!ids.includes(component))throw Error('Unknown component');
 const cfg=read(path.join(root,'config.json')),game=fs.realpathSync(cfg.GameDir),dir=path.join(root,'backup/all-in-one1147-r2-0210'),receipt=path.join(dir,'installation.json');
 if(fs.existsSync(path.join(dir,'pending.json')))throw Error('Interrupted transaction. Keep backup/all-in-one1147-r2-0210 for recovery');
 if(action==='clean')return require(path.join(src('06'),'Source/auto-cleanup-logs1147.cjs')).clean(root,options.cleanup||{});
 const r=fs.existsSync(receipt)?read(receipt):null;if(r&&(r.root!==root||r.game!==game||r.launcher!==launcher))throw Error('Restore record belongs to another installation');
 if(action!=='restore')setup(root,launcher,game);
 const known=read(path.join(__dirname,'legacy-hashes.json')),healthHashes=read(path.join(src('04'),'Source/compatibility.json')).health_hashes;
 const good=t=>{const b=bytes(t.path);if(t.mutable)return true;if(t.kind==='pointer'){if(!b)return false;const p=JSON.parse(b);return p.version===t.version&&p.sha256===t.installedChecksum;}return b!==null&&(hash(b)===t.after||t.health&&healthHashes.includes(hash(b)));};
 if(r)for(const t of r.files){if(!t.active)continue;if(good(t))continue;
  const b=bytes(t.path),off=path.join(__dirname,'Official',t.rel||'');if(action==='restore'||!b||!t.rel||!fs.existsSync(off)||!b.equals(fs.readFileSync(off)))throw Error('A managed file changed; no files overwritten: '+t.path);
 }
 const previous=r?.selected||[];
 const requested=component==='all'?(options.includeAll?ids:defaultIds):[component];
 if(action==='check')return{installed:!!r&&requested.every(id=>previous.includes(id))&&r.files.filter(t=>t.active).every(good),selected:previous,requested,official_fixes:'retained; not reinstalled',native_game_test:'pending'};
 if(action==='restore'&&!r)throw Error('No installation record for this updated bundle');
 let selected=action==='install'?[...new Set([...previous,...requested])]:previous.filter(id=>!requested.includes(id));selected=ids.filter(id=>selected.includes(id));
 const composed=compose(selected,root,game),desired=new Map();for(const[n,t]of composed.files)desired.set(t.pak?path.join(game,'Archon/Content/Paks',path.basename(n)):path.join(root,n),t);
 if(selected.includes('01'))for(const t of require('./launcher.cjs').prepare(launcher,options.env||process.env).plan)desired.set(t.path,{...t,rel:null,after:t.after});
 const protectedAssets=new Set();for(const t of composed.files.values())if(t.pak)for(const a of require('./paks.cjs').entries(path.join(t.rel.includes('ItemExpiry')?src('02')+'/Payload':t.health?src('04')+'/Payload/tools/dev-health1147':src('03')+'/Payload/paks',t.health?'health-1.pak':path.basename(t.rel))))protectedAssets.add(a);
 const ownedNames=new Set(['zzzzzzzzzzzzzzzz_ItemExpiry1147_P.pak','zzzzzzzzzzzzzzzzzz_DevHealth1147_P.pak','zzzzzzzzzzzzzzzzzz_RadiantEscalation1147_P.pak'].map(x=>x.toLowerCase())),originalNames=new Set(read(path.join(src('04'),'Source/compatibility.json')).original_paks.map(x=>x.toLowerCase()));
 if(action==='install'&&protectedAssets.size)for(const n of fs.readdirSync(path.join(game,'Archon/Content/Paks')))if(n.toLowerCase().endsWith('.pak')&&!ownedNames.has(n.toLowerCase())&&!originalNames.has(n.toLowerCase())){const a=require('./paks.cjs').entries(path.join(game,'Archon/Content/Paks',n));if(a.some(x=>protectedAssets.has(x)))throw Error('Another overlay replaces a selected asset: '+n);}
 const records=JSON.parse(JSON.stringify(r?.files||[])),changes=[],backupWrites=[];
 for(const[p,t]of desired){let rec=records.find(x=>x.path===p),current=bytes(p);const h=current&&hash(current),off=t.rel&&path.join(__dirname,'Official',t.rel);
  if(!rec){let before=current;
   if(t.kind==='launcher'||t.kind==='pointer'){}else if(off&&fs.existsSync(off)){
    before=fs.readFileSync(off);if(current&&!current.equals(before)&&!current.equals(t.after)&&!known[t.rel]?.includes(h))throw Error('Unknown edited file; nothing changed: '+p);
   }else{if(current&&!current.equals(t.after)&&!(t.health&&healthHashes.includes(h))&&!known[t.rel]?.includes(h)&&!t.mutable)throw Error('Unknown existing addon file: '+p);before=null;}
   rec={path:p,rel:t.rel,kind:t.kind||'package',before:before===null?null:hash(before),backup:'file-'+crypto.randomUUID()+'.original',active:true};records.push(rec);if(before!==null)backupWrites.push({path:path.join(dir,rec.backup),before:bytes(path.join(dir,rec.backup)),after:before});
  }else if(off&&fs.existsSync(off)){
   const baseline=fs.readFileSync(off),baselineHash=hash(baseline);
   if(rec.before!==baselineHash){
    if(rec.before&&hash(fs.readFileSync(path.join(dir,rec.backup)))!==rec.before)throw Error('Previous official restore backup hash differs');
    const backup='file-'+crypto.randomUUID()+'.original';backupWrites.push({path:path.join(dir,backup),before:null,after:baseline});Object.assign(rec,{before:baselineHash,backup});
   }
  }
  Object.assign(rec,{active:true,after:hash(t.after),health:!!t.health,mutable:!!t.mutable});if(t.kind==='pointer')Object.assign(rec,{version:t.version,beforeChecksum:rec.beforeChecksum||t.beforeChecksum,installedChecksum:t.installedChecksum});
  if(!current||!current.equals(t.after))changes.push({path:p,before:current,after:t.after});
 }
 for(const t of records)if(t.active&&!desired.has(t.path)){
  let original=t.before?fs.readFileSync(path.join(dir,t.backup)):null;if(original&&hash(original)!==t.before)throw Error('Restore backup hash differs');const off=t.rel&&path.join(__dirname,'Official',t.rel);if(off&&fs.existsSync(off))original=fs.readFileSync(off);const current=bytes(t.path);
  if(t.kind==='pointer'&&current){const pointer=JSON.parse(current);pointer.sha256=t.beforeChecksum;original=Buffer.from(JSON.stringify(pointer,null,1));}
  changes.push({path:t.path,before:current,after:original});t.active=false;
 }
 const settingsPath=path.join(root,'data/rules.txt'),oldSettings=bytes(settingsPath);let settings=selected.includes('04')?composed.settings:previous.includes('04')&&oldSettings?restoreSettings(oldSettings):oldSettings;
 if(settings&&(!oldSettings||!settings.equals(oldSettings)))changes.push({path:settingsPath,before:oldSettings,after:settings});
 const updated={revision:1,root,launcher,game,selected,created:r?.created||new Date().toISOString(),updated:new Date().toISOString(),files:records};
 if(r&&JSON.stringify(previous)===JSON.stringify(selected)&&!changes.length&&!backupWrites.length)return{installed:true,already_installed:true,selected};
 const transaction=path.join(dir,'transactions',crypto.randomUUID()),beforeReceipt=bytes(receipt);fs.mkdirSync(transaction,{recursive:true});
 try{
  changes.forEach((t,i)=>{if(t.before!==null)fs.writeFileSync(path.join(transaction,i+'.before'),t.before);});if(beforeReceipt)fs.writeFileSync(path.join(transaction,'receipt.before'),beforeReceipt);
  write(path.join(dir,'pending.json'),Buffer.from(JSON.stringify({transaction,changes:changes.map((t,i)=>({path:t.path,existed:t.before!==null,backup:i+'.before'}))},null,2)));
  backupWrites.forEach(t=>write(t.path,t.after));changes.forEach((t,i)=>{write(t.path,t.after);options.afterWrite?.(i,t);});write(receipt,Buffer.from(JSON.stringify(updated,null,2)));options.afterWrite?.(changes.length,{path:receipt});fs.rmSync(path.join(dir,'pending.json'));
  if(!selected.length)fs.renameSync(dir,dir+'-restored-'+crypto.randomUUID());
 }catch(e){changes.forEach(t=>write(t.path,t.before));backupWrites.forEach(t=>write(t.path,t.before));write(receipt,beforeReceipt);fs.rmSync(path.join(dir,'pending.json'),{force:true});if(!r)fs.rmSync(dir,{recursive:true,force:true});throw e;}
 return{[action==='restore'?'restored':'installed']:true,selected,official_fixes:'retained; not reinstalled',saves_preserved:true,pak_format:3,personal_rules:selected.includes('04')?'solo, 0.1–100x':false};
}
if(require.main===module){try{const result=install(process.argv[3],process.argv[4],process.argv[2],{component:process.argv[5]||'all'});console.log(JSON.stringify(result,null,2));if(process.argv[2]==='check'&&!result.installed)process.exitCode=1;}catch(e){console.error('STOPPED: '+e.message);process.exitCode=1;}}
module.exports={install,compose,restoreSettings,setup,verify,ids,defaultIds};
