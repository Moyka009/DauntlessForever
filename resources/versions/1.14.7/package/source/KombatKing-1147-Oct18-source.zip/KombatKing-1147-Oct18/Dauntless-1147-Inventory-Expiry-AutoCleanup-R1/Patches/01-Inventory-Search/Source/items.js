// SPDX-License-Identifier: AGPL-3.0-only
// R2: storage classification only. Existing list/set interface; no expanded picker.
'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto'), net = require('net');
const ROOT = path.resolve(__dirname, '..'), STATE = path.join(ROOT, 'data', 'state.json');
const MAX = 99999999;
const read = file => JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
const metadata = read(path.join(__dirname, 'catalog-1147.json'));
const catalog = new Map(metadata.items.map(i => [i.id, i]));
const fail = message => { throw Error(message); };
const out = value => process.stdout.write(JSON.stringify(value));

function ownPlayer(state) {
  const keys = new Set();
  for (const dir of ['eos', 'eos_lan']) {
    const file = path.join(ROOT, dir, 'eos_offline.ini');
    if (!fs.existsSync(file)) continue;
    const m = /^\s*EpicAccountId\s*=\s*([0-9a-f]{32})\s*$/im.exec(fs.readFileSync(file, 'utf8'));
    if (m) keys.add(crypto.createHash('sha256').update('epic:' + m[1]).digest('hex').slice(0, 32));
  }
  const players = Object.entries(state.players || {}).filter(([, p]) => Array.isArray(p.characters) && p.characters.length);
  const matched = players.filter(([key]) => keys.has(key));
  if (matched.length === 1) return matched[0][1];
  if (!matched.length && players.length === 1) return players[0][1];
  fail('Cannot identify your account safely. Multiple local/online accounts exist; check the eos sign-in settings. No save changed.');
}
function chars(state) {
  const player = ownPlayer(state);
  return player.characters.map(ch => {
    const inv = player.inventory && player.inventory[ch.id];
    if (!inv || !Array.isArray(inv.stackedItems) || !Array.isArray(inv.instancedItems)) fail('Character inventory is missing or invalid.');
    return { ch, inv, loadout: (player.loadouts || {})[ch.id] || {} };
  });
}
function mentioned(obj, id) {
  if (obj === id) return true;
  if (typeof obj === 'string' && /^[\[{]/.test(obj.trim())) {
    try { return mentioned(JSON.parse(obj), id); } catch { return true; }
  }
  return !!obj && typeof obj === 'object' && Object.values(obj).some(x => mentioned(x, id));
}
function inUse(c, id) {
  return mentioned(c.loadout, id) || c.inv.instancedItems.some(x => x.catalogId !== id && mentioned(x.itemData, id));
}
function qty(n) {
  if (typeof n !== 'number' || !Number.isSafeInteger(n) || n < 0 || n > MAX) fail('Counts must be whole numbers from 0 to ' + MAX + '.');
  return n;
}
function fresh(meta) {
  const item = { catalogId: meta.id, instanceId: crypto.randomUUID(), updateVersion: 1 };
  if (meta.group === 'Weapons' || meta.group === 'Armour' || meta.group === 'Weapon parts') {
    item.itemData = JSON.stringify({ CurrentLevel: meta.level, CurrentXP: 0, DataVersion: 1, EquippedCells: [], EquippedWeaponParts: [] });
  }
  return item;
}
function normalize(c, meta, n) {
  const id = meta.id;
  if (meta.singleton) n = n ? 1 : 0;
  if (!n && (inUse(c, id) || c.inv.instancedItems.some(x => x.catalogId === id && inUse(c, x.instanceId)))) fail('Unequip this item before removing it: ' + id);
  // Remove wrong-list entries only when they have no state or equipment references.
  if (meta.storage === 'stack') {
    const wrong = c.inv.instancedItems.filter(x => x.catalogId === id);
    if (wrong.some(x => x.itemData != null || inUse(c, x.instanceId))) fail('This item has an equipped/stateful entry in the wrong list. Unequip it before repair: ' + id);
    c.inv.instancedItems = c.inv.instancedItems.filter(x => x.catalogId !== id);
    c.inv.stackedItems = c.inv.stackedItems.filter(x => x.catalogId !== id);
    if (n) c.inv.stackedItems.push({ catalogId: id, quantity: n });
  } else {
    c.inv.stackedItems = c.inv.stackedItems.filter(x => x.catalogId !== id);
    const held = c.inv.instancedItems.filter(x => x.catalogId === id);
    if (!n) c.inv.instancedItems = c.inv.instancedItems.filter(x => x.catalogId !== id);
    else if (!held.length) c.inv.instancedItems.push(fresh(meta));
    // Preserve existing level, cells, parts and instance IDs.
  }
  return n;
}
async function backendUp() {
  return new Promise(resolve => {
    const socket = net.connect({ host: '127.0.0.1', port: 63000 });
    let done = false;
    const end = v => { if (!done) { done = true; socket.destroy(); resolve(v); } };
    socket.on('connect', () => end(true)); socket.on('error', () => end(false)); socket.setTimeout(800, () => end(false));
  });
}
function save(state, original) {
  if (!fs.readFileSync(STATE).equals(original)) fail('Save changed during editing. Close the game and retry.');
  const dir = path.join(ROOT, 'backup', 'inventory');
  fs.mkdirSync(dir, { recursive: true });
  const tag = new Date().toISOString().replace(/[:.]/g, '-') + '-' + crypto.randomBytes(4).toString('hex');
  const backup = path.join(dir, 'state.json.' + tag);
  fs.writeFileSync(backup, original, { flag: 'wx' });
  const tmp = STATE + '.inventory-' + crypto.randomBytes(6).toString('hex') + '.tmp';
  try {
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2), { flag: 'wx' });
    read(tmp);
    if (!fs.readFileSync(STATE).equals(original)) fail('Save changed during editing. Retry after stopping the game.');
    fs.renameSync(tmp, STATE);
  } finally { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); }
  return backup;
}
function list(state) {
  // Return owned items only. No picker catalog, gear controls or unlock-all flag.
  return { ok: true, characters: chars(state).map(c => {
    const items = {};
    for (const i of c.inv.stackedItems) if (i && i.catalogId) items[i.catalogId] = (items[i.catalogId] || 0) + (Number(i.quantity) || 0);
    for (const i of c.inv.instancedItems) {
      if (i && i.catalogId && catalog.has(i.catalogId)) items[i.catalogId] = 1;
    }
    return { id: c.ch.id, name: c.ch.name || '', items };
  }) };
}
async function main(args) {
  const [cmd, who, raw] = args;
  if (!fs.existsSync(STATE)) fail('No save yet. Launch 1.14.7 and make a character first.');
  const original = fs.readFileSync(STATE), state = JSON.parse(original.toString('utf8').replace(/^\uFEFF/, ''));
  if (cmd === 'list') return list(state);
  if (!['set', 'repair'].includes(cmd)) fail('Unknown command.');
  if (await backendUp()) fail('Close the game and press Stop in the launcher before editing inventory.');
  const targets = chars(state).filter(c => who === '*' || c.ch.id === who);
  if (!targets.length) fail('Character not found in your account.');
  let input;
  if (cmd === 'repair') input = [];
  else { try { input = JSON.parse(raw); } catch { fail('Invalid change list.'); } }
  if (cmd === 'set') {
    if (!input || typeof input !== 'object' || Array.isArray(input) || !Object.keys(input).length) fail('Invalid item counts.');
    for (const [id, n] of Object.entries(input)) { if (!catalog.has(id)) fail('Unknown 1.14.7 item ID: ' + id); qty(n); }
  } else if (!Array.isArray(input) || input.some(x => typeof x !== 'string')) fail('Expected a list of item IDs.');
  const result = { ok: true, set: {}, repaired: [], skipped: [] };
  for (const c of targets) {
    if (cmd === 'set') for (const [id, n] of Object.entries(input)) result.set[id] = normalize(c, catalog.get(id), n);
    if (cmd === 'repair') for (const meta of metadata.items) {
      const stacks = c.inv.stackedItems.filter(x => x.catalogId === meta.id);
      const inst = c.inv.instancedItems.filter(x => x.catalogId === meta.id);
      const wrong = meta.storage === 'instance' ? stacks.length > 0 : inst.length > 0;
      if (!wrong) continue;
      if (inUse(c, meta.id)) { result.skipped.push(meta.id); continue; }
      const total = stacks.reduce((n, x) => n + qty(x.quantity), 0);
      if (meta.storage === 'stack' && inst.some(x => x.itemData != null || inUse(c, x.instanceId))) { result.skipped.push(meta.id); continue; }
      normalize(c, meta, Math.max(total, inst.length ? 1 : 0)); result.repaired.push(meta.id);
    }
  }
  if (JSON.stringify(state) !== JSON.stringify(JSON.parse(original.toString('utf8').replace(/^\uFEFF/, '')))) result.backup = save(state, original);
  return result;
}
if (require.main === module) main(process.argv.slice(2)).then(out).catch(e => out({ ok: false, error: e.message }));
module.exports = { main, catalog, ownPlayer, normalize, list };
