# SPDX-License-Identifier: AGPL-3.0-only
param([ValidateSet('install','check','restore')][string]$Action='install',[string]$Package='', [string]$Launcher='C:\DauntlessForever')
$ErrorActionPreference='Stop'
try {
    if(-not $Package) {
        $roots=@()
        if($env:DL_DATA_DIR){$roots+=$env:DL_DATA_DIR}
        if($env:LOCALAPPDATA -and -not $env:DL_DATA_DIR){
            $legacy=Join-Path $env:LOCALAPPDATA 'DauntlessOffline'
            if((Test-Path -LiteralPath (Join-Path $legacy 'launcher.json')) -or (Test-Path -LiteralPath (Join-Path $legacy 'versions'))){$roots+=$legacy}
            else {$roots+=(Join-Path $env:LOCALAPPDATA 'DauntlessForever')}
        }
        foreach($root in $roots){
            $candidate=Join-Path $root 'versions\1.14.7'
            if(Test-Path -LiteralPath (Join-Path $candidate 'services_1147.json')){$Package=$candidate;break}
        }
        if(-not $Package){$Package=Read-Host 'Enter the active official 1.14.7 package folder (contains config.json and services_1147.json)'}
    }
    $Package=[IO.Path]::GetFullPath($Package.Trim().Trim('"'))
    if(-not(Test-Path -LiteralPath (Join-Path $Launcher 'resources\app.asar'))){$Launcher=(Read-Host 'Enter the Dauntless Forever launcher folder containing resources\app.asar').Trim().Trim('"')}
    $Launcher=[IO.Path]::GetFullPath($Launcher)
    if(-not(Test-Path -LiteralPath (Join-Path $Launcher 'resources\app.asar'))){throw 'Launcher app.asar not found.'}
    if($Action -ne 'check') {
        $prefix=$Launcher.TrimEnd('\')+'\'
        $running=@(Get-CimInstance Win32_Process | Where-Object {
            $_.Name -eq 'Dauntless-Win64-Shipping.exe' -or
            ($_.Name -eq 'node.exe' -and $_.CommandLine -match '(recorder|supervisor)-1147\.js') -or
            ($_.ExecutablePath -and $_.Name -ne 'node.exe' -and $_.ExecutablePath.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) -or
            $_.Name -in @('DauntlessForever.exe','Dauntless Forever.exe')
        })
        if($running.Count){throw 'Close Dauntless, stop its backend/server copies, and close the launcher before continuing.'}
    }
    $nodePath=Join-Path $Launcher 'resources\runtime\node\node.exe'
    if(-not(Test-Path -LiteralPath $nodePath)){
        $cfg=Get-Content -LiteralPath (Join-Path $Package 'config.json') -Raw | ConvertFrom-Json
        if($cfg.Node -and (Test-Path -LiteralPath $cfg.Node)){$nodePath=$cfg.Node}
        else {$cmd=Get-Command node.exe -ErrorAction SilentlyContinue;if($cmd){$nodePath=$cmd.Source}else{$nodePath=(Read-Host 'Enter the full path to node.exe').Trim().Trim('"')}}
    }
    if(-not(Test-Path -LiteralPath $nodePath)){throw 'Node.js executable not found.'}
    Write-Host "Active 1.14.7 package: $Package"
    Write-Host "Launcher folder: $Launcher"
    & $nodePath (Join-Path $PSScriptRoot '..\..\Source\install.cjs') $Action $Package $Launcher 06
    if($LASTEXITCODE -ne 0){throw 'Operation failed. Read the reason above.'}
    exit 0
} catch {Write-Host "STOPPED: $($_.Exception.Message)" -ForegroundColor Red;exit 1}
