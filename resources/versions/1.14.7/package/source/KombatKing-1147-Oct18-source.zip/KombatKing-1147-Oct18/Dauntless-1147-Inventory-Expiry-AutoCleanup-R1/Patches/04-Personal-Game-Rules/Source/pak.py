import struct,hashlib,zlib
from pathlib import Path
def u32(b,o):return struct.unpack_from('<I',b,o)[0]
def fstring(b,o):
 n=struct.unpack_from('<i',b,o)[0];o+=4
 if n<0:return b[o:o-n*2-2].decode('utf-16le'),o-n*2
 return b[o:o+n-1].decode('utf-8'),o+n
def entry(b,o):
 start=o;offset,size,raw,method=struct.unpack_from('<QQQI',b,o);o+=28
 digest=b[o:o+20];o+=20;blocks=[]
 if method:
  count=u32(b,o);o+=4
  for _ in range(count):blocks.append(struct.unpack_from('<QQ',b,o));o+=16
 flags=b[o];blocksize=u32(b,o+1);o+=5
 return {'offset':offset,'size':size,'raw':raw,'method':method,'digest':digest,'blocks':blocks,'flags':flags,'blocksize':blocksize,'header':o-start},o
class Pak:
 def __init__(self,file):
  self.file=Path(file);self.b=self.file.read_bytes();b=self.b
  magic=b.rfind(struct.pack('<I',0x5a6f12e1));self.footer=b[magic-17:]
  _,self.version,offset,size=struct.unpack_from('<IIQQ',b,magic)
  assert self.version in [3,8,9]
  index=b[offset:offset+size];assert hashlib.sha1(index).digest()==b[magic+24:magic+44]
  self.mount,o=fstring(index,0);count=u32(index,o);o+=4;self.rows={}
  for _ in range(count):
   name,o=fstring(index,o);e,o=entry(index,o);self.rows[name]=e
  assert o==len(index),(o,len(index))
 def extract(self,name):
  e=self.rows[name];at=e['offset'];header,_=entry(self.b,at)
  assert not e['flags']&1
  if not e['method']:out=self.b[at+header['header']:at+header['header']+e['size']]
  else:
   assert e['method']==1
   out=b''.join(zlib.decompress(self.b[at+a:at+b]) for a,b in e['blocks'])
  assert len(out)==e['raw']
  # PAK entry SHA1 covers stored bytes, not necessarily decompressed payload.
  stored=self.b[at+header['header']:at+header['header']+e['size']]
  assert hashlib.sha1(stored).digest()==e['digest']
  return out
def make_pak(files,out,mount='../../../Archon/Content/'):
 def string(s):
  b=s.encode()+b'\0';return struct.pack('<i',len(b))+b
 def ent(offset,data):return struct.pack('<QQQI',offset,len(data),len(data),0)+hashlib.sha1(data).digest()+struct.pack('<BI',0,0)
 b=bytearray();rows=[]
 for name,data in sorted(files.items()):
  offset=len(b);record=ent(offset,data);b+=ent(0,data)+data;rows.append((name,record))
 index=string(mount)+struct.pack('<I',len(rows))
 for name,record in rows:index+=string(name)+record
 offset=len(b);b+=index
 # V3 matches the working all-in-one hammer PAK. V9/FrozenIndex is rejected by 1.14.7.
 b+=struct.pack('<IIQQ',0x5a6f12e1,3,offset,len(index))+hashlib.sha1(index).digest()
 Path(out).write_bytes(b)
if __name__=='__main__':
 p=Pak(Path(__file__).parent/'input/Archon_18-WindowsClient.pak')
 print(p.mount,len(p.rows))
 out=Path(__file__).parent/'assets';out.mkdir(exist_ok=True)
 for n in p.rows:
  if any(x in n for x in ['crafting_recipes.','weapon_recipe_patterns_cr2019.','generated_gear_recipe_patterns_cr2019.','lantern_recipe_patterns.']):
   data=p.extract(n);(out/Path(n).name).write_bytes(data);print(n,len(data))
