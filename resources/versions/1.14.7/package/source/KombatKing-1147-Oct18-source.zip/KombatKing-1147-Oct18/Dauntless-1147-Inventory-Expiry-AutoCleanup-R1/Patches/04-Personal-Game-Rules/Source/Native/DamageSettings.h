#pragma once
#include <string>
#include <sstream>
#include <locale>
#include <cmath>
#include <istream>
#include <ostream>

namespace DamageScaling {
struct Settings { float Part=1.0f, Stagger=1.0f, Wound=1.0f, Base=1.0f, Obstacle=1.0f; };
inline std::string Trim(std::string value) {
    const auto first=value.find_first_not_of(" \t\r\n");
    if (first==std::string::npos) return {};
    return value.substr(first,value.find_last_not_of(" \t\r\n")-first+1);
}
inline Settings ParseSettings(std::istream& input, std::ostream& warnings) {
    Settings result;
    std::string line;
    bool first=true;
    while (std::getline(input,line)) {
        if (first && line.compare(0,3,"\xEF\xBB\xBF")==0) line.erase(0,3);
        first=false;
        line=Trim(line);
        if (line.empty() || line[0]=='#') continue;
        const auto equals=line.find('=');
        if (equals==std::string::npos) continue;
        const auto key=Trim(line.substr(0,equals));
        float* target=nullptr;
        if (key=="PART_DAMAGE_MULTIPLIER") target=&result.Part;
        else if (key=="STAGGER_DAMAGE_MULTIPLIER") target=&result.Stagger;
        else if (key=="WOUND_DAMAGE_MULTIPLIER") target=&result.Wound;
        else if (key=="BASE_DAMAGE_MULTIPLIER") target=&result.Base;
        else if (key=="OBSTACLE_DAMAGE_MULTIPLIER") target=&result.Obstacle;
        else continue;
        auto value=Trim(line.substr(equals+1));
        const auto comment=value.find('#');
        if (comment!=std::string::npos) value=Trim(value.substr(0,comment));
        if (value.size()>=2 && ((value.front()=='"' && value.back()=='"') || (value.front()=='\'' && value.back()=='\'')))
            value=value.substr(1,value.size()-2);
        std::istringstream parser(value);
        parser.imbue(std::locale::classic());
        float parsed=1.0f;
        char extra;
        if (!(parser>>parsed) || (parser>>extra) || !std::isfinite(parsed) || parsed<0 || parsed>100) {
            *target=1.0f;
            warnings<<"[DamageScaling] Invalid "<<key<<"; using 1. Allowed range: 0 to 100.\n";
        } else *target=parsed;
    }
    return result;
}
}
