# Radiant Escalation patch notes

Adds original Radiant 1–13, 10–50 and heroic queue/map selection, native XP/talent snapshot saving, stale-save protection, and the existing Easy/Hard Slayer's Path nodes. Keeps 50/100 Combat Merit costs and native level-20 heroic requirement. V3 PAK fixes the previous FrozenIndex crash.

- Ported to the verified current official 0.2.10 source/package.
- Uses shared transactional install/restore with independent selection.
- Adds no standalone NOTICE.txt.
- Official features already integrated by Addison are not reinstalled.
