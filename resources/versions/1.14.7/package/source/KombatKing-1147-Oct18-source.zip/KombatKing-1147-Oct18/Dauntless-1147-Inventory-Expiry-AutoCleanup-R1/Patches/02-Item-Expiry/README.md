# Item expiry exception

Clears five Season 11A potion expiry events (including Granny's Heartbreaker and Antidote) and the Springtide egg expiry event in the original 1.14.7 catalog tables. The delivered V3 overlay remains byte-identical to the working All-in-One R2 overlay.

Use this folder's Install, Check and Restore buttons for component 02. Main Install also enables updated inventory search and automatic log cleanup. Run official Set up for current package 2026-10-18.5 first and close the game/backend/launcher before installation.

Only the expiry overlay is added or removed; item quantities and player saves are preserved. The full extracted bundle is required by the component buttons.
