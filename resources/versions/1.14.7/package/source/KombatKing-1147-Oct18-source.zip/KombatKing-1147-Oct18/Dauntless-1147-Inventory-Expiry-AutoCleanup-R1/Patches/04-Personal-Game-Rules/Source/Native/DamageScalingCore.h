#pragma once
#include <array>
#include <cmath>
#include "DamageSettings.h"

namespace DamageScaling {
// The two fields for each damage type are its multiplier and flat per-hit bonus.
class AttributeScope {
    std::array<float*, 8> Fields{};
    std::array<float, 8> Saved{};
    bool Active=false;
public:
    AttributeScope(std::array<float*, 8> fields, Settings factors, bool enabled) : Fields(fields) {
        if (!enabled) return;
        const std::array<float,8> scale={factors.Part,factors.Part,factors.Stagger,factors.Stagger,factors.Wound,factors.Wound,factors.Base,factors.Base};
        for (unsigned i=0;i<Fields.size();++i)
            if (!Fields[i] || !std::isfinite(*Fields[i]) || !std::isfinite(scale[i]) || scale[i]<0 || scale[i]>100 || !std::isfinite(*Fields[i]*scale[i])) return;
        for (unsigned i=0;i<Fields.size();++i) {Saved[i]=*Fields[i]; *Fields[i]*=scale[i];}
        Active=true;
    }
    bool IsActive() const { return Active; }
    AttributeScope(const AttributeScope&)=delete;
    AttributeScope& operator=(const AttributeScope&)=delete;
    ~AttributeScope() {if (Active) for(unsigned i=0;i<Fields.size();++i) *Fields[i]=Saved[i];}
};
}
