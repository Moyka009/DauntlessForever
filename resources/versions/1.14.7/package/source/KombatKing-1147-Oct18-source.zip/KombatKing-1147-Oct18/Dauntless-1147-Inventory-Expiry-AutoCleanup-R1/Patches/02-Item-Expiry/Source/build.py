# SPDX-License-Identifier: AGPL-3.0-only
"""Clear six expiry FNames without resizing or rebuilding UE asset structures."""
import argparse, hashlib, json, shutil, struct, subprocess, tempfile
from pathlib import Path
from equipment_asset import Asset
from catalog_reader import table

PATCH = Path(__file__).resolve().parents[1]
TARGETS = {
 'quick_item_catalog.uasset': dict.fromkeys([
  'QI_11A_CRIT_POTION','QI_11A_POISON_CLEANSE','QI_11A_MOUNT_VENT',
  'QI_11A_POISON_LIFESTEAL','QI_11A_POISON_SOAK'], 'Season_11A_StoryMissions'),
 'Token_Catalogs/tokens_general_catalog.uasset': {'TOKEN_EVENT_SPRINGTIDE_EGG':'EVENT_SPRINGTIDE'}
}
NAME = 'zzzzzzzzzzzzzzzz_ItemExpiry1147_P.pak'
def digest(p,kind='sha256'): return hashlib.new(kind,p.read_bytes()).hexdigest()
def edit(source, dest, wanted):
 a=Asset(source);before=table(source);e=a.exports[0]
 pos,_=a.properties(e['start']);assert struct.unpack_from('<I',a.b,pos)[0]==0
 count=struct.unpack_from('<I',a.b,pos+4)[0];pos+=8
 b=bytearray(a.b);changed=[];allowed=set()
 for _ in range(count):
  row,pos=a.name(pos)
  while True:
   tag=a.tag(pos)
   if tag['name']=='None':pos=tag['end'];break
   if row in wanted and tag['name']=='ExpiryEventId':
    assert tag['type']=='NameProperty' and tag['size']==8
    old,end=a.name(tag['start']);assert old==wanted[row] and end==tag['end']
    b[tag['start']:end]=struct.pack('<II',a.names.index('None'),0)
    allowed.update(range(tag['start'],end))
    changed.append({'id':row,'before':old,'after':'None','offset':tag['start']})
   pos=tag['end']
 assert pos==e['start']+e['size']
 assert {x['id'] for x in changed}==set(wanted) and len(changed)==len(wanted)
 assert all(x in allowed for x,(old,new) in enumerate(zip(a.b,b)) if old!=new)
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(a.ua);dest.with_suffix('.uexp').write_bytes(b)
 after=table(dest)
 expected=json.loads(json.dumps(before));expected['asset']=str(dest)
 for row in expected['rows']:
  if row['id'] in wanted:
   for f in row['fields']:
    if f['path']=='/ExpiryEventId':f['value']='None'
 assert expected==after, 'Unexpected semantic change'
 assert dest.read_bytes()==source.read_bytes()
 return {'source':str(source.name),'rows':count,'changes':changed,'uasset_unchanged':True,
         'uexp_size_unchanged':len(b)==len(a.b),'other_fields_unchanged':True,
         'original_uasset_sha256':digest(source),'original_uexp_sha256':digest(source.with_suffix('.uexp')),
         'patched_uexp_sha256':digest(dest.with_suffix('.uexp'))}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('assets',type=Path);ap.add_argument('repak',type=Path);ap.add_argument('manifest',type=Path)
 args=ap.parse_args();repak=args.repak.resolve();prefix=Path('Archon/Content/Gameplay/Backend/Catalogs')
 assert digest(args.manifest,'sha1')=='aa70748e4c0a776a991f2bac10ad342adaa31476', 'Wrong game manifest'
 evidence=json.loads((PATCH/'Source/ORIGINAL-ASSETS.json').read_text())
 for rel,wanted in evidence.items():
  asset=args.assets/Path(rel).relative_to(prefix)
  assert digest(asset)==wanted, 'Original asset SHA256 mismatch: '+rel
 with tempfile.TemporaryDirectory(prefix='item-expiry-build-') as tmp:
  stage=Path(tmp)/'stage';out=PATCH/'Payload'/NAME;out.parent.mkdir(exist_ok=True)
  changes=[]
  for name,wanted in TARGETS.items():changes.append(edit(args.assets/name,stage/prefix/name,wanted))
  from pak import make_pak
  make_pak({p.relative_to(stage).as_posix():p.read_bytes() for p in stage.rglob('*') if p.is_file()},out,mount='../../../')
  unpack=Path(tmp)/'unpack';subprocess.run([str(repak),'unpack',str(out),'-o',str(unpack)],check=True)
  files=sorted(p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file())
  assert sorted(p.relative_to(unpack).as_posix() for p in unpack.rglob('*') if p.is_file())==files
  for rel in files:assert (stage/rel).read_bytes()==(unpack/rel).read_bytes()
  b=out.read_bytes();f=b[-44:];assert struct.unpack_from('<II',f,0)==(0x5a6f12e1,3)
  ix,size=struct.unpack_from('<QQ',f,8);assert ix+size==len(b)-44
  assert hashlib.sha1(b[ix:ix+size]).digest()==f[24:44]
  import sys
  sys.path.insert(0,str(args.manifest.resolve().parent/'deps'))
  from legendary.models.manifest import Manifest
  m=Manifest.read_all(args.manifest.read_bytes());original=next(x for x in m.file_manifest_list.elements if x.filename=='Archon/Content/Paks/Archon_24-WindowsClient.pak')
  manifest={'patch':'Item Expiry 1.14.7','revision':1,'game':'1.14.7 CL647472','pak':NAME,'pak_sha256':digest(out),'pak_format':3,
   'assets':files,'original_sha1':{original.filename:original.hash.hex()},
   'original_paks':[Path(x.filename).name for x in m.file_manifest_list.elements if x.filename.lower().endswith('.pak')],
   'manifest_sha1':digest(args.manifest,'sha1'),'changed_item_count':6,'changes':changes}
  (PATCH/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  print(json.dumps({'pak_size':out.stat().st_size,'sha256':digest(out),'items_changed':6,'assets_roundtrip_verified':len(files)}))
if __name__=='__main__':main()
