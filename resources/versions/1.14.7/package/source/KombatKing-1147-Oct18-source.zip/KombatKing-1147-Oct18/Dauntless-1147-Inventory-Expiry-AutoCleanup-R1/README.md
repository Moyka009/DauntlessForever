# Dauntless 1.14.7 — Inventory, Item Expiry and Automatic Log Cleanup

Updated for launcher **0.2.10**, official 1.14.7 server package **2026-10-18.5** and original game build **CL647472**.

1. Finish the official launcher update and 1.14.7 Set up.
2. Close the game, stop its backend/servers and close the launcher.
3. Extract the entire ZIP and run the main **Install.cmd**.

Main Install enables or updates these three components:

- **01 Inventory Search:** name/ID search, two-line suggestions and name-based adding. The catalog now has 5,805 entries, including all six actual Omnicells.
- **02 Item Expiry:** removes the expiry event from five Season 11A potions and the Springtide egg token. The verified native V3 overlay is retained.
- **06 Automatic Log Cleanup:** runs when the package's shared startup tools load and the local backend is stopped. It keeps the newest five per archive group, everything from the last 24 hours, current engine/server logs and the latest client/server ZIPs.

Existing selected Radiant, personal rules and client-engine logging components remain selected. Their folders and controls are included for compatibility and independent restores. A fresh main install selects only 01, 02 and 06.

**Check.cmd** checks the requested components. **Restore.cmd** removes 01, 02 and 06 while keeping other installed components. Every patch folder has its own Install, Check and Restore buttons. Keep the extracted folder together; component buttons use the shared installer.

This update reuses the existing All-in-One R2 installation record under `backup/all-in-one1147-r2-0210` so older installed components can be preserved and composed correctly. Use this updated bundle's buttons for subsequent component operations. New official restore baselines are saved without deleting earlier backups. Your separately installed Trials shop expansion is preserved.

Cleanup handles old `logs/run_*`, `logs/server_run_*`, timestamped server logs and archived `upload/server_logs_*.zip` / `client_logs_*.zip`. It skips linked trees, recently modified files and a running local backend. It preserves `client_engine.log`, fixed current server/recorder logs, `server_logs.zip` and `client_logs.zip`. Unknown files, saves and save backups are outside its cleanup scope.

Automatic cleanup starts with the next package tool/game launch. Install and Restore themselves do not delete logs. **Clean-Old-Logs.cmd** also remains available for a manual run after stopping everything. Logs deleted by cleanup cannot be recovered using Restore; restoring component 06 stops future automatic cleanup.

Player saves, account keys, installed game DLLs and existing personal choices are preserved by installation. No standalone NOTICE.txt or packet recorder is added. Source, patch notes, backend.md and AGPL-3.0-only licenses are included. See VALIDATION.md for automated results and native Windows testing limits.
