# Current official update audit

Verified official GitHub main at commit `5a8fe6e4f334ea86904476a117a4785af4632e8f`, launcher 0.2.10, 1.14.7 package **2026-10-18.5**. Retrieved/local reference bytes were compared with the commit's Git blob SHA1 values; Source/official-audit.json records those and SHA256 hashes.

The four launcher files used by inventory search are unchanged from the reviewed 0.2.10 source. The current official helper still handles stacked resources, so the catalog-aware instance storage/search addon remains relevant. Native player_role_catalog supplies the six newly indexed actual Omnicell IDs.

The official 1.14.7 game build and manifest remain CL647472 and SHA1 aa70748e4c0a776a991f2bac10ad342adaa31476. The expiry overlay remains valid and does not overlap the official equipment overlay (the latter changes the Recruit repeater weapon catalog). Its six targeted expiry values reproduce the delivered V3 overlay exactly.

The official current travel helper fingerprints the home player, protecting Inventory-page edits from an older pending host copy. The updated inventory helper changes the player inventory while preserving that pending fingerprint; an integration check confirms the current travel helper keeps the edited home save.

The new automatic cleanup hook is appended to the reviewed current tools/common.ps1. It runs the cleanup helper before a new local backend and skips cleanup when that backend is already listening. The original copyright/license comments and script content remain intact.

If Radiant was already selected, its route insertions are composed onto the current official recorder. Updated restore baselines preserve the current official party and travel behavior. Other official fixes remain supplied by the official package.

Source: https://github.com/addison2k/DauntlessForever/tree/5a8fe6e4f334ea86904476a117a4785af4632e8f
