# Inventory changes

No backend route changes. tools/items.js remains the catalog-aware helper; tools/catalog-1147.json gains six native PlayerRole entries. All are unstackable singleton equipment: PR_BASTION, PR_DISCIPLINE, PR_ICEBORNE, PR_TEMPEST, PR_DARKNESS and PR_FRANK.

Four launcher files expose metadata, validate native IDs, render name/ID search and two-line suggestions, and resolve names when adding. The patch targets the actual bundled and active app-update archives; pointer SHA256 values are updated transactionally.

Current tools/travel-1147.js is retained. Its pending local-player fingerprint still detects helper edits and prevents an older remote copy from overwriting them. The shared installer changes no save while installing/restoring; the helper changes only selected inventory values when the user saves from the Inventory page.
