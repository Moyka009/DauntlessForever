// SPDX-License-Identifier: AGPL-3.0-only
// Reflection/scoped attribute approach derived from the 1.6.2 community helper.
// 1.14.7 offsets re-found against CL647472 and verified against its own Dumper-7 SDK.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <atomic>
#include <array>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstring>
#include <mutex>
#include <filesystem>
#include <algorithm>
#include <iostream>
#include <unordered_map>
#include "minhook/MinHook.h"
#include "DamageScalingCore.h"
namespace {
using Ptr=uintptr_t;using Event=void(*)(void*,void*,void*);
Ptr base=0;std::wstring directory;std::mutex logMutex;
struct Name {int32_t index;uint32_t number;};struct Array {Ptr data;int32_t num,max;};
DamageScaling::Settings settings;float incoming=1,escalation=1;
Event originalEvent=nullptr;float(*originalEscalation)(void*)=nullptr;
bool Read(Ptr address,void* dest,size_t size) {
 SIZE_T n=0;return address&&ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(address),dest,size,&n)&&n==size;
}
template<class T>bool Read(Ptr address,T& result){return Read(address,&result,sizeof(result));}
std::wstring Path(const wchar_t* leaf){return directory+L"\\"+leaf;}
void Log(const std::string& message) {
 std::lock_guard<std::mutex> lock(logMutex);
 std::ofstream f(std::filesystem::path(Path((L"dev-rules1147-"+std::to_wstring(GetCurrentProcessId())+L".log").c_str())),std::ios::app);
 f<<message<<"\n";
}
std::string HashFile(const std::wstring& filename) {
 BCRYPT_ALG_HANDLE algorithm=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;DWORD objectSize=0,got=0;
 if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)return {};
 auto cleanup=[&]{if(hash)BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(algorithm,0);};
 if(BCryptGetProperty(algorithm,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&objectSize),sizeof(objectSize),&got,0)<0){cleanup();return {};}
 std::vector<unsigned char> object(objectSize);std::array<unsigned char,32> result{};
 if(BCryptCreateHash(algorithm,&hash,object.data(),objectSize,nullptr,0,0)<0){cleanup();return {};}
 HANDLE file=CreateFileW(filename.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
 if(file==INVALID_HANDLE_VALUE){cleanup();return {};}
 std::array<unsigned char,65536> buffer{};DWORD bytes=0;bool ok=true;
 while(true){if(!ReadFile(file,buffer.data(),static_cast<DWORD>(buffer.size()),&bytes,nullptr)){ok=false;break;}if(!bytes)break;if(BCryptHashData(hash,buffer.data(),bytes,0)<0){ok=false;break;}}
 CloseHandle(file);if(ok)ok=BCryptFinishHash(hash,result.data(),static_cast<ULONG>(result.size()),0)>=0;cleanup();
 if(!ok)return {};std::ostringstream out;for(auto c:result)out<<std::hex<<std::setfill('0')<<std::setw(2)<<int(c);return out.str();
}
bool NameText(Name name,std::string& text) {
 // Match the uploaded Dumper-7 SDK FName::GetRawString, as used by 1.4.4 GetName.
 // UObject/property identifiers are bounded engine names; SDK uses this 1024-wide buffer.
 if(name.index<0||name.number>10000000)return false;
 wchar_t buffer[1024]{};
 struct String {wchar_t* data;int32_t num,max;} temp{buffer,0,1024};
 reinterpret_cast<void(*)(const Name*,String&)>(base+0x02656410)(&name,temp);
 if(temp.data!=buffer||temp.num<1||temp.num>1024)return false;
 text.clear();for(int i=0;i<temp.num&&buffer[i];++i){if(buffer[i]>127)return false;text.push_back(char(buffer[i]));}
 auto slash=text.rfind('/');if(slash!=std::string::npos)text=text.substr(slash+1);
 return !text.empty();
}
bool NameAt(Ptr object,std::string& text){Name n{};return Read(object+0x18,n)&&NameText(n,text);}
bool TypeIs(Ptr object,const char* desired) {
 Ptr type=0;if(!Read(object+0x10,type))return false;
 for(unsigned i=0;type&&i<32;++i){std::string name;if(!NameAt(type,name))return false;if(name==desired)return true;Ptr parent=0;if(!Read(type+0x40,parent)||parent==type)return false;type=parent;}
 return false;
}

bool Field(Ptr type,const char* desired,int expectedOffset,int expectedSize) {
 for(unsigned c=0;type&&c<32;++c){
  Ptr field=0;if(!Read(type+0x50,field))return false;
  for(unsigned i=0;field&&i<1024;++i){
   Name n{};std::string name;int offset=0,size=0,dim=0;
   if(Read(field+0x28,n)&&NameText(n,name)&&name==desired)
    return Read(field+0x4c,offset)&&offset==expectedOffset&&Read(field+0x3c,size)&&size==expectedSize&&Read(field+0x38,dim)&&dim==1;
   Ptr next=0;if(!Read(field+0x20,next)||next==field)break;field=next;
  }
  Ptr next=0;if(!Read(type+0x40,next)||next==type)break;type=next;
 }
 return false;
}
Ptr Attributes(Ptr actor) {
 if(!actor)return 0;
 Ptr player=actor;
 if(!TypeIs(player,"BP_PlayerCharacter_C")) {
  if(!TypeIs(actor,"Actor")||!Read(actor+0xe0,player)||!player||!TypeIs(player,"BP_PlayerCharacter_C"))return 0;
 }
 Ptr type=0,asc=0;if(!Read(player+0x10,type)||!Field(type,"ArchonAbilitySystem",0xc50,8)||!Read(player+0xc50,asc)||!asc||!TypeIs(asc,"ArchonAbilitySystemComponent"))return 0;
 if(!Read(asc+0x10,type)||!Field(type,"SpawnedAttributes",0x140,16))return 0;
 Array attributes{};if(!Read(asc+0x140,attributes)||!attributes.data||attributes.num<0||attributes.num>128||attributes.max<attributes.num)return 0;
 for(int i=0;i<attributes.num;++i){Ptr attr=0;if(Read(attributes.data+i*8,attr)&&attr&&TypeIs(attr,"ArchonDamageAttributeSet"))return attr;}
 return 0;
}
bool Layout(Ptr attr) {
 Ptr type=0;if(!Read(attr+0x10,type))return false;
 const char* names[]={"PartDamageMultiplier","PartDamagePerHitBonus","BaseDamageStaggerMultiplier","StaggerPerHitBonus","BaseDamageExposeMultiplier","ExposePerHitBonus","CoreDamageMultiplier","CoreDamagePerHitBonus"};
 const int offsets[]={0xec,0xf0,0xd8,0xd0,0xdc,0xe4,0xf4,0xf8};
 for(int i=0;i<8;++i)if(!Field(type,names[i],offsets[i],4))return false;
 return true;
}
using Reallocator=void*(*)(void*,uint64_t,uint32_t);
Reallocator GameRealloc(){return reinterpret_cast<Reallocator>(base+0x02564ab0);}
struct CopyArray05 {Array source{},destination{},copy{};unsigned element=0;};
bool CloneOriginalDamageAndTags(Ptr parameters){
 // Four float arrays in FDamageEventData; two FGameplayTag arrays in FGameplayTagContainer.
 const int sources[]={0x08,0x20,0x30,0x40,0x78,0x88};
 const int destinations[]={0x160,0x178,0x188,0x198,0x140,0x150};
 std::array<CopyArray05,6> arrays{};
 for(unsigned i=0;i<6;++i){auto& a=arrays[i];a.element=i<4?4:8;
  if(!Read(parameters+sources[i],a.source)||!Read(parameters+destinations[i],a.destination)||a.source.num<0||a.source.num>4096||a.source.max<a.source.num||a.destination.num<0||a.destination.max<a.destination.num)return false;
 }
 auto cleanup=[&]{for(auto& a:arrays)if(a.copy.data)GameRealloc()(reinterpret_cast<void*>(a.copy.data),0,0);};
 for(auto& a:arrays){
  if(!a.source.num)continue;
  a.copy.num=a.copy.max=a.source.num;a.copy.data=reinterpret_cast<Ptr>(GameRealloc()(nullptr,uint64_t(a.source.num)*a.element,0));
  if(!a.copy.data||!Read(a.source.data,reinterpret_cast<void*>(a.copy.data),size_t(a.source.num)*a.element)){cleanup();return false;}
 }
 std::array<unsigned char,0x28> scalar{};std::array<unsigned char,8> trueDamage{};
 if(!Read(parameters+0x18,trueDamage.data(),trueDamage.size())||!Read(parameters+0x50,scalar.data(),scalar.size())){cleanup();return false;}
 // All allocations succeeded before output changes. Avoid freeing aliased input buffers.
 std::array<Ptr,6> freed{};unsigned freedCount=0;
 for(auto& a:arrays){Ptr old=a.destination.data;if(!old)continue;bool aliases=false;
  for(const auto& input:arrays)if(input.source.data==old)aliases=true;
  for(unsigned j=0;j<freedCount;++j)if(freed[j]==old)aliases=true;
  if(!aliases){GameRealloc()(reinterpret_cast<void*>(old),0,0);freed[freedCount++]=old;}
 }
 for(unsigned i=0;i<6;++i)std::memcpy(reinterpret_cast<void*>(parameters+destinations[i]),&arrays[i].copy,sizeof(Array));
 std::memcpy(reinterpret_cast<void*>(parameters+0x1a8),scalar.data(),scalar.size());
 std::memcpy(reinterpret_cast<void*>(parameters+0x170),trueDamage.data(),trueDamage.size());
 return true;
}

bool IsPreEvent(Ptr fn){
 Name n{};if(!Read(fn+0x18,n))return false;
 static thread_local std::unordered_map<int,bool> cache;
 auto it=cache.find(n.index);if(it!=cache.end())return it->second;
 std::string text;bool yes=NameText(n,text)&&text=="OnPreMitigateDamageBP";
 if(cache.size()<32768)cache[n.index]=yes;return yes;
}
void HookEvent(void* object,void* function,void* parameters){
 Ptr obj=(Ptr)object,fn=(Ptr)function,args=(Ptr)parameters;
 if(!obj||!fn||!args||!IsPreEvent(fn)){originalEvent(object,function,parameters);return;}
 uint32_t flags=0;if(!Read(obj+8,flags)||(flags&0x60000010)){originalEvent(object,function,parameters);return;}
 static thread_local std::vector<Ptr> scopes;
 if(std::find(scopes.begin(),scopes.end(),obj)!=scopes.end()){originalEvent(object,function,parameters);return;}
 struct Guard{std::vector<Ptr>& v;Guard(std::vector<Ptr>& a,Ptr p):v(a){v.push_back(p);}~Guard(){v.pop_back();}} guard(scopes,obj);
 if(incoming!=1&&TypeIs(obj,"BP_PlayerCharacter_C")){
  if(!Field(fn,"DamageEventData",8,0x70)||!Field(fn,"ReturnValue",0x160,0x70)||!Field(fn,"bOverrideDamageData",0x138,1)||!Field(fn,"OutDamageEventTags",0x140,0x20)){originalEvent(object,function,parameters);return;}
  originalEvent(object,function,parameters);
  unsigned char overridden=0;if(!Read(args+0x138,overridden))return;
  float core=0,trueDmg=0;Ptr from=args+(overridden?0x160:8);
  if(!Read(from+0x5c,core)||!Read(from+0x10,trueDmg)||!std::isfinite(core)||!std::isfinite(trueDmg)||!std::isfinite(core*incoming)||!std::isfinite(trueDmg*incoming))return;
  if(core<=0&&trueDmg<=0)return;
  if(!overridden&&!CloneOriginalDamageAndTags(args))return;
  if(core>0)core*=incoming;if(trueDmg>0)trueDmg*=incoming;std::memcpy((void*)(args+0x1bc),&core,4);std::memcpy((void*)(args+0x170),&trueDmg,4);overridden=1;std::memcpy((void*)(args+0x138),&overridden,1);static std::atomic<int> defenseCount{0};if(defenseCount.fetch_add(1)<3)Log("Incoming player damage callback scaled.");return;
 }
 if(settings.Part==1&&settings.Stagger==1&&settings.Wound==1&&settings.Base==1){originalEvent(object,function,parameters);return;}
 if(!TypeIs(obj,"monsterpart_bpc_C")){originalEvent(object,function,parameters);return;}
 Ptr giver=0;if(!Field(fn,"DamageGiver",0,8)||!Read(args,giver)){originalEvent(object,function,parameters);return;}
 Ptr attr=Attributes(giver);
 if(!attr||!Layout(attr)){originalEvent(object,function,parameters);return;}
 static thread_local std::vector<Ptr> attributesInScope;
 if(std::find(attributesInScope.begin(),attributesInScope.end(),attr)!=attributesInScope.end()){originalEvent(object,function,parameters);return;}
 Guard attrGuard(attributesInScope,attr);
 const int offsets[]={0xec,0xf0,0xd8,0xd0,0xdc,0xe4,0xf4,0xf8};std::array<float*,8> fields{};
 for(int i=0;i<8;++i){float x;if(!Read(attr+offsets[i],x)){originalEvent(object,function,parameters);return;}fields[i]=(float*)(attr+offsets[i]);}
 DamageScaling::AttributeScope scope(fields,settings,true);static std::atomic<int> hitCount{0};if(scope.IsActive()&&hitCount.fetch_add(1)<3)Log("Outgoing damage callback scaled and scoped.");originalEvent(object,function,parameters);
}
float HookEscalation(void* object){
 float boost=originalEscalation(object);
 // The original sums bonuses and returns zero without boosts. Caller adds one.
 return std::isfinite(boost)?(1+boost)*escalation-1:boost;
}
bool Signature(Ptr rva,const char* bytes,size_t size){return std::memcmp((void*)(base+rva),bytes,size)==0;}
bool Hook(Ptr rva,void* target,void** original){return MH_CreateHook((void*)(base+rva),target,original)==MH_OK;}
DWORD WINAPI Initialize(void*){
 wchar_t exe[32768]{},file[32768]{};GetModuleFileNameW(nullptr,exe,32768);base=(Ptr)GetModuleHandleW(nullptr);
 if(!GetEnvironmentVariableW(L"DF_PERSONAL1147_FILE",file,32768))return 0;
 directory=(std::filesystem::path(file).parent_path().parent_path()/L"logs").wstring();
 char server[8]{};GetEnvironmentVariableA("D1147_SERVER",server,8);
 if(server[0]!='1'||HashFile(exe)!="f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b"){Log("Refused executable or non-server process");return 0;}
 std::ifstream f{std::filesystem::path(file)};std::unordered_map<std::string,float> s;std::string line;
 while(std::getline(f,line)){auto eq=line.find('=');if(eq==std::string::npos)continue;std::istringstream p(line.substr(eq+1));float value;char extra;if(!(p>>value)||(p>>extra)||!std::isfinite(value)||value<0||value>100)return 0;s[line.substr(0,eq)]=value;}
 auto get=[&](const char* key){auto i=s.find(key);return i==s.end()?1.0f:i->second;};
 settings.Part=get("part_damage");settings.Stagger=get("stagger_damage");settings.Wound=get("wound_damage");settings.Base=get("core_damage");incoming=get("incoming_damage");escalation=get("escalation_rate");
 if(incoming<0.1f||escalation<0.1f)return 0;
 if(!Signature(0x2861880,"\x40\x55\x56\x57\x41\x54\x41\x55",8)||!Signature(0x1aece40,"\x40\x53\x48\x83\xec\x40",6)||!Signature(0x2564ab0,"\x48\x89\x5c\x24\x08\x48\x89\x74",8)){Log("Refused native signature mismatch");return 0;}
 if(MH_Initialize()!=MH_OK)return 0;
 bool eventNeeded=settings.Part!=1||settings.Stagger!=1||settings.Wound!=1||settings.Base!=1||incoming!=1;
 bool ok=(!eventNeeded||Hook(0x2861880,(void*)HookEvent,(void**)&originalEvent))&&(escalation==1||Hook(0x1aece40,(void*)HookEscalation,(void**)&originalEscalation));
 if(!ok){MH_Uninitialize();Log("Refused hook creation");return 0;}
 if(eventNeeded)MH_QueueEnableHook((void*)(base+0x2861880));if(escalation!=1)MH_QueueEnableHook((void*)(base+0x1aece40));
 if(MH_ApplyQueued()!=MH_OK){MH_Uninitialize();Log("Refused hook enable");return 0;}
 Log("Personal 1.14.7 rules loaded; native gameplay test required.");extern volatile LONG ready;InterlockedExchange(&ready,1);return 0;
}
volatile LONG ready=0;
}
extern "C" __declspec(dllexport) LONG DevRulesStatus1147(){return ready;}
BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(h);HANDLE t=CreateThread(nullptr,0,Initialize,nullptr,0,nullptr);if(t)CloseHandle(t);}return TRUE;}
