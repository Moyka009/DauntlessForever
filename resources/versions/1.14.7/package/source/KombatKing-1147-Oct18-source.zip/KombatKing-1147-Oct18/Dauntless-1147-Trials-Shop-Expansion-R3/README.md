# Trials shop expansion R3 — Dauntless 1.14.7

Removes all eight shop entries that come preinstalled on base weapons: Adamant Bolt, Reaper's Dance, Captain's Grip, Salvo Chamber, Valiant Overdrive, Flight of Ruin, Concussive Salvo and Concussive Payload.

Lady Luck retains **15 mods at 250 Steel Marks**, **six optional specials at 500 Steel Marks**, and **all six Omnicells at 500 Steel Marks** each. The six optional specials are Relentless Onslaught, Insatiable Dance, Ironheart Landbreaker, Avenging Overdrive, Reckless Leap and Saboteur's Grip. The R1 cells, Twin Suns, Rare Cell Core and mantles remain included, with Champion rank restrictions retained.

1. Extract the whole ZIP.
2. Close Dauntless, stop its backend/servers and close the launcher.
3. Run **Install.cmd**. Start the launcher normally and visit Lady Luck.

Installs directly over the reviewed official catalog, R1 or R2. **No prior Restore or patch installer is required.** The compatible official backend is package **2026-10-18.5**, commit `5a8fe6e4f334ea86904476a117a4785af4632e8f`, or another package/AIO setup with identical reviewed Trials files.

**Check.cmd** verifies installation. **Restore.cmd** returns exactly to your pre-R3 shop: official 37 offers, R1's 63 offers or R2's 80 offers. Earlier patch backups/receipts remain in place. Keep `backup\trials-store-expansion1147-r3`. Only the shop catalog is replaced; removing an offer does not remove equipment from your inventory or weapons.

The final catalog has 72 entries, with 68 visible non-dye offers under the unchanged official dye-pack filter. ADDED-ITEMS.md lists additions and prices. SLAYERS-PATH-COVERAGE.md compares all ordinary mods/specials against Path rewards and base-weapon defaults.

Native evidence checks 266 weapon catalog entries and their DefaultWeaponPartIDs, along with the 467-node Slayer's Path and full weapon-part/Omnicell catalogs. Source, backend.md, patch notes, native evidence and AGPL-3.0-only license are included. No standalone NOTICE.txt or recorder is added. Saves, settings, Radiant and personal rules are preserved.

Automated module, HTTP purchase and upgrade/restore results are in VALIDATION.md. Native Windows gameplay has not been executed here.
