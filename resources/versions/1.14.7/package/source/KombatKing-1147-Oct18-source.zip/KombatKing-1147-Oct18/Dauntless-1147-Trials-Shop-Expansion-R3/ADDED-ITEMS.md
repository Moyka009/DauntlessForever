# Added Trials rewards

Prices are in Steel Marks unless marked Gilded. Permanent unlocks cannot be bought again while owned. Cells and cores are repeatable.

| Reward | Price | Native 1.14.7 item ID |
| --- | ---: | --- |
| +3 Berserker Cell | 150 Steel | `CELL_TRIALS_01_E` |
| +3 Strategist Cell | 150 Steel | `CELL_TRIALS_02_E` |
| +3 Engineer Cell | 150 Steel | `CELL_TRIALS_03_E` |
| +3 Sprinter Cell | 150 Steel | `CELL_TRIALS_04_E` |
| +3 Mender Cell | 150 Steel | `CELL_TRIALS_06_E` |
| Furious Axecore | 250 Steel | `PART_GA_PASSIVE_TRIALS_02` |
| Railsplitter's Canteen | 250 Steel | `PART_GA_PASSIVE_TRIALS_01` |
| Momentum Blades | 250 Steel | `PART_CB_PASSIVE_TRIALS_01` |
| Turbine Trigger | 250 Steel | `PART_IH_PASSIVE_TRIALS_02` |
| Antique Clip | 250 Steel | `PART_IH_PASSIVE_TRIALS_01` |
| Tactician's Magazine | 250 Steel | `PART_DP_PASSIVE_TRIALS_01` |
| Demolition Sights | 250 Steel | `PART_DP_PASSIVE_TRIALS_02` |
| Barbed Spearhead | 250 Steel | `PART_MS_PASSIVE_TRIALS_01` |
| Executioner's Spearhead | 250 Steel | `PART_MS_PASSIVE_TRIALS_02` |
| Keen Edge | 250 Steel | `PART_EB_PASSIVE_TRIALS_01` |
| Dynamic Bladecore | 250 Steel | `PART_EB_PASSIVE_TRIALS_02` |
| Relentless Onslaught | 500 Steel | `PART_GA_SPECIAL_SKILLSHOT_RESET` |
| Insatiable Dance | 500 Steel | `PART_CB_SPECIAL_INSATIABLE_DANCE` |
| Ironheart Landbreaker | 500 Steel | `PART_IH_SPECIAL_ISLANDCRACKER_DEFENSIVE` |
| Avenging Overdrive | 500 Steel | `PART_EB_SPECIAL_PARRY` |
| Reckless Leap | 500 Steel | `PART_MS_SPECIAL_ROCKETLUNGE` |
| The Twin Suns | 1000 Steel | `WP_DP_EXOTIC_BOMBS` |
| Rare Cell Core | 150 Gilded | `CONTAINER_CORE_GOLD_CELLCORE` |
| Discipline | 500 Steel | `PR_DISCIPLINE` |
| Mantle of the Victor | 500 Gilded | `AC_BACK_TRIALS_00` |
| Mantle of the Champion (rank-locked) | 1000 Gilded | `AC_BACK_TRIALS_01` |
| Lightweight Frame | 250 Steel | `PART_DP_PASSIVE_LOW_AMMO_MOVESPEED` |
| Precision Sights | 250 Steel | `PART_DP_PASSIVE_MARKSMAN_DAMAGE` |
| Extraction Catalyst | 250 Steel | `PART_DP_PASSIVE_PDODGE_COOLDOWNS` |
| Saboteur's Grip | 500 Steel | `PART_DP_GRIP_MINE` |
| Bastion Omnicell | 500 Steel | `PR_BASTION` |
| Iceborne Omnicell | 500 Steel | `PR_ICEBORNE` |
| Tempest Omnicell | 500 Steel | `PR_TEMPEST` |
| Revenant Omnicell | 500 Steel | `PR_DARKNESS` |
| Artificer Omnicell | 500 Steel | `PR_FRANK` |

R3 includes the R1 restoration plus nine further offers: three mods, Saboteur's Grip and five additional Omnicells. Eight preinstalled base-weapon special listings from R2 have been removed. These are custom shop additions requested by the user. Mods cost 250 Steel Marks; optional specials and all six Omnicells cost 500 Steel Marks.

R1 historical restoration prices remain documented in Source/audit.json. All six actual PlayerRole equipment IDs are used, including PR_DARKNESS for Revenant and PR_FRANK for Artificer.

The complete comparison against the Slayer's Path and base-weapon defaults is in Source/slayer-path-coverage.json, Source/Native/base-weapon-defaults.json and SLAYERS-PATH-COVERAGE.md.
