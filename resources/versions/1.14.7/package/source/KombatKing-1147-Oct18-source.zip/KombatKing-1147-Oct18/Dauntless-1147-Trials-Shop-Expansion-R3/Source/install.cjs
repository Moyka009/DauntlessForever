// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=path.resolve(__dirname,'..'),hash=b=>crypto.createHash('sha256').update(b).digest('hex'),read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const bytes=p=>fs.existsSync(p)?fs.readFileSync(p):null;
function write(p,b){if(b===null){fs.rmSync(p,{force:true});return;}fs.mkdirSync(path.dirname(p),{recursive:true});const t=p+'.trials-'+crypto.randomUUID();try{fs.writeFileSync(t,b,{flag:'wx'});fs.renameSync(t,p);}finally{fs.rmSync(t,{force:true});}}
function verify(){for(const[n,h]of Object.entries(read(path.join(base,'Integrity.json')).files)){if(path.isAbsolute(n)||n.split('/').includes('..')||hash(fs.readFileSync(path.join(base,n)))!==h)throw Error('Delivery integrity mismatch: '+n);}}
function install(root,action='install',options={}){
 if(!['install','check','restore'].includes(action))throw Error('Unknown action');verify();root=fs.realpathSync(root);
 const spec=read(path.join(__dirname,'compatibility.json')),target=path.join(root,'backend/trials1147-data.json'),runtime=path.join(root,'backend/trials1147.js'),dir=path.join(root,'backup/trials-store-expansion1147-r3'),receipt=path.join(dir,'installation.json'),pending=path.join(dir,'pending.json');
 if(fs.existsSync(pending))throw Error('Interrupted Trials shop transaction. Preserve backup/trials-store-expansion1147-r3 for recovery.');
 const r=fs.existsSync(receipt)?read(receipt):null,current=bytes(target),currentHash=current&&hash(current);
 if(r&&(r.root!==root||r.target!==target))throw Error('Trials backup belongs to a different package');
 if(action==='check')return{installed:!!r&&currentHash===spec.after_sha256&&hash(fs.readFileSync(runtime))===spec.runtime_sha256,catalog_offers:spec.offers,visible_non_dye_offers:68,mods:15,specials:6,omnicells:6,saves_preserved:true};
 if(action==='install'){
  const cfg=read(path.join(root,'config.json')),exe=path.join(cfg.GameDir,'Archon/Binaries/Win64/Dauntless-Win64-Shipping.exe');
  if(hash(fs.readFileSync(exe))!==spec.exe_sha256)throw Error('Requires the original 1.14.7 CL647472 game executable');
  if(hash(fs.readFileSync(runtime))!==spec.runtime_sha256)throw Error('Trials backend implementation differs from the reviewed current package. No files changed.');
 }
 if(r){
  const original=fs.readFileSync(path.join(dir,'catalog.original'));if(hash(original)!==r.before||!spec.accepted_before_sha256.includes(r.before))throw Error('Original Trials catalog backup failed verification');
  if(action==='install'){if(currentHash!==spec.after_sha256&&currentHash!==r.before)throw Error('Trials catalog changed after installation. No files changed.');if(currentHash===spec.after_sha256)return{installed:true,already_installed:true,offers:spec.offers,saves_preserved:true};}
  else if(currentHash!==spec.after_sha256&&currentHash!==r.before)throw Error('Trials catalog was changed by another update; refusing to overwrite it.');
  const after=action==='restore'?original:fs.readFileSync(path.join(base,'Payload/backend/trials1147-data.json'));
  write(pending,Buffer.from(JSON.stringify({action,target,before:currentHash})));
  try{write(target,after);options.afterWrite?.();fs.rmSync(pending);if(action==='restore')fs.renameSync(dir,dir+'-restored-'+crypto.randomUUID());}
  catch(e){write(target,current);fs.rmSync(pending,{force:true});throw e;}
  return{[action==='restore'?'restored':'installed']:true,offers:action==='restore'?JSON.parse(original.toString('utf8')).length:spec.offers,saves_preserved:true,other_patches_preserved:true};
 }
 if(action==='restore')throw Error('No Trials shop expansion installation record');
 if(fs.existsSync(dir))throw Error('Incomplete Trials shop backup folder; preserve it for recovery.');
 if(!spec.accepted_before_sha256.includes(currentHash))throw Error('Unknown existing Trials catalog. No files changed.');
 const after=fs.readFileSync(path.join(base,'Payload/backend/trials1147-data.json'));if(hash(after)!==spec.after_sha256)throw Error('Expanded catalog hash differs');
 fs.mkdirSync(dir,{recursive:true});
 try{fs.writeFileSync(path.join(dir,'catalog.original'),current,{flag:'wx'});write(pending,Buffer.from(JSON.stringify({action,target,before:currentHash})));write(target,after);options.afterWrite?.();write(receipt,Buffer.from(JSON.stringify({revision:3,root,target,before:currentHash,after:hash(after),created:new Date().toISOString()},null,2)));options.afterReceipt?.();fs.rmSync(pending);}
 catch(e){write(target,current);fs.rmSync(dir,{recursive:true,force:true});throw e;}
 return{installed:true,catalog_offers:spec.offers,visible_non_dye_offers:68,mods:15,specials:6,omnicells:6,prior_catalog_offers:JSON.parse(current.toString('utf8')).length,saves_preserved:true,runtime_unchanged:true,other_patches_preserved:true,champion_rank_lock_preserved:true};
}
if(require.main===module){try{const result=install(process.argv[3],process.argv[2]);console.log(JSON.stringify(result,null,2));if(process.argv[2]==='check'&&!result.installed)process.exitCode=1;}catch(e){console.error('STOPPED: '+e.message);process.exitCode=1;}}
module.exports={install,verify};
