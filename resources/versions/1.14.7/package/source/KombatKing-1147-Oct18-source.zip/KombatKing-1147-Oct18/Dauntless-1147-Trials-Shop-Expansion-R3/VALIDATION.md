# Validation — 18 October 2026

Target: Dauntless 1.14.7 CL647472, official backend package 2026-10-18.5, commit `5a8fe6e4f334ea86904476a117a4785af4632e8f`.

All 27 automated checks passed before delivery:

- 10 actual Trials-module checks: catalog size, native storage, exact Path/default exclusion and prices, existing ownership, all purchasable offers, rank locks, repeatability, idempotency, saved receipts, failure rollback, authentication and category filtering.
- 11 installer/restore checks: official install and restore, preservation of unrelated files, repeat-install backups, write/receipt failure rollback, restore rollback, unknown-file/corrupt-backup refusal, already-restored baseline, direct R1 upgrade/restore, failed upgrade rollback and direct R2 upgrade/restore with its backup/receipt retained.
- 6 complete-backend HTTP checks: startup/sign-in, exact 68 visible non-dye offers, absence and 404 lookup of all eight removed base-special SKUs, purchases/persistence/correct mark charges for all 34 unrestricted additions, Champion rank lock, and permanent ownership/repurchase protection after restart.

Native comparison uses 266 original weapon entries and their DefaultWeaponPartIDs, 467 Path nodes, 36 ordinary mods, 22 ordinary special options and six Omnicells. The final shop has 15 mods, six optional specials and six Omnicells at the requested prices.

The catalog has 72 entries; four original individual dyes remain hidden by the unchanged official dye-pack module. Of 35 additions, one (Champion mantle) remains rank-locked.

Catalog reconstruction is checked byte-for-byte against SHA256. Installer tests hash the exact original EXE without launching it. The Windows PowerShell wrapper is reviewed statically. Native Windows gameplay has not been executed here.
