# Slayer's Path and base-weapon coverage — original 1.14.7

Each ordinary selectable mod and special is compared against native Path reward ItemIDs and weapon-slot default ItemIDs. Repeater grips/chambers count as special options. Preinstalled base-weapon parts are excluded from the shop.

| Type | Item | Path node / base weapon | Shop price |
| --- | --- | --- | ---: |
| Mod | Cyclonic Strikeplate | WeaponTypeAC_Mod_00 | — |
| Mod | Echo Bracedriver | WeaponTypeAC_Mod_01 | — |
| Mod | Inertial Fistguard | WeaponTypeAC_Mod_02 | — |
| Mod | Hurricane Blades | WeaponTypeCB_Mod_01 | — |
| Mod | Lightweight Chain | WeaponTypeCB_Mod_00 | — |
| Mod | Serrated Blades | WeaponTypeCB_Mod_02 | — |
| Mod | Momentum Blades | Neither | 250 Steel |
| Mod | Demolition Blades | Neither | 250 Steel |
| Mod | Capacitive Magazine | WeaponTypeDP_Mod_00 | — |
| Mod | Scoped Sights | WeaponTypeDP_Mod_01 | — |
| Mod | Lucky Magazine | WeaponTypeDP_Mod_02 | — |
| Mod | Lightweight Frame | Neither | 250 Steel |
| Mod | Precision Sights | Neither | 250 Steel |
| Mod | Extraction Catalyst | Neither | 250 Steel |
| Mod | Tactician's Magazine | Neither | 250 Steel |
| Mod | Demolition Sights | Neither | 250 Steel |
| Mod | Recursive Hilt | WeaponTypeEB_Mod_01 | — |
| Mod | Charged Swordfocus | WeaponTypeEB_Mod_02 | — |
| Mod | Mending Bladecore | WeaponTypeEB_Mod_00 | — |
| Mod | Keen Edge | Neither | 250 Steel |
| Mod | Dynamic Bladecore | Neither | 250 Steel |
| Mod | Volatile Axecore | WeaponTypeGA_Mod_00 | — |
| Mod | Lightweight Haft | WeaponTypeGA_Mod_01 | — |
| Mod | Overcharged Cylinder | WeaponTypeGA_Mod_02 | — |
| Mod | Railsplitter's Canteen | Neither | 250 Steel |
| Mod | Furious Axecore | Neither | 250 Steel |
| Mod | Impulse Crown | WeaponTypeIH_Mod_01 | — |
| Mod | Extended Clip | WeaponTypeIH_Mod_02 | — |
| Mod | Weighted Crown | WeaponTypeIH_Mod_00 | — |
| Mod | Antique Clip | Neither | 250 Steel |
| Mod | Turbine Trigger | Neither | 250 Steel |
| Mod | Munitions Amplifier | WeaponTypeMS_Mod_00 | — |
| Mod | Lightweight Shaft | WeaponTypeMS_Mod_01 | — |
| Mod | Barbed Spearhead | Neither | 250 Steel |
| Mod | Executioner's Spearhead | Neither | 250 Steel |
| Mod | Balanced Spearhead | WeaponTypeMS_Mod_02 | — |
| Special | Adamant Bolt | Preinstalled on base weapons | — |
| Special | Titan's Crash | WeaponTypeAC_Spc_00 | — |
| Special | Reaper's Dance | Preinstalled on base weapons | — |
| Special | Insatiable Dance | Neither | 500 Steel |
| Special | Cruel Riftstrike | WeaponTypeCB_Spc_00 | — |
| Special | Captain's Grip | Preinstalled on base weapons | — |
| Special | Saboteur's Grip | Neither | 500 Steel |
| Special | Salvo Chamber | Preinstalled on base weapons | — |
| Special | Marksman Chamber | WeaponType_DP_Spc_000 | — |
| Special | Full-Bore Chamber | WeaponTypeDP_Spc_00 | — |
| Special | Valiant Overdrive | Preinstalled on base weapons | — |
| Special | Avenging Overdrive | Neither | 500 Steel |
| Special | Ardent Cyclone | WeaponTypeEB_Spc_00 | — |
| Special | Flight of Ruin | Preinstalled on base weapons | — |
| Special | Grim Onslaught | WeaponTypeGA_Spc_00 | — |
| Special | Relentless Onslaught | Neither | 500 Steel |
| Special | Concussive Salvo | Preinstalled on base weapons | — |
| Special | Mighty Landbreaker | WeaponTypeIH_Spc_00 | — |
| Special | Ironheart Landbreaker | Neither | 500 Steel |
| Special | Savage Wellspring | WeaponTypeMS_Spc_00 | — |
| Special | Concussive Payload | Preinstalled on base weapons | — |
| Special | Reckless Leap | Neither | 500 Steel |
| Omnicell | Bastion | All six requested regardless of Path | 500 Steel |
| Omnicell | Discipline | All six requested regardless of Path | 500 Steel |
| Omnicell | Iceborne | All six requested regardless of Path | 500 Steel |
| Omnicell | Tempest | All six requested regardless of Path | 500 Steel |
| Omnicell | Revenant | All six requested regardless of Path | 500 Steel |
| Omnicell | Artificer | All six requested regardless of Path | 500 Steel |

Exotic-only abilities marked bIsUnassignable remain tied to their native weapons. The comparison excludes those, explicit test entries, PAX duplicates, legendary abilities, repeater prisms and barrels. Their native evidence is included in Source/Native and Source/slayer-path-coverage.json.
