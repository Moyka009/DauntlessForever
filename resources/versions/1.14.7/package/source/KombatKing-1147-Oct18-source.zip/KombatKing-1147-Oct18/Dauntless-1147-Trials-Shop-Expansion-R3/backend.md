# Backend changes

Only `backend/trials1147-data.json` is replaced. The reviewed official Trials runtime and recorder route chain remain unchanged.

R3 filters out all offers granting an item found in native weapon-slot DefaultWeaponPartIDs. The included original 1.14.7 equipment audit contains 266 weapon entries. Their slot fields identify exactly eight R2 shop listings as preinstalled equipment: Adamant Bolt, Reaper's Dance, Captain's Grip, Salvo Chamber, Valiant Overdrive, Flight of Ruin, Concussive Salvo and Concussive Payload. No optional mod offer is a weapon-slot default.

The remaining catalog has 72 offers: the 37 reviewed official offers plus 35 additions. Its 15 mods cost 250 Steel Marks; its six optional specials cost 500 Steel Marks. All six native Omnicells cost 500 Steel Marks and grant actual instance-backed equipment: PR_BASTION, PR_DISCIPLINE, PR_ICEBORNE, PR_TEMPEST, PR_DARKNESS (Revenant) and PR_FRANK (Artificer). All original Champion restrictions, repeatable-cell/core behavior, inventory ownership and saved transaction protections remain enforced.

Source/Native/base-weapon-defaults.json includes the 266 weapons' original slot fields, audit archive SHA256, source member, original 1.14.7 manifest SHA1 and removed offers. Source/slayer-path-coverage.json distinguishes Path rewards, preinstalled defaults and shop items. The complete comparison still covers 36 ordinary mods and 22 ordinary special/grip/chamber options: 21 mods and 8 specials are Path rewards; 8 further specials are native defaults; the shop contains the remaining 15 mods and 6 specials. Full decoded part, override, composite, role and Path tables and original inspected asset pairs remain included.

The official dye module still filters four individual original dyes, leaving 68 non-dye offers. It is not changed. R1 returning reward prices and reconstructed restoration prices retain their documented provenance in Source/audit.json. Later custom shop additions remain identified as user-requested stock and prices.

Source/rebuild.cjs reconstructs the final catalog byte-for-byte. Source/package.cjs regenerates item/coverage lists, native evidence hashes, Windows line endings and integrity hashes.

Source/install.cjs accepts only the exact reviewed official, R1 or R2 catalog and original Trials runtime/game EXE. Its independent R3 backup records the exact pre-install catalog. Restore reinstates that catalog without editing R1/R2 backups or receipts. Caught replacement/receipt failures roll back. Unknown edits and corrupt backups are refused.

No player save, equipment instance, purchase receipt, personal setting, AIO receipt or native game file is edited by this change. A removed shop listing does not delete equipment already owned. Pending tokens for a removed SKU are rejected by the existing runtime as a changed offer before marks are charged.
