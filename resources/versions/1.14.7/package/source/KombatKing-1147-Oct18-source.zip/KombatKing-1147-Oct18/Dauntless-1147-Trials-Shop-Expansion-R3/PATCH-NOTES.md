# Trials shop expansion R3

- Remove every shop offer whose item is a native weapon-slot default, checked against 266 weapon entries.
- Remove Adamant Bolt, Reaper's Dance, Captain's Grip, Salvo Chamber, Valiant Overdrive, Flight of Ruin, Concussive Salvo and Concussive Payload.
- Keep all 15 non-Path mods at 250 Steel Marks, six optional non-Path/non-base specials at 500 Steel Marks and six Omnicells at 500 Steel Marks each.
- Retain the restored cells, Twin Suns, Rare Cell Core, mantles and existing Champion rank lock.
- Reduce the catalog from R2's 80 to 72 offers. Existing official dye filtering leaves 68 visible non-dye offers.
- Install directly over the reviewed official catalog, R1 or R2. Restore returns exactly to whichever catalog preceded R3; older patch receipts/backups are preserved.
- Preserve saved inventory and existing equipment when their duplicate shop listings are removed.
- Include the updated native Path/default coverage report, source, backend.md, AGPL license and independent Install/Check/Restore buttons.

Dyes and native gameplay are unchanged. The ownership diagnostic is not needed for the resolved starter-special listing issue and is not included.
