// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto'),base=path.resolve(__dirname,'..');
const read=n=>JSON.parse(fs.readFileSync(path.join(__dirname,n))),before=read('Reference/trials1147-data-before.json'),audit=read('audit.json'),native=new Map(read('Reference/native-items.json').map(i=>[i.id,i]));
const catalog=structuredClone(before);
for(const o of catalog){if(o.items.some(i=>i.catalogId==='PART_CB_PASSIVE_TRIALS_02'))o.tags=[...new Set([...o.tags,'store_trials_tab_mods'])];if(o.items.some(i=>i.catalogId==='LT_TRIALS_00'))o.tags=[...new Set([...o.tags,'store_trials_tab_equipment'])];}
for(const [index,a]of audit.additions.entries()){
 for(const i of a.items){const n=native.get(i.catalogId);assert(n,'Missing 1.14.7 item '+i.catalogId);assert.equal(i.kind,n.storage==='instance'?'instance':'stack');assert.equal(i.source,n.source);}
 catalog.push({...structuredClone(before[0]),id:a.sku,displayName:a.name,displayDescription:a.description,displayPriority:before.length+index+1,prices:[a.price],tags:['ladyluckstore','store_trials_tab_'+a.category],items:a.items,repeatable:a.repeatable,championOnly:a.champion_only});
}
assert.equal(catalog.length,72);assert.equal(new Set(catalog.map(o=>o.id)).size,72);
const bytes=Buffer.from(JSON.stringify(catalog,null,2)+'\n'),wanted=read('compatibility.json').after_sha256;assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),wanted);
if(process.argv.includes('--check'))assert(fs.readFileSync(path.join(base,'Payload/backend/trials1147-data.json')).equals(bytes));else fs.writeFileSync(path.join(base,'Payload/backend/trials1147-data.json'),bytes);
console.log('PASS catalog rebuilt byte-for-byte from the included references and audit');
