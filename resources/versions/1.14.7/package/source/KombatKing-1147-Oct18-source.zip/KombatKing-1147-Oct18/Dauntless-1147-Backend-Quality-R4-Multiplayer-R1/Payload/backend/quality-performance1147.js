// SPDX-License-Identifier: AGPL-3.0-only
// R4: reduce repeated work without delaying authoritative saves.
'use strict';
const fs=require('fs');
const clone=x=>JSON.parse(JSON.stringify(x));
const own=(o,k)=>Object.hasOwn(o,k);
function signature(file){try{const s=fs.statSync(file,{bigint:true});return [s.dev,s.ino,s.size,s.mtimeNs,s.ctimeNs].join(':');}catch(e){if(e.code==='ENOENT')return null;throw e;}}
function createWriter(quality){
 let cachedFile=null,cachedText=null,cachedSignature=null;
 const stats={diskReads:0,writes:0,unchanged:0};
 function save(file,state){
  // Serialize every requested save: mutations cannot be missed, and invalid values cannot become null.
  const data=JSON.stringify(state,(key,value)=>{if(typeof value==='number'&&!Number.isFinite(value))throw Error('Save contains a non-finite number');return value;},2);
  if(!state||typeof state!=='object'||Array.isArray(state)||!state.players||typeof state.players!=='object'||Array.isArray(state.players))throw Error('Invalid player save structure');
  const sig=signature(file);
  let old=null;
  if(sig!==null){
   if(file===cachedFile&&sig===cachedSignature)old=cachedText;
   else{
    old=fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'');stats.diskReads++;
    const parsed=JSON.parse(old);
    if(!parsed||typeof parsed!=='object'||Array.isArray(parsed)||!parsed.players||typeof parsed.players!=='object'||Array.isArray(parsed.players))throw Error('Invalid player save structure');
   }
   if(old===data){cachedFile=file;cachedText=old;cachedSignature=sig;stats.unchanged++;return false;}
   // Durability is retained: backup and main file still use fsync + atomic rename.
   quality.atomicWrite(file+'.bak',old);
  }
  quality.atomicWrite(file,data);
  cachedFile=file;cachedText=data;cachedSignature=signature(file);stats.writes++;
  return true;
 }
 return{save,stats,clear(){cachedFile=cachedText=cachedSignature=null;}};
}
function freeze(x){if(x&&typeof x==='object'&&!Object.isFrozen(x)){for(const v of Object.values(x))freeze(v);Object.freeze(x);}return x;}
function cachedConfig(build,windowKey){
 let key,value;
 return()=>{const next=windowKey();if(value===undefined||key!==next){const built=freeze(build());value=built;key=next;}return value;};
}
function bountyTransaction(p,fn){
 const fields=['bounties'],metaFields=['bounties','huntpassSeasons'];
 const before=new Map(fields.map(k=>[k,own(p,k)?clone(p[k]):undefined]));
 const hasMeta=own(p,'mega1147'),meta=p.mega1147;
 const metaBefore=new Map(metaFields.map(k=>[k,meta&&own(meta,k)?clone(meta[k]):undefined]));
 const presence=new Set(fields.filter(k=>own(p,k))),metaPresence=new Set(metaFields.filter(k=>meta&&own(meta,k)));
 try{return fn();}catch(error){
  for(const k of fields)if(presence.has(k))p[k]=before.get(k);else delete p[k];
  if(!hasMeta)delete p.mega1147;
  else{p.mega1147=meta;if(meta&&typeof meta==='object')for(const k of metaFields)if(metaPresence.has(k))meta[k]=metaBefore.get(k);else delete meta[k];}
  throw error;
 }
}
module.exports={createWriter,cachedConfig,bountyTransaction};
