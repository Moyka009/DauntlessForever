// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),T=require('./performance-patch.cjs');
const base=path.resolve(__dirname,'..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const names=[...Object.keys(T.edits),'backend/quality-performance1147.js','tools/server-log-reader1147.ps1'];
function safe(p){for(p=path.resolve(p);;p=path.dirname(p)){if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('Linked R4 paths are not supported: '+p);if(path.dirname(p)===p)break;}}
function bytes(p){return fs.existsSync(p)?fs.readFileSync(p):null;}
function write(p,b){safe(p);if(b===null){fs.rmSync(p,{force:true});return;}const tmp=p+'.r4-'+crypto.randomUUID();try{fs.writeFileSync(tmp,b,{flag:'wx'});fs.renameSync(tmp,p);}finally{fs.rmSync(tmp,{force:true});}}
function inspect(root){root=fs.realpathSync(root);const dir=path.join(root,'backup/backend-quality1147-r4');safe(dir);for(const n of names)safe(path.join(root,n));if(fs.existsSync(path.join(dir,'pending.json')))throw Error('Interrupted R4 installation; preserve '+dir+' for recovery');const record=fs.existsSync(path.join(dir,'installation.json'))?JSON.parse(fs.readFileSync(path.join(dir,'installation.json'),'utf8')):null;return{root,dir,record,before:names.map(n=>bytes(path.join(root,n)))};}
function valid(x){return !!x.record&&x.record.root===x.root&&x.record.files.length===names.length&&x.record.files.every((f,i)=>f.rel===names[i]&&f.backup===i+'.original'&&(f.before===null||/^[0-9a-f]{64}$/.test(f.before))&&x.before[i]&&sha(x.before[i])===f.after);}
function prepare(root,action='install'){
 const x=inspect(root);
 if(x.record){if(!valid(x))throw Error('R4 installed files differ; no files changed');for(const f of x.record.files){const b=f.before===null?null:bytes(path.join(x.dir,f.backup));if(f.before!==null&&(!b||sha(b)!==f.before))throw Error('R4 backup differs: '+f.rel);}return x;}
 if(action==='restore')throw Error('No R4 installation record');
 if(fs.existsSync(x.dir)||x.before.slice(-2).some(Boolean))throw Error('Unrecorded R4 backup/helper found; no files changed');
 for(let i=1;i<Object.keys(T.edits).length;i++){
  const rel=names[i],b=x.before[i];if(!b)throw Error('Missing R4 target: '+rel);
  const reference=fs.readFileSync(path.join(__dirname,'Reference/performance',rel));
  const variants=[reference];if(rel==='backend/huntpass1147.js')variants.push(require('./Compatibility/free-patch.cjs').huntpass(reference));
  const normalize=b=>b.toString('utf8').replaceAll('\r\n','\n');
  if(!variants.some(v=>normalize(v)===normalize(b)))throw Error('Unreviewed R4 target: '+rel+'; no files changed');
  T.patch(rel,b);
 }
 return x;
}
function install(root,action='install',options={}){
 if(!['install','check','restore'].includes(action))throw Error('Unknown R4 action');
 const x=action==='check'?inspect(root):prepare(root,action);
 if(action==='check')return{installed:valid(x),record_present:!!x.record,revision:4};
 if(x.record&&action==='install')return{installed:true,already_installed:true,revision:4};
 let after;
 if(action==='restore')after=x.record.files.map(f=>f.before===null?null:fs.readFileSync(path.join(x.dir,f.backup)));
 else{after=names.map((rel,i)=>T.edits[rel]?T.patch(rel,x.before[i]):fs.readFileSync(path.join(base,'Payload',rel)));}
 const files=action==='restore'?x.record.files:names.map((rel,i)=>({rel,before:x.before[i]?sha(x.before[i]):null,after:sha(after[i]),backup:i+'.original'}));
 if(action==='install')fs.mkdirSync(x.dir,{recursive:true});
 try{
  if(action==='install')files.forEach((f,i)=>{if(x.before[i])fs.writeFileSync(path.join(x.dir,f.backup),x.before[i],{flag:'wx'});});
  write(path.join(x.dir,'pending.json'),Buffer.from(JSON.stringify({action,files})));
  after.forEach((b,i)=>write(path.join(x.root,names[i]),b));options.afterWrite?.();
  if(after.some((b,i)=>b===null?fs.existsSync(path.join(x.root,names[i])):!fs.readFileSync(path.join(x.root,names[i])).equals(b)))throw Error('R4 written file verification failed');
  if(action==='install'){write(path.join(x.dir,'installation.json'),Buffer.from(JSON.stringify({root:x.root,revision:4,files,created:new Date().toISOString()},null,2)));options.afterReceipt?.();}
  fs.rmSync(path.join(x.dir,'pending.json'));
  if(action==='restore')fs.renameSync(x.dir,x.dir+'-restored-'+crypto.randomUUID());
 }catch(error){x.before.forEach((b,i)=>write(path.join(x.root,names[i]),b));if(action==='install')fs.rmSync(x.dir,{recursive:true,force:true});else fs.rmSync(path.join(x.dir,'pending.json'),{force:true});throw error;}
 return{installed:action==='install',restored:action==='restore',revision:4,saves_preserved:true};
}
module.exports={prepare,install,names};
