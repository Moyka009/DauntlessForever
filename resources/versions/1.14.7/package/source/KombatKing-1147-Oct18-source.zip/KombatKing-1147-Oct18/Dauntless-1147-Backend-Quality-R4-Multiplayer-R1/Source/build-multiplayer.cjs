// SPDX-License-Identifier: AGPL-3.0-only
const fs=require('fs'),path=require('path'),T=require('./multiplayer-patch.cjs');
for(const rel of Object.keys(T.edits)){
 const source=['backend/recorder-1147.js','tools/online-host-1147.ps1'].includes(rel)?path.join(__dirname,'Built',rel):path.join(__dirname,'MultiplayerReference',rel);
 const out=path.join(__dirname,'BuiltMultiplayer',rel);fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,T.patch(rel,fs.readFileSync(source)));
}
console.log('PASS multiplayer transforms on included reviewed reference scripts');
