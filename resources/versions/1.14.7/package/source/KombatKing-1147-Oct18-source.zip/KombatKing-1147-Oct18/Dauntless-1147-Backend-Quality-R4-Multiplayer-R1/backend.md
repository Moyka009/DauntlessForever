# Backend changes — R4 Multiplayer R1

The multiplayer overlay modifies backend/recorder-1147.js and adds backend/multiplayer1147.js. All R4 foundation changes are retained.

recorder-1147.js:
- Reconstruct place occupancy before matchmaking and status checks; refresh participant activity only from identified requests.
- Release old place ownership on new sign-in and explicit departure.
- Refuse a different occupied hunt with HTTP 409 and a structured matchmaking error, keeping existing candidates unchanged.
- Scope failed-candidate cleanup to its own place ID.
- Recover parties from state.multiplayer1147Parties; save accepted membership, leadership and removal changes. If the durable save fails, reload the party maps from recovered state before returning the error.
- Replace the age-only party-follow cutoff with matching-live-server liveness (pending requests retain a bounded age).
- Use the correct destination marker for solo party readiness.
- Emit four-player training options.

multiplayer1147.js:
- Lazily reconstruct an occupied hunt from the live/wanted marker and saved candidates.
- Preserve unidentified live hunts instead of assuming they are empty.
- Maintain an in-memory renewable 30-minute lease per identified player.
- Track explicitly retired hunt IDs to avoid resurrecting a just-released map during the supervisor's shutdown grace period.
- Do not defer player progress saves or write a separate shadow player database.

tools/df-gateway-1147.js and join-proxy-1147.js validate ports. online-host-1147.ps1 monitors gateway death. travel-1147.js adds home-write conflict checks, unique backups/temporary paths and a response bound. lan-join-1147.ps1 adds a local-profile guard, stops unsafe uploads/recovery, and pauses periodic saves on exit code 4. tools/multiplayer-join-check1147.js implements the saved-character preflight.

Installer receipts:
- R4 foundation: existing backend-quality1147-r2, background1147-r1 and backend-quality1147-r4 receipts.
- Multiplayer overlay: backup/backend-quality1147-r4-multiplayer.
- Combined installer bookkeeping: backup/backend-quality1147-r4-multiplayer-main.

The installer changes code only. Runtime party membership is stored as additional metadata in the existing state file; restoring code preserves that metadata and all player data. Runtime leases are intentionally conservative; native connection liveness is not available to this backend.

No ASAR, native address, DLL, PAK, retail game executable or NOTICE file is changed. Native tutorial execution and late-join map-option quest mappings remain unimplemented.
