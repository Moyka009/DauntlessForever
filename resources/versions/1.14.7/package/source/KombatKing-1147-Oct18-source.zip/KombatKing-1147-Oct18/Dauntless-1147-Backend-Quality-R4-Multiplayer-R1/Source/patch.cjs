// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const edits=[
 ["var huntpassSeasons1147 = require('./huntpass-seasons1147').create(ROOT);", "if (!args.includes('--summary') && !args.includes('--events')) loadState(); // Recover before season initialization reads state.json\nvar huntpassSeasons1147 = require('./huntpass-seasons1147').create(ROOT);"],
 ["  loadState();\n  capRoot = findCaptures();", "  // State was loaded before feature module initialization.\n  capRoot = findCaptures();"],
 ["const quality = require('./quality');","const quality = require('./quality');\nconst qualityRuntime1147 = require('./quality-runtime1147'); // KK-BACKEND-QUALITY-R2"],
 ["  const b = bearerOf(req);\n  return (b ? sessions.get(b) : null) || (req && req._pkey) || state.lastPlayer || 'local';","  return req.qualityPlayerKey || qualityRuntime1147.resolvePlayer(req,state,sessions,bearerOf,t=>epicSubOf(t)?playerKeyFromEpicToken(t):null);"],
 ["function inventoryOf(player, characterId) {","function inventoryOf(player, characterId) {\n  if (characterId && !player.characters.some(c=>c.id===characterId)) throw quality.httpError(403,'Inventory character does not belong to this account');"],
 ["  ensureStarterItems(player.inventory[id]);","  qualityRuntime1147.inventory(player.inventory[id]);\n  ensureStarterItems(player.inventory[id]);"],
 ["  const pathName = url.pathname;","  const pathName = url.pathname;\n  req.qualityOwned = qualityRuntime1147.owned(svc.service,pathName.replace(/\\/$/,''));"],
 ["  let body;\n  if (bodyBuf.length) { try { body = JSON.parse(bodyBuf.toString('utf8')); } catch (e) { body = undefined; } }","  let body, requestError;\n  try { body=qualityRuntime1147.parseBody(bodyBuf); qualityRuntime1147.validate(svc.service,req.method,pathName,body); }\n  catch(e) { requestError={status:e.status||400,note:'request refused: '+scrubString(e.message)}; }\n  req.playerBody = req.qualityOwned ? body : undefined;\n  if(!requestError && req.qualityOwned)try{req.qualityPlayerKey=qualityRuntime1147.resolvePlayer(req,state,sessions,bearerOf,t=>epicSubOf(t)?playerKeyFromEpicToken(t):null);}catch(e){requestError={status:e.status||400,note:'player identity refused: '+scrubString(e.message)};}"],
 ["if(!Number.isSafeInteger(total))throw quality.httpError(400,'Stacked quantity is too large');","if(!Number.isSafeInteger(total)||total>2147483647)throw quality.httpError(400,'Stacked quantity is too large');"],
 ["cur.progress = gameRules.sumTrack(t.progression_id, cur.progress, Number(t.progress) || 0);", "cur.progress = qualityRuntime1147.total(gameRules.sumTrack(t.progression_id, cur.progress, Number(t.progress) || 0));"],
 ["cur.progress = gameRules.sumTrack(id, cur.progress, gameRules.track(id, Number(c.match[2]) || 0));", "cur.progress = qualityRuntime1147.total(gameRules.sumTrack(id, cur.progress, gameRules.track(id, Number(c.match[2]) || 0)));"],
 ["  if (pathName === '/_recorder/ping')", "  if (requestError) { reply=requestError; known=true; }\n  else if (pathName === '/_recorder/ping')"],
 ["catch(e) { reply={status:e.status||500,note:'feature module: '+scrubString(e.message)};", "catch(e) { reply={status:e.status||(e instanceof URIError?400:500),note:'feature module: '+scrubString(e.message)};"],
 ["      req.on('end', () => { try { handle(svc, svc.port, req, res, Buffer.concat(chunks));", "      req.on('end', () => { if(size>MAX_BODY){ res.writeHead(413,{'Content-Length':0}); res.end(); logLine({t:new Date().toISOString(),port:svc.port,svc:svc.service,m:req.method,path:String(req.url||'').split('?')[0].slice(0,900),status:413,known:true,note:'request exceeds 8 MiB; not dispatched',reqLen:size,resLen:0}); return; } try { handle(svc, svc.port, req, res, Buffer.concat(chunks));"]
];
function once(s,a,b){if(s.split(a).length!==2)throw Error('Reviewed quality anchor differs: '+a.slice(0,80));return s.replace(a,b);}
function patch(bytes){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');for(const[a,b]of edits)s=once(s,a,b);return Buffer.from(s.replaceAll('\n',nl));}
function unpatch(bytes){let s=bytes.toString('utf8'),nl=s.includes('// KK-BACKEND-QUALITY-R2\r\n')?'\r\n':'\n';for(const[a,b]of [...edits].reverse())s=once(s,b.replaceAll('\n',nl),a.replaceAll('\n',nl));return Buffer.from(s);}
module.exports={patch,unpatch};
