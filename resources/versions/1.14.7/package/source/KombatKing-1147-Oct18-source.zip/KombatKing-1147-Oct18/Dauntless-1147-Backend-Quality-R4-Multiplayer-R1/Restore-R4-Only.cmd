@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run.ps1" -Action restore-r4
if errorlevel 1 echo STOPPED: Read the reason above.
pause
