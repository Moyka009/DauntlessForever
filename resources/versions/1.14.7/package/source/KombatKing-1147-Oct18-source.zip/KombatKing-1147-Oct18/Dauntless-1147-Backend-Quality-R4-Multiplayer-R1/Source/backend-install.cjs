// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),net=require('net');
const P=require('./patch.cjs'),L=require('./Compatibility/patch.cjs'),F=require('./Compatibility/free-patch.cjs');
const base=path.resolve(__dirname,'..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'')),bytes=p=>fs.existsSync(p)?fs.readFileSync(p):null;
const rels=['backend/recorder-1147.js','backend/quality.js','backend/quality-runtime1147.js'];
function safe(p){for(p=path.resolve(p);;p=path.dirname(p)){if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('Linked patch paths are not supported: '+p);if(path.dirname(p)===p)break;}}
function write(p,b){safe(p);if(b===null){fs.rmSync(p,{force:true});return;}fs.mkdirSync(path.dirname(p),{recursive:true});const tmp=p+'.quality-'+crypto.randomUUID();try{fs.writeFileSync(tmp,b,{flag:'wx'});fs.renameSync(tmp,p);}finally{fs.rmSync(tmp,{force:true});}}
function verify(){for(const [n,h]of Object.entries(read(path.join(base,'INTEGRITY.json'))))if(path.isAbsolute(n)||n.split('/').includes('..')||sha(fs.readFileSync(path.join(base,n)))!==h)throw Error('Delivery integrity mismatch: '+n);}
function originalBackend(b){if(b.includes(Buffer.from(F.requireLine)))b=F.unpatch(b,false);if(b.includes(Buffer.from(L.marker)))b=L.unpatch(b);return b;}
function install(root,action='install',options={}){
 if(!['install','check','restore'].includes(action))throw Error('Unknown action');verify();root=fs.realpathSync(root);
 const dir=path.join(root,'backup/backend-quality1147-r2'),receipt=path.join(dir,'installation.json'),pending=path.join(dir,'pending.json');
 for(const n of [...rels,'backup/backend-quality1147-r2'])safe(path.join(root,n));
 if(fs.existsSync(pending))throw Error('Interrupted quality installation; preserve '+dir+' for recovery');
 const record=fs.existsSync(receipt)?read(receipt):null,current=rels.map(n=>bytes(path.join(root,n)));
 if(!current[0]||!current[1])throw Error('Active 1.14.7 backend is missing');
 const validHook=()=>{try{P.unpatch(current[0]);return true;}catch{return false;}};
 if(action==='check')return {installed:!!record&&record.root===root&&validHook()&&record.files.every((f,i)=>i===0||current[i]&&sha(current[i])===f.after),package:root,revision:2,saves_preserved:true,capture_folder_present:fs.existsSync(path.join(root,'captures'))};
 if(record&&record.root!==root)throw Error('Patch backup belongs to another package');
 if(record){
  const originals=record.files.map(f=>{if(f.before===null)return null;const b=fs.readFileSync(path.join(dir,f.backup));if(sha(b)!==f.before)throw Error('Original backup differs: '+f.rel);return b;});
  if(!validHook()||record.files.some((f,i)=>i>0&&(!current[i]||sha(current[i])!==f.after)))throw Error('Installed quality files differ. No files changed.');
  if(action==='install')return {installed:true,already_installed:true,revision:2};
  const desired=[P.unpatch(current[0]),...originals.slice(1)];
  write(pending,Buffer.from(JSON.stringify({action:'restore',files:record.files})));
  try{desired.forEach((b,i)=>write(path.join(root,rels[i]),b));options.afterWrite?.();fs.rmSync(pending);fs.renameSync(dir,dir+'-restored-'+crypto.randomUUID());}
  catch(e){current.forEach((b,i)=>write(path.join(root,rels[i]),b));fs.rmSync(pending,{force:true});throw e;}
  return {restored:true,saves_preserved:true,other_patches_preserved:true};
 }
 if(action==='restore')throw Error('No Backend Quality R2 installation record');
 if(fs.existsSync(dir)||current[2]||current[0].includes(Buffer.from('KK-BACKEND-QUALITY-R2')))throw Error('Unrecorded quality files/backup found; no files changed');
 const cfg=read(path.join(root,'config.json')),exe=path.join(cfg.GameDir,'Archon/Binaries/Win64/Dauntless-Win64-Shipping.exe');
 if(sha(fs.readFileSync(exe))!=='f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b')throw Error('Requires original 1.14.7 CL647472 executable');
 const spec=read(path.join(__dirname,'compatibility.json'));
 if(!spec.acceptedBackendSha256.includes(sha(originalBackend(current[0]))))throw Error('Backend is not a reviewed official/AIO build. No files changed.');
 if(!spec.qualityBeforeSha256.includes(sha(current[1])))throw Error('Quality helper is not a reviewed version. No files changed.');
 const desired=[P.patch(current[0]),fs.readFileSync(path.join(base,'Payload/backend/quality.js')),fs.readFileSync(path.join(base,'Payload/backend/quality-runtime1147.js'))];
 const files=rels.map((rel,i)=>({rel,before:current[i]?sha(current[i]):null,after:sha(desired[i]),backup:i+'.original'}));fs.mkdirSync(dir,{recursive:true});
 try{
  files.forEach((f,i)=>{if(current[i])fs.writeFileSync(path.join(dir,f.backup),current[i],{flag:'wx'});});write(pending,Buffer.from(JSON.stringify({action:'install',files})));
  desired.forEach((b,i)=>write(path.join(root,rels[i]),b));options.afterWrite?.();
  write(receipt,Buffer.from(JSON.stringify({root,revision:2,files,created:new Date().toISOString()},null,2)));options.afterReceipt?.();
  if(desired.some((b,i)=>!fs.readFileSync(path.join(root,rels[i])).equals(b)))throw Error('Installed file verification failed');fs.rmSync(pending);
 }catch(e){current.forEach((b,i)=>write(path.join(root,rels[i]),b));fs.rmSync(dir,{recursive:true,force:true});throw e;}
 return {installed:true,revision:2,package:root,saves_preserved:true,other_patches_preserved:true,native_files_changed:false};
}
async function stopped(){const open=await new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port:63000});let done=false;const end=v=>{if(!done){done=true;s.destroy();resolve(v);}};s.on('connect',()=>end(true));s.on('error',()=>end(false));s.setTimeout(700,()=>end(false));});if(open)throw Error('Close the game and backend first');}
if(require.main===module)(async()=>{const action=process.argv[2];if(action!=='check')await stopped();const r=install(process.argv[3],action);console.log(JSON.stringify(r,null,2));if(action==='check'&&!r.installed)process.exitCode=1;})().catch(e=>{console.error('STOPPED: '+e.message);process.exitCode=1;});
module.exports={install,verify,sha,stopped};
