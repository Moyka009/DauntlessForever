# SPDX-License-Identifier: AGPL-3.0-only
# Runs before any worker or its output logs are created. Children inherit the session marker.
function Initialize-BackgroundLogs1147 {
    if ($env:DF_LOG_SESSION_1147) { return }
    if ((Test-Recorder) -or @(Get-ServerCopies).Count -gt 0) {
        $env:DF_LOG_SESSION_1147 = 'existing-session'
        return
    }
    $logConfig = Get-Config
    if (-not $logConfig) { return }
    $logNode = $logConfig.Node
    if (-not $logNode -or -not (Test-Path -LiteralPath $logNode)) { $logNode = Find-Node }
    if (-not $logNode) { return }
    try {
        $cleanupOutput = & $logNode (Join-Path $PSScriptRoot 'clear-startup-logs1147.cjs') $Root
        if ($LASTEXITCODE -ne 0) { throw 'cleanup failed' }
        $cleanupResult = ($cleanupOutput -join "`n") | ConvertFrom-Json
        if ($cleanupResult.failed -gt 0) { Say 'Some old logs are still open and could not be deleted.' 'Yellow' }
        $env:DF_LOG_SESSION_1147 = [Guid]::NewGuid().ToString('N')
    } catch { Say 'Old log cleanup could not finish; startup will continue.' 'Yellow' }
}
