// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),T=require('./performance-patch.cjs');
for(const rel of Object.keys(T.edits)){const input=rel.includes('recorder')?'Reference/official-2026-10-18.5.js':'Reference/performance/'+rel;let b=fs.readFileSync(path.join(__dirname,input));if(rel.includes('recorder'))b=require('./patch.cjs').patch(b);const dest=path.join(__dirname,'Built',rel);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,T.patch(rel,b));}
fs.copyFileSync(path.join(__dirname,'../Payload/backend/quality-performance1147.js'),path.join(__dirname,'Built/backend/quality-performance1147.js'));
console.log('Built five performance-overlay outputs from bundled reviewed source.');
