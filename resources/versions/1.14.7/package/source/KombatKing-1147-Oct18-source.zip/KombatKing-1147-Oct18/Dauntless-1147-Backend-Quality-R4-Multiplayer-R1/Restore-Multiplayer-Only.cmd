@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run.ps1" -Action restore-multiplayer
set "patch_result=%errorlevel%"
pause
exit /b %patch_result%
