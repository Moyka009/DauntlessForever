// SPDX-License-Identifier: AGPL-3.0-only
// Backend Quality R2, KombatKing / Codex, 2026. Retains Addison2k's offline routing.
'use strict';
const quality=require('./quality'),MAX=2147483647;
const object=x=>!!x&&typeof x==='object'&&!Array.isArray(x);
function fail(message,status=400){throw quality.httpError(status,message);}
function parseBody(bytes){
 if(!bytes.length)return undefined;
 let body;try{body=JSON.parse(bytes.toString('utf8'));}catch{fail('Request body is not valid JSON');}
 function visit(x,depth){
  if(depth>64)fail('Request JSON nesting is too deep');
  if(typeof x==='number'&&!Number.isFinite(x))fail('Request contains a non-finite number');
  if(x&&typeof x==='object')for(const [k,v]of Object.entries(x)){
   if(['__proto__','prototype','constructor'].includes(k))fail('Invalid request object key');
   visit(v,depth+1);
  }
 }
 visit(body,0);return body;
}
function owned(service,url){
 if(service==='progression'&&['/progression/config','/bounty/game-data'].includes(url))return false;
 return service==='dauntless'&&/^\/(inventory|character)(\/|$)/.test(url)||service==='loadout'||
  service==='progression'&&/^\/(progression|pjm|bounty|escalation|cooldown|tracker|encountered-content|huntpass)(\/|$)/.test(url)||
  service==='gauntlet'&&/^\/(progression|rewards)\//.test(url)||
  service==='auth'&&/^\/(entitlements?v2|accountinfo)(\/|$)/.test(url)&&url!=='/accountinfo/public';
}
function resolvePlayer(req,state,sessions,bearer,epicKey){
 const token=bearer(req),key=token&&(sessions.get(token)||epicKey(token));
 if(token&&(!key||!state.players[key]))fail('Player session is missing or expired; sign in again',401);
 if(key&&!req.qualityOwned)return key;
 if(req.qualityOwned){
  return quality.playerKey(req,state,sessions,bearer,epicKey);
 }
 const keys=Object.keys(state.players);
 if(keys.length===1)return keys[0];
 if(!keys.length&&!token)return 'local';
 fail('Player identity is ambiguous; sign in again',401);
}
function number(value,label,{negative=false,integer=true}={}){
 if(value===undefined)return;
 const n=typeof value==='number'?value:typeof value==='string'&&value.trim()?Number(value):NaN;
 if(!Number.isFinite(n)||integer&&!Number.isInteger(n)||n>MAX||n<(negative?-MAX:0))fail('Invalid '+label);
}
function id(value,label){if(typeof value!=='string'||!value.length||value.length>512||['__proto__','prototype','constructor'].includes(value))fail('Invalid '+label);}
function validate(service,method,url,body){
 if(!['POST','PUT'].includes(method))return;
 if(service==='dauntless'&&/^\/character\/?$/.test(url)&&!object(body))fail('Character update must be an object');
 if(service==='dauntless'&&/^\/inventory\/?$/.test(url)){
  if(!object(body))fail('Inventory update must be an object');
  for(const kind of ['addStackedItems','removeStackedItems'])if(Array.isArray(body[kind]))for(const item of body[kind]){
   if(!object(item))fail('Invalid stacked item');id(item.catalogId,'catalog ID');number(item.quantity,'inventory quantity');
  }
 }
 if(service==='progression'&&/^\/progression(?:\/[^/]+)?\/?$/.test(url)){
  if(!object(body))fail('Progression update must be an object');
  for(const key of ['progress_tracks','objectives'])if(body[key]!==undefined&&!Array.isArray(body[key]))fail('Invalid '+key+' list');
  for(const t of body.progress_tracks||[]){if(!object(t))fail('Invalid progress track');id(t.progression_id,'track ID');number(t.progress,'track progress',{negative:true});}
  for(const o of body.objectives||[]){if(!object(o))fail('Invalid objective');id(o.objective_id,'objective ID');number(o.value,'objective progress',{integer:false});number(o.completed_count,'objective count');}
 }
 if(service==='progression'&&/^\/progression\/[^/]+\/[^/]+\/-?\d+\/?$/.test(url))number(Number(url.replace(/\/$/,'').split('/').pop()),'track delta',{negative:true});
}
function inventory(inv){
 if(!object(inv)||!Array.isArray(inv.stackedItems)||!Array.isArray(inv.instancedItems))fail('Saved inventory is malformed',409);
 for(const item of inv.stackedItems){if(!object(item))fail('Saved stack is malformed',409);number(item.quantity,'saved stacked quantity');}
}
function total(value){number(value,'progression total');return value;}
module.exports={parseBody,owned,resolvePlayer,validate,inventory,total,MAX};
