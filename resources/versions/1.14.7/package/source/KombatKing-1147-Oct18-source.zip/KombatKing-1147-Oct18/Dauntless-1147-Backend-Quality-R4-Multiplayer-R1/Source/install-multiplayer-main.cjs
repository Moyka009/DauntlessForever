// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=require('./r4-base.cjs'),core=require('./backend-install.cjs'),background=require('./background.cjs'),performance=require('./performance-install.cjs'),mp=require('./multiplayer-install.cjs');
function levels(root){return{core:core.install(root,'check').installed,background:background.install(root,'check').installed,performance:performance.install(root,'check').installed};}
function undoNew(root,had){if(!had.performance&&performance.install(root,'check').installed)performance.install(root,'restore');if(!had.background&&background.install(root,'check').installed)background.install(root,'restore');if(!had.core&&core.install(root,'check').installed)core.install(root,'restore');}
function install(root,action='install',options={}){
 core.verify();root=mp.inspect(root).root;const folder=path.join(root,'backup/backend-quality1147-r4-multiplayer-main'),file=path.join(folder,'installation.json');mp.safe(folder);
 const meta=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):null;
 const current=mp.install(root,'check');
 if(action==='check')return{installed:current.installed&&mp.foundationValid(root),revision:4,multiplayer:current.installed,saves_preserved:true};
 if(action==='restore-multiplayer'){if(!mp.foundationValid(root))throw Error('R4 foundation or multiplayer changed; no files changed.');return{...mp.install(root,'restore',options.multiplayer),r4_retained:true};}
 if(action==='restore-r4'){if(current.record_present)throw Error('Restore the multiplayer overlay first.');return base.install(root,action,options);}
 if(action==='install'){
  if(current.record_present){if(!mp.foundationValid(root))throw Error('Installed R4/multiplayer files changed; no files changed.');return{installed:true,already_installed:true,revision:4,multiplayer:true};}
  mp.preflight(root);const had=levels(root),retain=meta?.had||had;
  base.install(root,'install',options);
  try{const result=mp.install(root,'install',options.multiplayer);if(!meta){fs.mkdirSync(folder,{recursive:true});mp.write(file,Buffer.from(JSON.stringify({root:fs.realpathSync(root),had:retain},null,2)));}return{...result,r4_included:true,prior_r4_preserved:had.performance,hidden_workers:true};}
  catch(e){if(mp.install(root,'check').installed)mp.install(root,'restore');undoNew(root,had);throw e;}
 }
 if(action==='restore'){
  if(!meta){if(current.record_present)throw Error('Main installation receipt missing; preserve backup and request recovery.');return base.install(root,'restore',options);}
  if(meta.root!==fs.realpathSync(root))throw Error('Main backup belongs to another package.');
  if(current.record_present){if(!mp.foundationValid(root))throw Error('Installed R4/multiplayer changed; no files changed.');mp.install(root,'restore',options.multiplayer);}
  const had=meta.had;undoNew(root,had);fs.renameSync(folder,folder+'-restored-'+crypto.randomUUID());
  return{restored:true,revision:4,multiplayer_removed:true,preexisting_r4_retained:had.performance,saves_preserved:true};
 }
 throw Error('Unknown action.');
}
module.exports={install};
if(require.main===module)(async()=>{if(process.argv[2]!=='check')await core.stopped();const r=install(process.argv[3],process.argv[2]);console.log(JSON.stringify(r,null,2));if(process.argv[2]==='check'&&!r.installed)process.exitCode=1;})().catch(e=>{console.error('STOPPED: '+e.message);process.exitCode=1;});
