// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const foundation=require('./foundation-r3.cjs'),core=require('./backend-install.cjs'),background=require('./background.cjs'),performance=require('./performance-install.cjs');
function install(root,action='install',options={}){
 core.verify();
 const old=foundation.install(root,'check'),perf=performance.install(root,'check');
 if(action==='check')return{...old,installed:old.installed&&perf.installed,revision:4,performance_optimizations:perf.installed};
 if(action==='restore-r4'){if(!old.installed)throw Error('Foundation changed; no files changed');return{...performance.install(root,'restore'),foundation_r3_retained:true};}
 if(action==='install'){
  performance.prepare(root);
  const hadCore=core.install(root,'check').installed,hadBackground=background.install(root,'check').installed;
  const result=foundation.install(root,'install',options);
  try{return{...result,...performance.install(root,'install',options.performance),already_installed:!!result.already_installed&&perf.installed,background_workers_hidden:true,immediate_durable_saves:true};}
  catch(error){if(!hadBackground&&background.install(root,'check').installed)background.install(root,'restore');if(!hadCore&&core.install(root,'check').installed)core.install(root,'restore');throw error;}
 }
 if(action==='restore'){
  if(old.installed&&!perf.installed&&!perf.record_present){performance.prepare(root);return{...foundation.install(root,'restore',options),revision:4,performance_already_restored:true};}
  if(!old.installed||!perf.installed)throw Error('R4 or foundation files differ; no files changed');
  performance.prepare(root,'restore');background.prepare(root,'restore');
  performance.install(root,'restore',options.performance);
  try{return{...foundation.install(root,'restore',options),revision:4,performance_restored:true};}
  catch(error){performance.install(root,'install');throw error;}
 }
 throw Error('Unknown action');
}
if(require.main===module)(async()=>{const action=process.argv[2];if(action!=='check')await core.stopped();const r=install(process.argv[3],action);console.log(JSON.stringify(r,null,2));if(action==='check'&&!r.installed)process.exitCode=1;})().catch(e=>{console.error('STOPPED: '+e.message);process.exitCode=1;});
module.exports={install,verify:core.verify,sha:core.sha};
