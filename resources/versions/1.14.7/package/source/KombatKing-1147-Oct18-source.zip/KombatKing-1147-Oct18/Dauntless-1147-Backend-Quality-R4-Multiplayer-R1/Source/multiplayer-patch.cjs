// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
function once(s,a,b){if(s.split(a).length!==2)throw Error('Multiplayer anchor differs: '+a.slice(0,100));return s.replace(a,b);}
const edits={
 'backend/recorder-1147.js':[
  ['let place = null;',`let place = null;
const multiplayer1147 = require('./multiplayer1147').create({root:ROOT,getState:()=>state,liveServer}); // KK-MULTIPLAYER-R4-R1
function maintainPlace(key) {
  place=multiplayer1147.recover(place);
  multiplayer1147.touch(key); multiplayer1147.prune(place);
  if(place&&!place.owners.size){multiplayer1147.retire(place.id);place=null;setWanted(null);}
}`],
  ['function leavePlace(key) {\n  if (!place) return;', 'function leavePlace(key) {\n  place=multiplayer1147.recover(place);\n  if (!place) return;'],
  ['if (!place.owners.size) { place = null; setWanted(null); }','if (!place.owners.size) { multiplayer1147.retire(place.id);place = null; setWanted(null); }'],
  ['    delete player.candidate;   // a fresh sign-in is never already in a match','    leavePlace(key);\n    delete player.candidate;   // a fresh sign-in releases its previous hunt lease'],
  ["req._pkey = keyFromIds(pathName, body);   // DF-LAN-1147: which player a server request is about",`req._pkey = keyFromIds(pathName, body);   // DF-LAN-1147: which player a server request is about
  if(!requestError){const token=bearerOf(req);const identified=req.qualityPlayerKey||(token&&sessions.get(token))||req._pkey;if(identified)multiplayer1147.touch(identified);}`],
  ["  const p = playerFor(c.req); const b = c.body || {};\n    const dest = destinationFor(b);", "  const p = playerFor(c.req); const b = c.body || {};\n    maintainPlace(keyFor(c.req));\n    const dest = destinationFor(b);"],
  ["    const p = playerFor(c.req);\n    // DF-PARTY-1147: a party member whose leader", "    const p = playerFor(c.req);\n    maintainPlace(keyFor(c.req));\n    // DF-PARTY-1147: a party member whose leader"],
  ["        dest.note = `another player is in ${place.label}: go there too, or wait for them to come back. Staying in Ramsgate`;\n        dest.city = true; delete dest.url;", "        return {status:409,json:{errorCode:'errors.com.dauntless.matchmaking.hunt_busy',errorMessage:`Another player is in ${place.label}. Join that hunt or wait until it is free.`,numericErrorCode:409},note:'multiplayer: occupied hunt retained; no silent city fallback'};"],
  ["      else if (follow && (!place || place.id !== follow.id)) {", "      else if (follow && (!place || place.id !== follow.id)) {\n        if(place&&[...place.owners].some(k=>k!==me))return{status:409,json:{errorCode:'errors.com.dauntless.matchmaking.hunt_busy',errorMessage:'Another hunt is occupied. Wait before following the party.',numericErrorCode:409},note:'multiplayer: occupied place protected from stale follow'};"],
  ["      const me = keyFor(c.req);\n      if (p.candidate && p.candidate.city === false)", "      const me = keyFor(c.req);\n      if(place&&place.id!==follow.id&&[...place.owners].some(k=>k!==me))return{status:409,json:{errorCode:'errors.com.dauntless.matchmaking.hunt_busy',errorMessage:'Another hunt is occupied. Wait before following the party.',numericErrorCode:409},note:'multiplayer: occupied place protected from stale follow'};\n      if (p.candidate && p.candidate.city === false)"],
  ["if (failed) { setWanted(null); place = null; }", "if(failed&&place&&place.id===cd.id){place.owners.delete(keyFor(c.req));if(!place.owners.size){multiplayer1147.retire(place.id);setWanted(null);place=null;}}"],
  ["${MAP_BY_GAME_TYPE[type]}?MaxPlayers=1", "${MAP_BY_GAME_TYPE[type]}?MaxPlayers=4"],
  ["function groupOf(acc) { const id = partyOfAcc.get(acc);",`let multiplayerPartiesLoaded=false;
function restoreMultiplayerParties(){
 if(multiplayerPartiesLoaded)return;multiplayerPartiesLoaded=true;
 for(const row of (Array.isArray(state.multiplayer1147Parties)?state.multiplayer1147Parties:[])){
  if(!row||typeof row.id!=='string'||!Array.isArray(row.members))continue;
  const members=[...new Set(row.members)].filter(a=>isAcc(a)&&playerOfAcc(a));
  if(members.length<2||members.length>PARTY_MAX||!members.includes(row.leader))continue;
  if(members.some(a=>partyOfAcc.has(a)))continue;
  const P={id:row.id,leader:row.leader,members,created:Date.now()};parties.set(P.id,P);
  for(const a of members){partyOfAcc.set(a,P.id);partySeen.set(a,Date.now());}
 }
}
function persistMultiplayerParties(){state.multiplayer1147Parties=[...parties.values()].map(p=>({id:p.id,leader:p.leader,members:[...p.members],created:p.created}));try{saveState();}catch(e){parties.clear();partyOfAcc.clear();multiplayerPartiesLoaded=false;restoreMultiplayerParties();throw e;}}
function availableMultiplayerCandidate(cd){
 if(!cd||cd.city!==false)return false;
 const srv=liveServer(HUNT_SERVER_FILE);
 return !!(srv&&srv.id===cd.id)||Date.now()-(cd.asked||0)<=5*60*1000;
}
function groupOf(acc) { restoreMultiplayerParties();const id = partyOfAcc.get(acc);`],
  ["function partySweep() {\n  const now = Date.now();", "function partySweep() {\n  restoreMultiplayerParties();\n  const now = Date.now();"],
  ["  partyLog(`${acc} left ${P.id.slice(0, 8)} (${why}); ${P.members.length} left, leader ${P.leader}`);", "  persistMultiplayerParties();\n  partyLog(`${acc} left ${P.id.slice(0, 8)} (${why}); ${P.members.length} left, leader ${P.leader}`);"],
  ["  partyLog(`${p.accountId} joined ${P.id.slice(0, 8)} (leader ${P.leader}); ${P.members.length} members`);", "  persistMultiplayerParties();\n  partyLog(`${p.accountId} joined ${P.id.slice(0, 8)} (leader ${P.leader}); ${P.members.length} members`);"],
  ["  P.leader = m; partyLog", "  P.leader = m; persistMultiplayerParties(); partyLog"],
  ["|| Date.now() - (cd.asked || 0) > PARTY_HUNT_FOLLOW_MS) return null;\n  const srv = liveServer(HUNT_SERVER_FILE);", "|| !availableMultiplayerCandidate(cd)) return null;\n  const srv = liveServer(HUNT_SERVER_FILE);"],
  ["|| Date.now() - (cd.asked || 0) > PARTY_HUNT_FOLLOW_MS) return null;\n  if (askedId", "|| !availableMultiplayerCandidate(cd)) return null;\n  if (askedId"],
  ["  const cd = p.candidate || null;\n  return { candidateId:", "  const cd = p.candidate || null;\n  const srv=cd?liveServer(cd.city===false?HUNT_SERVER_FILE:SERVER_FILE):null;\n  const ready=!!(srv&&(cd.city!==false||srv.id===cd.id));\n  return { candidateId:"],
  ["candidateState: cd ? (liveServer() ? 'IN_PROGRESS' : 'MATCHING') : null", "candidateState: cd ? (ready ? 'IN_PROGRESS' : 'MATCHING') : null"]
 ],
 'tools/df-gateway-1147.js':[
  ["    const up = net.connect(port + SHIFT, '127.0.0.1');", "    if(!Number.isInteger(port)||port<LO||port>HI||!Number.isInteger(port+SHIFT)||port+SHIFT<1||port+SHIFT>65535){client.destroy();return;}\n    let up;try{up=net.connect(port + SHIFT, '127.0.0.1');}catch{client.destroy();return;}"],
  ["    const port = Number(head.subarray(7, nl).toString('latin1').trim());\n    if (!(port >= LO && port <= HI))", "    const field=head.subarray(7,nl).toString('latin1').trim();\n    const port=/^[0-9]+$/.test(field)?Number(field):NaN;\n    if (!(Number.isInteger(port) && port >= LO && port <= HI))"]
 ],
 'tools/join-proxy-1147.js':[
  ["!(Number(PORT) > 0)", "!(/^[0-9]+$/.test(PORT||'') && Number.isInteger(Number(PORT)) && Number(PORT)>=1 && Number(PORT)<=65535)"]
 ],
 'tools/online-host-1147.ps1':[
  ["            if ($relay.HasExited) { Say 'The relay connection was lost:", "            if ($gateway.HasExited) { Say 'The backend gateway stopped: restarting Host Mode.' 'Yellow'; $relayLost = $true; break }\n            if ($relay.HasExited) { Say 'The relay connection was lost:"],
  ["        if ($relay.HasExited) { Say 'The relay connection program stopped.", "        if ($gateway.HasExited) { Say 'The backend gateway stopped. Close this game and start hosting again.' 'Yellow'; break }\n        if ($relay.HasExited) { Say 'The relay connection program stopped."]
 ],
 'tools/travel-1147.js':[
  ["const to = path.join(dir, `state_${stamp}_${tag}.json`);\n  fs.copyFileSync(stateFile, to);", "const to = path.join(dir, `state_${stamp}_${String(Date.now()).slice(-6)}_${crypto.randomBytes(5).toString('hex')}_${tag}.json`);\n  fs.copyFileSync(stateFile, to, fs.constants.COPYFILE_EXCL);"],
  ["if (!keep && process.env.TRAVEL_PENDING === '1' && hk && changedSinceSent(st.players[hk]))", "if (hk && changedSinceSent(st.players[hk]))"],
  ["      try { fs.unlinkSync(pendingFile); } catch (e) {}\n      process.exit(4);", "      if (!keep && process.env.TRAVEL_PENDING === '1') { try { fs.unlinkSync(pendingFile); } catch (e) {} }\n      process.exit(4);"],
  ["    const saved = keep ? '' : backup('before-home');", "    const latest=readState();const latestKey=homeKey(latest);\n    if(latestKey!==hk||fingerprint(latest.players[latestKey])!==fingerprint(mine)){console.log('Your local character changed during download. Both copies were kept; automatic saving is paused.');process.exit(4);}\n    const saved = keep ? '' : backup('before-home');"],
  ["    const tmp = stateFile + '.tmp';\n    fs.writeFileSync(tmp, JSON.stringify(st, null, 2)); fs.renameSync(tmp, stateFile);", "    const tmp = stateFile + '.tmp-'+crypto.randomUUID();\n    try{fs.writeFileSync(tmp, JSON.stringify(st, null, 2),{flag:'wx'});fs.renameSync(tmp,stateFile);}finally{try{fs.unlinkSync(tmp);}catch{}}"],
  ["const chunks = []; res.on('data', (c) => chunks.push(c));", "const chunks = [];let total=0;res.on('error',reject);res.on('data', (c) => {total+=c.length;if(total>8*1024*1024){req.destroy(new Error('Host character response exceeded 8 MiB'));return;}chunks.push(c);});"]
 ],
 'tools/lan-join-1147.ps1':[
  ["foreach ($c in Get-ServerCopies)", `# KK-MULTIPLAYER-R4-R1: unsupported fresh-character travel is refused before any host connection.
$joinCheck=Join-Path $PSScriptRoot 'multiplayer-join-check1147.js'
$joinNode=$cfg.Node;if(-not $joinNode -or -not(Test-Path -LiteralPath $joinNode)){$joinNode=Find-Node}
if(-not $joinNode){Fail 'Node is missing. Run Set up first.'}
$joinResult=& $joinNode $joinCheck $Root 2>&1
if($LASTEXITCODE -ne 0){Fail (($joinResult -join ' ')+ ' Start solo Play, finish character creation and the tutorial, then join again.')}
foreach ($c in Get-ServerCopies)`],
  ["        else { Say '  You play with the host''s copy of your character this time.' 'Yellow' }", "        else { Stop-Proxy; Fail 'Character upload failed or was refused. Your local save is preserved; retry before joining.' }"],
  ["        elseif ($c -eq 2) { Say '  (You play with a new character on the host.)' }", "        elseif ($c -eq 2) { Stop-Proxy; Fail 'Create and finish your character in solo Play before joining a friend.' }"],
  ["if ($c -eq 1) { Stop-Proxy; Fail 'could not bring your character home", "if ($c -eq 1 -or $c -eq 3) { Stop-Proxy; Fail 'could not bring your character home"],
  ["if ($LASTEXITCODE -eq 3) { break }", "if ($LASTEXITCODE -eq 3 -or $LASTEXITCODE -eq 4) { break }"]
 ]
};
function patch(rel,bytes){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');for(const[a,b]of edits[rel]||[])s=once(s,a,b);return Buffer.from(s.replaceAll('\n',nl));}
module.exports={edits,patch};
