// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=path.resolve(__dirname,'..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const names=['start.ps1','online-host-1147.ps1','lan-host-1147.ps1','background-startup1147.ps1','clear-startup-logs1147.cjs'];
function once(s,a,b){if(s.split(a).length!==2)throw Error('Background script anchor differs: '+a.slice(0,70));return s.replace(a,b);}
function patch(name,bytes){
 let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 s=once(s,". (Join-Path $PSScriptRoot 'common.ps1')",". (Join-Path $PSScriptRoot 'common.ps1')\n. (Join-Path $PSScriptRoot 'background-startup1147.ps1')\nInitialize-BackgroundLogs1147");
 if(name==='start.ps1'){
  s=once(s,"Say '1/3 Starting the local backend (a small minimized window)...'","Say '1/3 Starting the local backend in the background...'");
  s=once(s,"-WorkingDirectory $Root -WindowStyle Minimized -PassThru","-WorkingDirectory $Root -WindowStyle Hidden -PassThru `\n            -RedirectStandardOutput (Join-Path $Root 'logs\\recorder.out.log') -RedirectStandardError (Join-Path $Root 'logs\\recorder.err.log')");
  s=once(s,"$srvStyle = if ($NoGame) { 'Hidden' } else { 'Minimized' }", "$srvStyle = 'Hidden'");
  s=once(s,'-WindowStyle $srvStyle -PassThru','-WindowStyle $srvStyle -PassThru `\n    -RedirectStandardOutput (Join-Path $Root \'logs\\server-worker.out.log\') -RedirectStandardError (Join-Path $Root \'logs\\server-worker.err.log\')');
  s=once(s,'# --- 2. game server (hidden; its PowerShell window is minimized)','# --- 2. game server and its PowerShell worker are hidden');
 }else{
  if(name==='lan-host-1147.ps1')s=once(s,"-Verb RunAs -ArgumentList @('-NoProfile', '-NoExit',","-Verb RunAs -WindowStyle Hidden -ArgumentList @('-NoProfile',");
  s=once(s,"Say 'Starting PLAY in its own window (backend, game server, then your game)...'","Say 'Starting PLAY in the background (backend, game server, then your game)...'");
  s=once(s,"$play = Start-Process -FilePath 'powershell.exe' -PassThru -WorkingDirectory $Root `", "$play = Start-Process -FilePath 'powershell.exe' -PassThru -WindowStyle Hidden -WorkingDirectory $Root `\n            -RedirectStandardOutput (Join-Path $Root 'logs\\play.out.log') -RedirectStandardError (Join-Path $Root 'logs\\play.err.log') `");
  s=once(s,'    $play.WaitForExit()\n',"    $play.WaitForExit()\n    if ($play.ExitCode -ne 0) { Fail 'Background PLAY stopped. See logs\\play.out.log and logs\\play.err.log.' }\n");
 }
 return Buffer.from(s.replaceAll('\n',nl));
}
function safe(p){for(p=path.resolve(p);;p=path.dirname(p)){if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('Linked background paths are not supported: '+p);if(path.dirname(p)===p)break;}}
function write(p,b){safe(p);if(b===null){fs.rmSync(p,{force:true});return;}const t=p+'.background-'+crypto.randomUUID();try{fs.writeFileSync(t,b,{flag:'wx'});fs.renameSync(t,p);}finally{fs.rmSync(t,{force:true});}}
function inspect(root){
 root=fs.realpathSync(root);const dir=path.join(root,'backup/background1147-r1');safe(dir);
 const record=fs.existsSync(path.join(dir,'installation.json'))?JSON.parse(fs.readFileSync(path.join(dir,'installation.json'),'utf8')):null;
 if(fs.existsSync(path.join(dir,'pending.json')))throw Error('Interrupted background update; preserve '+dir);
 const before=names.map(n=>{const p=path.join(root,'tools',n);safe(p);return fs.existsSync(p)?fs.readFileSync(p):null;});
 return {root,dir,record,before};
}
function prepare(root,action='install'){
 const x=inspect(root),{record,before,dir}=x;
 if(record){
  if(record.root!==x.root||record.files.length!==names.length||record.files.some((f,i)=>f.name!==names[i]||!before[i]||sha(before[i])!==f.after))throw Error('Installed background scripts differ; no files changed');
  x.originals=record.files.map(f=>{if(f.before===null)return null;const p=path.join(dir,f.backup);safe(p);const b=fs.readFileSync(p);if(sha(b)!==f.before)throw Error('Background backup differs: '+f.name);return b;});
 }else{
  if(fs.existsSync(dir))throw Error('Unrecorded background backup found; preserve '+dir);
  if(action==='restore')throw Error('No background installation record');
  before.forEach((b,i)=>{
   if(i>=3){if(b)throw Error('Unrecorded background helper: '+names[i]);return;}
   const original=fs.readFileSync(path.join(base,'Source/Reference/tools',names[i]));
   if(!b||b.toString('utf8').replaceAll('\r\n','\n')!==original.toString('utf8').replaceAll('\r\n','\n'))throw Error('Unreviewed background script: tools/'+names[i]+'; no files changed');
  });
 }
 return x;
}
function install(root,action='install',options={}){
 if(action==='check'){try{const x=prepare(root);return {installed:!!x.record};}catch{return {installed:false};}}
 const x=prepare(root,action),{dir,before,record}=x;
 if(record&&action==='install')return {installed:true,already_installed:true};
 if(action==='restore'){
  write(path.join(dir,'pending.json'),Buffer.from('{"action":"restore"}'));
  try{x.originals.forEach((b,i)=>write(path.join(root,'tools',names[i]),b));options.afterWrite?.();fs.rmSync(path.join(dir,'pending.json'));fs.renameSync(dir,dir+'-restored-'+crypto.randomUUID());}
  catch(e){before.forEach((b,i)=>write(path.join(root,'tools',names[i]),b));fs.rmSync(path.join(dir,'pending.json'),{force:true});throw e;}
  return {restored:true};
 }
 const after=before.map((b,i)=>i<3?patch(names[i],b):fs.readFileSync(path.join(base,'Payload/tools',names[i]))),files=names.map((name,i)=>({name,before:before[i]?sha(before[i]):null,after:sha(after[i]),backup:i+'.original'}));
 fs.mkdirSync(dir,{recursive:true});
 try{
  before.forEach((b,i)=>{if(b)fs.writeFileSync(path.join(dir,i+'.original'),b,{flag:'wx'});});write(path.join(dir,'pending.json'),Buffer.from('{"action":"install"}'));
  after.forEach((b,i)=>write(path.join(root,'tools',names[i]),b));options.afterWrite?.();
  write(path.join(dir,'installation.json'),Buffer.from(JSON.stringify({root:x.root,files},null,2)));options.afterReceipt?.();
  if(after.some((b,i)=>!fs.readFileSync(path.join(root,'tools',names[i])).equals(b)))throw Error('Background script verification failed');fs.rmSync(path.join(dir,'pending.json'));
 }catch(e){before.forEach((b,i)=>write(path.join(root,'tools',names[i]),b));fs.rmSync(dir,{recursive:true,force:true});throw e;}
 return {installed:true};
}
module.exports={install,prepare,patch,names};
