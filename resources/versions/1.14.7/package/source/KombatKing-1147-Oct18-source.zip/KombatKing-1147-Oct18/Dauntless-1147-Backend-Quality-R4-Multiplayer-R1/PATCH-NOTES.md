# Backend Quality R4 + Multiplayer Fix R1

## R4 retained

- Validate malformed/oversized JSON, quantities, progress totals, account ownership, and saved inventory.
- Recover a damaged state before feature modules load; preserve immediate durable saves and backups.
- Avoid duplicate unchanged state writes, repeated Hunt Pass config construction, repeated season mirror writes, and full server-log rescans.
- Keep background Node/PowerShell workers hidden and clean old startup logs.
- Log unrecoverable process faults and exit instead of continuing unknown mutated state.

## Multiplayer changes

- Validate gateway/proxy ports as integers in range; catch gateway socket-construction exceptions.
- Monitor gateway failure alongside relay failure in the hosting script.
- Rebuild hunt occupancy after backend-only restart; prevent new map requests from replacing an occupied hunt.
- Release departed/relogged users and apply a 30-minute renewable backend-activity lease.
- Return explicit occupied-hunt errors instead of normal-looking city fallback.
- Scope failed-match cleanup to that candidate rather than clearing another player's hunt.
- Persist party membership/leadership with player state and recover it on restart.
- Keep live party hunts followable past the old 15-minute deadline.
- Resolve solo party status using the correct city/hunt marker and matching hunt ID.
- Emit MaxPlayers=4 for training.
- Guard every travel home write against newer local edits, including edits arriving during download.
- Pause periodic home saving on conflict; fail joining when upload or pending recovery is unsafe.
- Bound host travel response size to 8 MiB, use unique temporary paths, and give backups unique names.
- Check for a local saved character before connecting to a host.

Not included: native tutorial co-op, per-guest late-join quest-tag injection, multiple independent hunt servers, launcher ASAR admission reservations/readiness races, or the planned R5 trust/approval system. No claim that all multiplayer/security risks are solved.
