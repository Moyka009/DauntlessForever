# SPDX-License-Identifier: AGPL-3.0-only
# R4: read only appended bytes; no persistent file handles and no whole-log rescans.
$script:ServerLogReaders1147=@{}
function Reset-ServerLogReader1147([string]$Path) {
    $script:ServerLogReaders1147.Remove($Path)
}
function Read-NewServerLog1147([string]$Path) {
    $stream=$null
    try {
        if (-not (Test-Path -LiteralPath $Path)) { Reset-ServerLogReader1147 $Path; return }
        $info=Get-Item -LiteralPath $Path -ErrorAction Stop
        $entry=$script:ServerLogReaders1147[$Path]
        if (-not $entry -or $info.Length -lt $entry.Offset) {
            $entry=@{Offset=[long]0; Tail=''; Decoder=[Text.Encoding]::UTF8.GetDecoder()}
            $script:ServerLogReaders1147[$Path]=$entry
        }
        $stream=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
        $stream.Seek($entry.Offset,[IO.SeekOrigin]::Begin) | Out-Null
        $buffer=New-Object byte[] 262144
        $count=$stream.Read($buffer,0,$buffer.Length)
        if ($count -eq 0) { return }
        $entry.Offset += $count
        $chars=New-Object char[] ([Text.Encoding]::UTF8.GetMaxCharCount($count))
        $used=$entry.Decoder.GetChars($buffer,0,$count,$chars,0,$false)
        $text=$entry.Tail
        if ($used -gt 0) { $text += (-join $chars[0..($used-1)]) }
        $lines=$text -split "`n"
        $entry.Tail=$lines[-1]
        # Native logs normally flush newline-delimited messages. Bound malformed single-line memory.
        if ($entry.Tail.Length -gt 65536) { $entry.Tail=$entry.Tail.Substring($entry.Tail.Length-65536) }
        for ($i=0; $i -lt $lines.Count-1; $i++) { $lines[$i].TrimEnd([char]13) }
    } catch { return }
    finally { if ($stream) { $stream.Dispose() } }
}
