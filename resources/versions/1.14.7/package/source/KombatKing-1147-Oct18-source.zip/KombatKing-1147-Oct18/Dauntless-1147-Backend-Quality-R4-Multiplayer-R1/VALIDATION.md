# Validation scope

The multiplayer revision uses the same R4 foundation. Historical foundation evidence is retained under Validation/R4-RESULTS.*; the current multiplayer run has separate results. The new installer is Source/install-multiplayer-main.cjs; Source/install.cjs remains the original R4 foundation entry for its regression tests.

The multiplayer suite reruns real Node backend/travel/network tests on owned loopback fixtures. They use synthetic player state and fake alive-server markers, not Unreal clients or native servers. Fresh-profile prevention is a preflight guard, not proof the native tutorial works in co-op.

Known remaining audit case: MP05, per-player late-join quest binding. The suite must report it rather than silently pass it. MP22 is blocked by R4's existing session guard; TR07 is blocked by the new preflight.

Installer checks cover fresh installation, upgrade from existing R4, full and multiplayer-only restore, reinstall, failed install/restore rollback, altered output refusal, linked backup refusal, and preservation of saves/settings/Play script. Real PowerShell parses transformed scripts. Native Windows hosting, tutorial progression, WAN/UDP relay behavior and long-hunt lease behavior still need actual game testing.

The authoritative current command results and exact remaining cases are in Validation/MULTIPLAYER-RESULTS.json and Validation/MULTIPLAYER-RESULTS.txt after test completion.
