# Backend Quality R4 audit — 2026-10-18

## Scope and source

Official main was checked again for this request and remained commit `5a8fe6e4f334ea86904476a117a4785af4632e8f`, dated 2026-10-18 06:34:02 UTC. Current package: 2026-10-18.5; launcher 0.2.10. All 17 current backend files were checked against the pinned Git tree's blob hashes. Source/official-audit.json records exact file hashes. This does not identify which optional patches are currently installed on the user's Windows PC.

Sources: https://github.com/addison2k/DauntlessForever/tree/5a8fe6e4f334ea86904476a117a4785af4632e8f/resources/versions/1.14.7/package/backend and the earlier All-in-One component 01 / Backend Quality Fix2. Original current recorder and quality helper are bundled as source references.

## Confirmed and repaired

| Finding | Unpatched reproduction | Repair |
| --- | --- | --- |
| Broken JSON becomes an absent body | PUT /character with `{` returned 200 and created an unwanted character. | Parse failure returns 400 before dispatch. Character writes require an object. |
| Oversized request accepted in part | A valid inventory body followed by over 8 MiB of whitespace returned 200 and applied its prefix. | Reject the entire request with 413; no route runs. |
| Session/target mismatch | A session for player A targeting player B's inventory returned 200 and created B's character ID as an inventory key under A. | Check explicit path/body owners and the current session before account feature dispatch. |
| Expired sessions pick the last player | A nonmatching session header on /accountinfo returned the last signed-in player's account with 200. | Return 401 and require sign-in; no last-player fallback. Unauthenticated game-server calls must identify one owner when multiple saves exist. |
| Invalid numeric state | Objective value `1e309` returned 200; Infinity became null on disk. | Refuse non-finite JSON numbers, invalid progression values and internal non-finite save values. |
| Native integer overflow | An inventory quantity of 2,147,483,648 was accepted with 200. | Validate individual additions/removals and resulting stack totals against the native int32 maximum. |
| Save BOM inconsistency | Loader strips the BOM, while writer/backup recovery previously did not. A valid BOM-marked save could load but fail to save; a BOM backup could be refused. | Normalize the BOM consistently for parsing, retaining corrupt-file preservation and atomic backups. |
| Startup bypasses save recovery | With a damaged state.json and valid state.json.bak, the current backend exits in Hunt Pass initialization before quality.loadState runs. Reproduced in the actual backend process. | Load/recover state before constructing season modules; preserve damaged bytes, backup data and recovered_save status. |
| Malformed escape reported as server error | Feature dispatch mapped URIError to generic 500, unlike the normal route dispatcher. | Consistently map URIError to 400. |

The runtime tests also retain native inventory retry behavior, a save failure's 503 plus memory rollback, XP/objective writes, currency balances, explicit game-server identity, public profile queries, restarts and transfer receipts. No whole-save copy is added to every read; only request data and explicit owner IDs are checked.

## Already fixed in current official code

Atomic saves, previous-save recovery, inventory replay history, request-log rotation, save-write failure handling and managed startup/shutdown come from the earlier quality work and are already present. Current bounties already use the family merge and claim tombstones; R4 preserves that logic. The current official Hunt Pass presents a rolling 12-week window (within the requested 52-week maximum). R4 caches that same window's template; event/Trials schedules and native UI behavior are not replaced or extended to 2099.

The existing recovery helper worked in isolation, but the startup-order fault above prevented it running in that damaged-save case. The new real-process recovery test covers this distinction.

## R4 performance and fault-handling work

R4 adds a bounded committed-text save cache, immutable Hunt Pass configuration cache, unchanged season-display mirror suppression, scoped bounty rollback, and incremental native-log tailing. Actual changed saves remain immediate with the existing fsync/atomic rename/previous-save backup. Whole-state serialization and request-log writes still have a cost; this release does not claim to remove every synchronous operation.

Fixture measurements: 200 unchanged save calls read the main file once; 20 actual HTTP progression-config requests build one identical selected-pass template; 100 identical display mirrors do not rewrite; bounty rollback never accesses a getter representing a large unrelated inventory. UTF-8/partial-line/truncation and 100000-line log tests run under real Linux PowerShell. These are work-count/behavior results, not Windows FPS measurements.

Process-level uncaught exceptions/rejections now log through bounded rotation and exit nonzero. This avoids serving from unknown in-memory state. Existing Host Mode may restart the service; normal handled HTTP errors do not force exit. A fatal exit can disconnect players and solo play may require restarting, so this is a fail-safe policy, not a claim the underlying native crash is cured.

R4's module targets are checked before foundation writes. Exact-byte install/restore, direct R2/R3 upgrades, R4-only restore, known free-platinum/Radiant forms, both line endings, unknown edits, linked targets and injected install/restore failures are exercised in fixture tests. See Validation/R4-RESULTS.* for this release's authoritative run; older RESULTS.txt is historical R3 evidence.

## Earlier warnings and current limits

- **Currency widget warning:** a real current session and valid inventory returned the exact saved balance in HTTP tests. An expired session had a confirmed identity problem and now gets 401. This does not prove every earlier UCurrencyWidget warning has the same cause; timing, client caching and malformed existing balances remain separate possibilities.
- **Crafting-data warnings:** the earlier report named Bullseye, two potions, Bastion, Discipline and Iceborne. Those are native catalog/recipe or client-side lookups; this backend audit does not establish that adding a recipe would be correct. No fabricated crafting rows are installed.
- **BountySelectionWidget focus and notification warnings:** these involve native UI state. They are not repaired by hiding backend warnings or returning invented success objects. Existing final challenge helper is retained; no old timer/callback patch is reinstated.
- **Missing captures:** this source-only backend fixture has no downloaded captures. Bounty tuning therefore correctly returns 503, while the generated progression configuration remains available. A normal configured installation needs the capture files prepared by official setup. This patch does not replace missing game-wide data with empty success replies. Check.cmd reports whether a captures folder exists; it does not validate every capture file.
- Expected unsupported-service 404s, telemetry 404s and the intentionally empty survey 400 remain as implemented. They are not automatically evidence of a native crash.
- Native render-target pool pressure, missing texture/dye rows, unsupported network objects and weapon mesh/part warnings need separate native tracing if still present. No GPU, DLL, PAK or weapon metadata changes are made here.

The historical request log available during review spans 2026-10-17 04:25:52 to 2026-10-18 05:06:30 UTC. Observed Dauntless/progression/loadout calls either had no bearer header or one marked as a current session; this supports retaining explicit-owner game-server calls. It is older than this request and is not a fresh crash reproduction.

## Crash conclusion

The faults above are proven backend faults and can create invalid replies or saved data. A direct cause of the user's occasional EXCEPTION_ACCESS_VIOLATION is **not established**. No matching fresh crash context/dump, faulting instruction or Windows game run was available in this audit. These repairs reduce confirmed failure paths; they do not justify claiming that all crashes or all warnings are fixed.

If a crash recurs, correlate its timestamp with the existing request log, `logs\client_engine.log` when that recorder is installed, `logs\recorder-errors.log`, and the newest Archon crash context. Avoid publishing account keys or raw session tokens. No additional log recorder is bundled.
