# Backend Quality R4 + Multiplayer Fix R1 — 1.14.7

Close Dauntless, its servers/backend, and the launcher. Extract the ZIP and run **Install.cmd**. Then launch normally. Install this on the host and each guest so both the backend/network and travel-save fixes are present.

Includes the complete Backend Quality R4 foundation: immediate durable saves, recovery/validation, hidden workers, startup log cleanup, reduced duplicate save writes, Hunt Pass config caching, bounded server log reading, and the multiplayer fixes below.

**Check.cmd** verifies installation. **Restore-Multiplayer-Only.cmd** removes the multiplayer overlay while retaining R4. **Restore.cmd** returns code to the state before this bundle: if R4 was already installed, it keeps R4; if this bundle installed R4, it removes those newly added layers. Saves and settings are not restored or rewritten by the installer. Backups remain under the active package's backup folder.

Multiplayer changes:
- Reject malformed gateway port headers without killing other connections; reject invalid relay ports before starting the proxy.
- Detect a failed gateway during hosting. Host Mode uses its existing restart path; ordinary hosting displays a restart instruction.
- Recover occupied hunt ownership from live/wanted markers and saved candidates after a backend restart.
- Refresh participant activity from identified backend requests, release ownership on relogin/departure, and expire a silent owner's lease after 30 minutes.
- Retain an occupied hunt and return an explicit busy error rather than silently moving a competing requester to Ramsgate.
- Keep party membership across a backend restart and allow following a matching live hunt beyond 15 minutes.
- Make party and matchmaking readiness consult the same destination's server marker.
- Use four-player training map options.
- Stop periodic home saving on local conflicts; preserve newer local edits, bound host response size, use unique temporary files, and create noncolliding backups.
- Refuse brand-new/unsaved local profiles before connecting to a friend's unsupported tutorial path. Failed character upload or invalid pending recovery stops joining instead of silently using a host-side copy.

**Still solo-first:** this is a safe join guard, not a native multiplayer tutorial implementation. A saved character partway through the tutorial may still need to finish it in solo Play. No tutorial completion flags are fabricated.

**Known remaining work:** late guests can still lack their own quest binding in an already-running map; that needs native game-side work. The launcher ASAR admission races from the audit are not changed by this backend package. One secondary hunt per host remains the design. This is not the unfinished R5 account-approval/security system.

The original R4 files and known free-platinum/loadout variants remain supported. Unrecognized incompatible code or altered installed helpers is refused rather than overwritten. The startup-message patch edits play-1147.ps1, which this bundle does not replace.

The lease uses backend activity, not native connection inspection. Test long hunts and temporary network loss with actual clients before distributing broadly. No DLL, retail EXE, PAK, ASAR, save-transfer converter, or runtime NOTICE is installed.
