// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),B=require('./background.cjs');
const out=path.join(__dirname,'Built/tools');fs.mkdirSync(out,{recursive:true});
for(const name of B.names.slice(0,3))fs.writeFileSync(path.join(out,name),B.patch(name,fs.readFileSync(path.join(__dirname,'Reference/tools',name))));
console.log('Built three hidden-worker startup scripts.');
