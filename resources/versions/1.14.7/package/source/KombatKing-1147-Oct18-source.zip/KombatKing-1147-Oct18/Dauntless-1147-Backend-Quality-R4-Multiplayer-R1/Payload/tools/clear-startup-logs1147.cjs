// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path');
function noLinks(p){for(p=path.resolve(p);;p=path.dirname(p)){if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('Linked log paths are not cleaned: '+p);if(path.dirname(p)===p)break;}}
function clean(root,cutoff=Date.now()){
 noLinks(root);root=path.resolve(root);const result={deleted:0,skipped:0,failed:0};
 for(const dir of ['logs','upload']){
  const p=path.join(root,dir);noLinks(p);if(!fs.existsSync(p))continue;
  for(const name of fs.readdirSync(p)){
   const allowed=dir==='logs'?/\.(?:log|jsonl|err)(?:\.\d+)?$/i.test(name):/^(?:server_logs|client_logs|backend_logs|recorder_logs)(?:[-_ ().\dTZ]*)\.zip$/i.test(name);
   if(!allowed)continue;
   const f=path.join(p,name),s=fs.lstatSync(f);
   if(!s.isFile()||s.isSymbolicLink()||s.mtimeMs>=cutoff){result.skipped++;continue;}
   try{fs.unlinkSync(f);result.deleted++;}catch{result.failed++;}
  }
 }
 return result;
}
if(require.main===module){try{const root=process.argv[2];if(!root)throw Error('Package folder required');console.log(JSON.stringify(clean(root)));}catch(e){console.error('Log cleanup: '+e.message);process.exitCode=1;}}
module.exports={clean};
