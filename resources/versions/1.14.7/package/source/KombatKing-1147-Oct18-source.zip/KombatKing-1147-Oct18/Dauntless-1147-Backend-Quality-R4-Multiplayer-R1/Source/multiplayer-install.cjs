// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),vm=require('vm'),T=require('./multiplayer-patch.cjs');
const base=path.resolve(__dirname,'..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const helpers=['backend/multiplayer1147.js','tools/multiplayer-join-check1147.js'],names=[...Object.keys(T.edits),...helpers];
function safe(p){for(p=path.resolve(p);;p=path.dirname(p)){if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('Linked multiplayer path: '+p);if(path.dirname(p)===p)break;}}
const bytes=p=>fs.existsSync(p)?fs.readFileSync(p):null;
function write(p,b){safe(p);if(b===null){fs.rmSync(p,{force:true});return;}fs.mkdirSync(path.dirname(p),{recursive:true});const temp=p+'.mp-'+crypto.randomUUID();try{fs.writeFileSync(temp,b,{flag:'wx'});fs.renameSync(temp,p);}finally{fs.rmSync(temp,{force:true});}}
function inspect(root){safe(root);root=fs.realpathSync(root);const dir=path.join(root,'backup/backend-quality1147-r4-multiplayer');safe(dir);for(const n of names)safe(path.join(root,n));if(fs.existsSync(path.join(dir,'pending.json')))throw Error('Interrupted multiplayer install. Preserve '+dir);const file=path.join(dir,'installation.json');return{root,dir,record:fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):null,before:names.map(n=>bytes(path.join(root,n)))};}
function valid(x){return !!x.record&&x.record.root===x.root&&x.record.files.length===names.length&&x.record.files.every((r,i)=>r.rel===names[i]&&r.backup===i+'.original'&&x.before[i]&&sha(x.before[i])===r.after);}
function originals(x){return x.record.files.map(f=>{if(f.before===null)return null;const p=path.join(x.dir,f.backup);safe(p);const b=fs.readFileSync(p);if(sha(b)!==f.before)throw Error('Multiplayer backup changed: '+f.rel);return b;});}
function projectRecorder(b){if(!b.includes(Buffer.from('KK-BACKEND-QUALITY-R2')))b=require('./patch.cjs').patch(b);if(!b.includes(Buffer.from('KK-BACKEND-QUALITY-R4')))b=require('./performance-patch.cjs').patch('backend/recorder-1147.js',b);return b;}
function preflight(root){const x=inspect(root);if(x.record){if(!valid(x))throw Error('Installed multiplayer files changed; no files changed.');originals(x);return x;}if(fs.existsSync(x.dir)||x.before.slice(-2).some(Boolean))throw Error('Unrecorded multiplayer helper or backup; no files changed.');for(let i=0;i<names.length-helpers.length;i++){const rel=names[i];if(!x.before[i])throw Error('Missing multiplayer target: '+rel);const b=rel==='backend/recorder-1147.js'?projectRecorder(x.before[i]):x.before[i];const result=T.patch(rel,b);if(/\.(js|cjs)$/.test(rel))new vm.Script(result.toString('utf8'),{filename:rel});}return x;}
function install(root,action='install',options={}){
 const x=action==='install'?preflight(root):inspect(root);
 if(action==='check')return {installed:valid(x),record_present:!!x.record};
 if(x.record&&!valid(x))throw Error('Multiplayer files changed; no files changed.');
 if(action==='install'&&x.record)return {installed:true,already_installed:true,multiplayer:true};
 if(action==='restore'&&!x.record)throw Error('No multiplayer installation record.');
 const after=action==='restore'?originals(x):names.map((rel,i)=>T.edits[rel]?T.patch(rel,x.before[i]):fs.readFileSync(path.join(base,'Payload',rel)));
 if(action==='install')fs.mkdirSync(x.dir,{recursive:true});
 try{
  if(action==='install')x.before.forEach((b,i)=>{if(b)fs.writeFileSync(path.join(x.dir,i+'.original'),b,{flag:'wx'});});
  write(path.join(x.dir,'pending.json'),Buffer.from(JSON.stringify({action})));
  after.forEach((b,i)=>{write(path.join(x.root,names[i]),b);options.afterWrite?.(i);});
  if(after.some((b,i)=>b===null?fs.existsSync(path.join(x.root,names[i])):!fs.readFileSync(path.join(x.root,names[i])).equals(b)))throw Error('Multiplayer write verification failed.');
  if(action==='install')write(path.join(x.dir,'installation.json'),Buffer.from(JSON.stringify({root:x.root,files:names.map((rel,i)=>({rel,backup:i+'.original',before:x.before[i]?sha(x.before[i]):null,after:sha(after[i])}))},null,2)));
  fs.rmSync(path.join(x.dir,'pending.json'));
  if(action==='restore')fs.renameSync(x.dir,x.dir+'-restored-'+crypto.randomUUID());
 }catch(e){x.before.forEach((b,i)=>write(path.join(x.root,names[i]),b));if(action==='install')fs.rmSync(x.dir,{recursive:true,force:true});else fs.rmSync(path.join(x.dir,'pending.json'),{force:true});throw e;}
 return {installed:action==='install',restored:action==='restore',revision:4,multiplayer:true,saves_preserved:true};
}
function foundationValid(root){
 const x=inspect(root);if(!valid(x))return false;const old=originals(x),original=new Map(names.map((n,i)=>[n,old[i]]));
 if(!require('./backend-install.cjs').install(root,'check').installed)return false;
 for(const [receipt,kind]of [['backup/background1147-r1/installation.json','background'],['backup/backend-quality1147-r4/installation.json','performance']]){
  const r=JSON.parse(fs.readFileSync(path.join(root,receipt),'utf8'));if(r.root!==x.root)return false;
  for(const f of r.files){const rel=kind==='background'?'tools/'+f.name:f.rel;const b=original.has(rel)?original.get(rel):bytes(path.join(root,rel));if(!b||sha(b)!==f.after)return false;}
 }
 return true;
}
module.exports={install,preflight,inspect,valid,foundationValid,names,write,safe};
