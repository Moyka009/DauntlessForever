// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const edits={
 'backend/recorder-1147.js':[
  ["let runtime = null;","const performance1147 = require('./quality-performance1147'); // KK-BACKEND-QUALITY-R4\nconst performanceWriter1147 = performance1147.createWriter(quality);\nlet runtime = null;"],
  ['if (quality.saveState(STATE_FILE, state)) metrics.saves++;','if (performanceWriter1147.save(STATE_FILE, state)) metrics.saves++;'],
  ['fs.appendFileSync(crashLog,','quality.appendLog(crashLog,'],
  ["  process.on('uncaughtException', (e) => noteError('uncaught', e));\n  process.on('unhandledRejection', (e) => noteError('unhandled', e));","  // Unknown process-level faults cannot safely resume mutated in-memory state.\n  const fatal = (kind, error) => { noteError(kind, error); process.exit(1); };\n  process.on('uncaughtException', (e) => fatal('uncaught', e));\n  process.on('unhandledRejection', (e) => fatal('unhandled', e));"]
 ],
 'backend/huntpass1147.js':[
  ["const crypto=require('crypto'),baseData=require('./huntpass1147-data.json');","const crypto=require('crypto'),baseData=require('./huntpass1147-data.json');\nconst performance1147=require('./quality-performance1147'); // KK-BACKEND-QUALITY-R4"],
  ['config=()=>pathConfig(data),grants=', 'config=performance1147.cachedConfig(()=>pathConfig(data),()=>passWindow(data).start),grants=']
 ],
 'backend/bounties1147.js':[
  ["const clone=x=>JSON.parse(JSON.stringify(x));","const performance1147=require('./quality-performance1147'); // KK-BACKEND-QUALITY-R4\nconst clone=x=>JSON.parse(JSON.stringify(x));"],
  ['function atomic(p,fn){const before=clone(p);try{return fn();}catch(e){for(const k of Object.keys(p))delete p[k];Object.assign(p,before);throw e;}}','function atomic(p,fn){return performance1147.bountyTransaction(p,fn);}']
 ],
 'backend/huntpass-seasons1147.js':[
  ["const choice=path.join(root,'data/season.txt');","let mirrorText;\n const choice=path.join(root,'data/season.txt');"],
  ["try{fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(file+'.tmp',JSON.stringify({passes}));fs.renameSync(file+'.tmp',file);}","try{const text=JSON.stringify({passes});if(text===mirrorText&&fs.existsSync(file))return;fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(file+'.tmp',text);fs.renameSync(file+'.tmp',file);mirrorText=text;}"]
 ],
 'tools/server-1147.ps1':[
  ['. (Join-Path $PSScriptRoot "common.ps1")','. (Join-Path $PSScriptRoot "common.ps1")\n. (Join-Path $PSScriptRoot "server-log-reader1147.ps1")'],
  ['    if (Test-Path -LiteralPath $huntLog) { Remove-Item -LiteralPath $huntLog -Force -ErrorAction SilentlyContinue }','    Reset-ServerLogReader1147 $huntLog\n    if (Test-Path -LiteralPath $huntLog) { Remove-Item -LiteralPath $huntLog -Force -ErrorAction SilentlyContinue }'],
  ['    $ll = @(Read-Shared $huntLog | Where-Object { $_ })','    $ll = @(Read-NewServerLog1147 $huntLog | Where-Object { $_ })'],
  ['    for ($i = $h.Shown; $i -lt $ll.Count; $i++) { Write-Host ("  [2nd] " + $ll[$i]) -ForegroundColor DarkCyan }\n    if ($ll.Count -gt $h.Shown) { $h.Shown = $ll.Count }','    foreach ($line in $ll) { Write-Host ("  [2nd] " + $line) -ForegroundColor DarkCyan }'],
  ['    $lines = @(Read-Shared $srvLog)','    $lines = @(Read-NewServerLog1147 $srvLog)'],
  ['    for ($i = $shown; $i -lt $lines.Count; $i++) { if ($lines[$i]) { Write-Host "  $($lines[$i])" } }\n    if ($lines.Count -gt $shown) { $shown = $lines.Count }','    foreach ($line in $lines) { if ($line) { Write-Host "  $line" } }']
 ]
};
function transform(rel,bytes,reverse=false){let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');for(let[a,b]of reverse?[...edits[rel]].reverse():edits[rel]){if(reverse)[a,b]=[b,a];if(s.split(a).length!==2)throw Error('R4 reviewed anchor differs: '+rel+' '+a.slice(0,60));s=s.replace(a,b);}return Buffer.from(s.replaceAll('\n',nl));}
module.exports={edits,patch:(r,b)=>transform(r,b),unpatch:(r,b)=>transform(r,b,true)};
