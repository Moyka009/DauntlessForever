# SPDX-License-Identifier: AGPL-3.0-only
"""Verify source syntax, regenerate integrity data and create the deliverable ZIP."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[1]
subprocess.run(['node',str(root/'Source/build-background.cjs')],check=True)
subprocess.run(['node',str(root/'Source/build-performance.cjs')],check=True)
subprocess.run(['node',str(root/'Source/build-multiplayer.cjs')],check=True)
def files():
    return sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
for p in [root/'Run.ps1',*root.glob('*.cmd')]:
    p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))
for p in files():
    if p.suffix in ['.js','.cjs']:subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
    if p.suffix=='.json':json.loads(p.read_text())
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files() if p.name!='INTEGRITY.json'}
(root/'INTEGRITY.json').write_text(json.dumps(manifest,indent=2)+'\n')
out=root.with_suffix('.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files():z.write(p,str(Path(root.name)/p.relative_to(root)))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('PASS JavaScript syntax, JSON parse, integrity manifest and ZIP CRC')
print(out, out.stat().st_size, hashlib.sha256(out.read_bytes()).hexdigest())
