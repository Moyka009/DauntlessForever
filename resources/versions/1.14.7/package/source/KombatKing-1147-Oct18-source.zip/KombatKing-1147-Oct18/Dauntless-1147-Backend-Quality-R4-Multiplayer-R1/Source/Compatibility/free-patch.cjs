// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const loadouts=require('./patch.cjs');
const requireLine="const freePlatinum1147 = require('./free-platinum1147'); // KK-FREE-PLATINUM-1147-R1";
const bodyLine='  body = freePlatinum1147.inventory(body);';
const replyLine="  if (svc.service === 'store' && reply.json !== undefined) reply = freePlatinum1147.reply(reply);";
function once(s,a,b){if(s.split(a).length!==2)throw Error('Free-platinum reviewed anchor differs: '+a.slice(0,80));return s.replace(a,b);}
function patch(bytes){
 if(!bytes.toString().includes(loadouts.marker))bytes=loadouts.patch(bytes);
 let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 s=once(s,"const quality = require('./quality');","const quality = require('./quality');\n"+requireLine);
 s=once(s,'function applyInventory(inv, body) {','function applyInventory(inv, body) {\n'+bodyLine);
 s=once(s,"  let payload = '';",replyLine+"\n  let payload = '';");
 return Buffer.from(s.replaceAll('\n',nl));
}
function unpatch(bytes,removeLoadouts){
 let s=bytes.toString('utf8'),nl=s.includes(requireLine+'\r\n')?'\r\n':'\n';
 for(const line of [requireLine,bodyLine,replyLine])s=once(s,line+nl,'');
 const out=Buffer.from(s);return removeLoadouts?loadouts.unpatch(out):out;
}
function huntpass(bytes){
 let s=bytes.toString('utf8');
 s=once(s,'price:150*ranks,salesPrice:150*ranks','price:0,salesPrice:0');
 s=once(s,"if(balance(p)<o.prices[0].price)throw error('Not enough platinum');",'');
 s=once(s,"const cost=t.ranks*150;if(balance(p)<cost)throw error('Not enough platinum');",'');
 s=once(s,"const inv=ctx.inventoryOf(p,t.character),plat=inv.stackedItems.find(i=>i.catalogId==='CURRENCY_PLATINUM');plat.quantity-=cost;",'ctx.inventoryOf(p,t.character);');
 return Buffer.from(s);
}
module.exports={patch,unpatch,huntpass,requireLine};
