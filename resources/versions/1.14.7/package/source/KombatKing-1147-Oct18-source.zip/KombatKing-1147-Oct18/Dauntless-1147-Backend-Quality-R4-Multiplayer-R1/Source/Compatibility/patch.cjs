// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const marker='// KK-LOADOUTS-1147-R1';
const hook="const loadoutsFix1147 = require('./loadouts-fix1147').create({root:ROOT,getPlayers:()=>Object.values(state.players||{}),playerFor,bearerOf,sessions,saveState,defaultLoadoutSlot,defaultPersistent});";
function patch(bytes){
 let s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';s=s.replaceAll('\r\n','\n');
 if(s.includes(marker))throw Error('Loadout fix hook is already present');
 const anchor='function handle(svc, port, req, res, bodyBuf) {';
 if(s.split(anchor).length!==2)throw Error('Reviewed backend handle anchor differs');
 s=s.replace(anchor,marker+'\n'+hook+'\n'+anchor);
 const re=/try \{ reply = ((?:modes1147|radiant1147)\.handle\(\{service:svc\.service,method:req\.method,path:pathName,req,body,url\}\)); known=!!reply; \}/g;
 const matches=[...s.matchAll(re)];if(matches.length!==1)throw Error('Reviewed official/Radiant feature route differs');
 s=s.replace(re,"try { reply = loadoutsFix1147.handle({service:svc.service,method:req.method,path:pathName,req,body,url}) || $1; known=!!reply; }");
 return Buffer.from(s.replaceAll('\n',nl));
}
function unpatch(bytes){let s=bytes.toString('utf8'),nl=s.includes(marker+'\r\n')?'\r\n':'\n';
 const block=marker+nl+hook+nl;if(s.split(block).length!==2)throw Error('Installed loadout hook differs');s=s.replace(block,'');
 const insert='loadoutsFix1147.handle({service:svc.service,method:req.method,path:pathName,req,body,url}) || ';
 if(s.split(insert).length!==2)throw Error('Installed loadout dispatch differs');s=s.replace(insert,'');return Buffer.from(s);}
module.exports={patch,unpatch,marker};
