// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const core=require('./backend-install.cjs'),background=require('./background.cjs');
function install(root,action='install',options={}){
 core.verify();
 const oldCore=core.install(root,'check'),oldBackground=background.install(root,'check');
 if(action==='check')return {...oldCore,installed:oldCore.installed&&oldBackground.installed,revision:3,background_workers_hidden:oldBackground.installed};
 if(action==='install'){
  background.prepare(root);
  const result=core.install(root,'install',options);
  try{const b=background.install(root,'install',options.background);return {...result,revision:3,background_workers_hidden:true,already_installed:!!result.already_installed&&!!b.already_installed};}
  catch(e){if(!oldCore.installed)core.install(root,'restore');throw e;}
 }
 if(action==='restore'){
  if(!oldCore.installed||!oldBackground.installed)throw Error('Installed quality/background files differ or are missing; no files changed');
  background.prepare(root,'restore');
  background.install(root,'restore',options.background);
  try{return {...core.install(root,'restore'),revision:3,background_scripts_restored:true};}
  catch(e){background.install(root,'install');throw e;}
 }
 throw Error('Unknown action');
}
if(require.main===module)(async()=>{const action=process.argv[2];if(action!=='check')await core.stopped();const r=install(process.argv[3],action);console.log(JSON.stringify(r,null,2));if(action==='check'&&!r.installed)process.exitCode=1;})().catch(e=>{console.error('STOPPED: '+e.message);process.exitCode=1;});
module.exports={install,verify:core.verify,sha:core.sha};
