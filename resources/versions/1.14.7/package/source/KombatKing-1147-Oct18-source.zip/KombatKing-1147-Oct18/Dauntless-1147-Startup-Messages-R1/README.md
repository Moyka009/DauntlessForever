# Startup messages fix — 1.14.7

Close Dauntless and stop its local server, then double-click **Install.cmd**. Launch 1.14.7 normally afterward. You no longer need Test-Fix.cmd or Trace.cmd.

**Check.cmd** checks installation. **Restore.cmd** removes only this fix and preserves other edits in the Play script. Saves and settings are untouched.

Uses the same DLL confirmed working in the user's R2 test: the offline IGameClient error is hidden and the welcome screen is skipped using the normal game check. The helper now loads automatically through tools/play-1147.ps1. No extra background worker or test window is added.

The installer detects the active package, verifies the exact 1.14.7 executable, and saves its receipt and backup in **backup/startup-messages1147-r1**. It adds four files under tools/startup-messages1147 and two marked blocks in tools/play-1147.ps1. No launcher ASAR, backend, retail EXE, dxgi.dll, or PAK is replaced.

This covers normal Play and launch/join modes that use play-1147.ps1. Starting the retail EXE directly bypasses the fix. A launcher package update or repair may replace the Play script; Check.cmd detects that, and the patch may need updating or reinstalling.

Only the newest two earlier helper logs are retained at each startup. No runtime NOTICE file is installed. Source, patch notes, and AGPL-3.0 license are included.

The DLL behavior is user-confirmed. Automatic integration has been checked with installation/restore fixtures and real PowerShell/C# compilation on Linux; the final Windows launcher integration still needs its first run.
