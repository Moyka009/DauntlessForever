#pragma once
// SPDX-License-Identifier: AGPL-3.0-only
#include <bcrypt.h>
#include <string.h>
static bool hashExe(){
 wchar_t path[32768];if(!GetModuleFileNameW(0,path,32768))return false;
 BCRYPT_ALG_HANDLE algorithm=0;BCRYPT_HASH_HANDLE hash=0;DWORD sz=0,n=0;bool ok=false;
 HANDLE f=INVALID_HANDLE_VALUE;PUCHAR object=0;unsigned char digest[32],buffer[65536];
 const unsigned char expected[]={0xf3,0xf9,0x5f,0xbf,0x22,0x70,0x9e,0xf0,0x77,0xa1,0x16,0x32,0xed,0x95,0xd6,0x75,0xb7,0x20,0x9b,0x7e,0x01,0x72,0xd9,0xec,0xb9,0xba,0x7d,0x02,0xa1,0xfb,0xb6,0x6b};
 do{
  if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,0,0)<0)break;
  if(BCryptGetProperty(algorithm,BCRYPT_OBJECT_LENGTH,(PUCHAR)&sz,sizeof(sz),&n,0)<0)break;
  object=(PUCHAR)HeapAlloc(GetProcessHeap(),0,sz);if(!object)break;
  if(BCryptCreateHash(algorithm,&hash,object,sz,0,0,0)<0)break;
  f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0);if(f==INVALID_HANDLE_VALUE)break;
  bool valid=true;
  while(true){if(!ReadFile(f,buffer,sizeof(buffer),&n,0)){valid=false;break;}if(!n)break;if(BCryptHashData(hash,buffer,n,0)<0){valid=false;break;}}
  if(valid&&BCryptFinishHash(hash,digest,32,0)>=0)ok=memcmp(digest,expected,32)==0;
 }while(false);
 if(f!=INVALID_HANDLE_VALUE)CloseHandle(f);if(hash)BCryptDestroyHash(hash);if(object)HeapFree(GetProcessHeap(),0,object);if(algorithm)BCryptCloseAlgorithmProvider(algorithm,0);
 return ok;
}
