# SPDX-License-Identifier: AGPL-3.0-only
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
foreach($file in @((Join-Path $root 'Run.ps1'),(Join-Path $root 'Payload\Startup.ps1'),$PSCommandPath)){
 $tokens=$null;$issues=$null
 [void][Management.Automation.Language.Parser]::ParseFile($file,[ref]$tokens,[ref]$issues)
 if($issues.Count){throw ($issues|Out-String)}
}
Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $root 'Payload\Attach.cs') -Raw)
Write-Output 'PASS all PowerShell scripts parse and actual C# loader compiles'
# Verify that dot-sourced functions resolve their own payload folder.
. (Join-Path $root 'Payload\Startup.ps1')
$script:StartupMessages1147Ready=$false
Start-StartupMessages1147 -PlayerId 1 -Executable 'unused'
Write-Output 'PASS skipped initialization leaves game launch untouched'
