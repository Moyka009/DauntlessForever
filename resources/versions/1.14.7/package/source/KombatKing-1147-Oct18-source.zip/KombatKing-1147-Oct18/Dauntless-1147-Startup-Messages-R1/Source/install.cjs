// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=path.resolve(__dirname,'..'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const expected='f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b';
const rels=['tools/play-1147.ps1','tools/startup-messages1147/Startup.ps1','tools/startup-messages1147/Attach.cs','tools/startup-messages1147/StartupMessages1147.dll','tools/startup-messages1147/payload.json'];
const begin='# BEGIN startup-messages1147-r1',end='# END startup-messages1147-r1';
const prepare=`${begin} prepare\n. (Join-Path $PSScriptRoot 'startup-messages1147\\Startup.ps1')\nInitialize-StartupMessages1147 -Executable $Exe\n${end} prepare\n`;
const attach=`${begin} attach\nStart-StartupMessages1147 -PlayerId $p.Id -Executable $Exe\n${end} attach\n`;
function safe(p){for(p=path.resolve(p);;p=path.dirname(p)){if(fs.existsSync(p)&&fs.lstatSync(p).isSymbolicLink())throw Error('Linked paths are not supported: '+p);if(path.dirname(p)===p)break;}}
function write(p,b){safe(p);if(b===null){fs.rmSync(p,{force:true});return;}fs.mkdirSync(path.dirname(p),{recursive:true});const t=p+'.startup-'+crypto.randomUUID();try{fs.writeFileSync(t,b,{flag:'wx'});fs.renameSync(t,p);}finally{fs.rmSync(t,{force:true});}}
function patch(bytes,remove=false){
 const s=bytes.toString('utf8'),nl=s.includes('\r\n')?'\r\n':'\n';let text=s.replaceAll('\r\n','\n');
 if(remove){for(const block of [prepare,attach]){if(text.split(block).length!==2)throw Error('Installed startup block changed; no files changed.');text=text.replace(block,'');}}
 else{
  if(text.includes(begin)||text.includes(end))throw Error('Unrecorded startup fix or partial installation; no files changed.');
  if(!text.includes('$psi.UseShellExecute = $false')||!text.includes('$psi.FileName = $Exe'))throw Error('Unsupported player launch script; no files changed.');
  const before='$startTime = Get-Date',start='$p = [Diagnostics.Process]::Start($psi)';
  if(text.split(before).length!==2||text.split(start).length!==2)throw Error('Player launch anchors differ; no files changed.');
  text=text.replace(before,prepare+before).replace(start,start+'\n'+attach.trimEnd());
 }
 return Buffer.from(text.replaceAll('\n',nl));
}
function operation(action,root,options={}){
 if(!['install','check','restore'].includes(action))throw Error('Unknown action.');
 safe(root);root=fs.realpathSync(root);const backup=path.join(root,'backup/startup-messages1147-r1');safe(backup);
 if(!fs.existsSync(path.join(root,'services_1147.json')))throw Error('Not an active 1.14.7 package.');
 const config=JSON.parse(fs.readFileSync(path.join(root,'config.json'),'utf8').replace(/^\uFEFF/,''));
 const exe=path.join(config.GameDir,'Archon/Binaries/Win64/Dauntless-Win64-Shipping.exe');safe(exe);
 if(action!=='restore'&&hash(fs.readFileSync(exe))!==expected)throw Error('Wrong game executable; no files changed.');
 const before=rels.map(r=>{const p=path.join(root,r);safe(p);return fs.existsSync(p)?fs.readFileSync(p):null;});
 const receiptPath=path.join(backup,'installation.json');
 if(fs.existsSync(path.join(backup,'pending.json')))throw Error('Interrupted startup patch. Preserve backup/startup-messages1147-r1 and request recovery.');
 const record=fs.existsSync(receiptPath)?JSON.parse(fs.readFileSync(receiptPath,'utf8')):null;
 if(record){
  if(record.root!==root||record.files.length!==rels.length||record.files.some((r,i)=>r.name!==rels[i]))throw Error('Installation receipt differs.');
  // Helpers must be unchanged. Other edits in the play script may remain.
  before.slice(1).forEach((b,j)=>{if(!b||hash(b)!==record.files[j+1].after)throw Error('Installed helper was edited: '+rels[j+1]+'; no files changed.');});
  patch(before[0],true);
  if(action==='check'||action==='install')return {installed:true,already_installed:action==='install',game:config.GameDir,saves_preserved:true};
  const originals=record.files.map((r,i)=>{if(r.before===null)return null;const p=path.join(backup,i+'.original');safe(p);const b=fs.readFileSync(p);if(hash(b)!==r.before)throw Error('Backup verification failed: '+r.name);return b;});
  const after=[patch(before[0],true),...originals.slice(1)];
  write(path.join(backup,'pending.json'),Buffer.from('{"action":"restore"}'));
  try{after.forEach((b,i)=>{write(path.join(root,rels[i]),b);options.afterWrite?.(i);});if(after.some((b,i)=>b===null?fs.existsSync(path.join(root,rels[i])):!fs.readFileSync(path.join(root,rels[i])).equals(b)))throw Error('Restore verification failed.');fs.rmSync(path.join(backup,'pending.json'));fs.renameSync(backup,backup+'-restored-'+crypto.randomUUID());}
  catch(e){before.forEach((b,i)=>write(path.join(root,rels[i]),b));fs.rmSync(path.join(backup,'pending.json'),{force:true});throw e;}
  return {restored:true,saves_preserved:true,other_play_script_edits_preserved:true};
 }
 if(action==='check')return {installed:false};
 if(action==='restore')throw Error('No startup installation receipt; no files changed.');
 if(fs.existsSync(backup)||before.slice(1).some(Boolean))throw Error('Unrecorded startup files or backup found; no files changed.');
 const script=patch(before[0]);
 const payload=['Startup.ps1','Attach.cs','StartupMessages1147.dll'].map(n=>fs.readFileSync(path.join(base,'Payload',n)));
 const manifest=JSON.parse(fs.readFileSync(path.join(base,'SHA256.json'),'utf8'));
 for(let i=0;i<payload.length;i++)if(hash(payload[i])!==manifest['Payload/'+['Startup.ps1','Attach.cs','StartupMessages1147.dll'][i]])throw Error('Payload integrity check failed.');
 const spec=Buffer.from(JSON.stringify({exe:expected,files:{'Attach.cs':hash(payload[1]),'StartupMessages1147.dll':hash(payload[2])}},null,2));
 const after=[script,...payload,spec];
 fs.mkdirSync(backup,{recursive:true});
 try{
  before.forEach((b,i)=>{if(b)fs.writeFileSync(path.join(backup,i+'.original'),b,{flag:'wx'});});
  write(path.join(backup,'pending.json'),Buffer.from('{"action":"install"}'));
  after.forEach((b,i)=>{write(path.join(root,rels[i]),b);options.afterWrite?.(i);});
  if(after.some((b,i)=>!fs.readFileSync(path.join(root,rels[i])).equals(b)))throw Error('Installation verification failed.');
  write(receiptPath,Buffer.from(JSON.stringify({root,files:rels.map((name,i)=>({name,before:before[i]?hash(before[i]):null,after:hash(after[i])}))},null,2)));
  fs.rmSync(path.join(backup,'pending.json'));
 }catch(e){before.forEach((b,i)=>write(path.join(root,rels[i]),b));fs.rmSync(backup,{recursive:true,force:true});throw e;}
 return {installed:true,game:config.GameDir,automatic_on_play:true,saves_preserved:true,backup};
}
module.exports={operation,patch,rels};
if(require.main===module){try{console.log(JSON.stringify(operation(process.argv[2],process.argv[3]),null,2));}catch(e){console.error('STOPPED: '+e.message);process.exitCode=1;}}
