# SPDX-License-Identifier: AGPL-3.0-only
# Dot-sourced by tools/play-1147.ps1 before the player game starts.
function Initialize-StartupMessages1147 {
 param([string]$Executable)
 $script:StartupMessages1147Ready=$false
 try {
  $spec=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'payload.json') -Raw | ConvertFrom-Json
  if((Get-FileHash -LiteralPath $Executable -Algorithm SHA256).Hash -ne $spec.exe){throw 'Unsupported game executable.'}
  foreach($name in @('StartupMessages1147.dll','Attach.cs')){
   if((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $name) -Algorithm SHA256).Hash -ne $spec.files.PSObject.Properties[$name].Value){throw "Startup helper changed: $name"}
  }
  if(-not ('StartupTraceAttach1147' -as [type])){Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Attach.cs') -Raw)}
  # Keep the two newest logs from earlier player sessions; only this helper's logs are eligible.
  @(Get-ChildItem -LiteralPath $PSScriptRoot -Filter 'startup-fix1147-*.log' -File | Sort-Object LastWriteTime -Descending | Select-Object -Skip 2) | ForEach-Object {Remove-Item -LiteralPath $_.FullName -ErrorAction SilentlyContinue}
  $script:StartupMessages1147Ready=$true
 }catch{Write-Warning "Startup message fix was skipped: $($_.Exception.Message)"}
}
function Start-StartupMessages1147 {
 param([int]$PlayerId,[string]$Executable)
 if(-not $script:StartupMessages1147Ready){return}
 try {
  $log=Join-Path $PSScriptRoot "startup-fix1147-$PlayerId.log"
  if(Test-Path -LiteralPath $log){Remove-Item -LiteralPath $log}
  [StartupTraceAttach1147]::Load($PlayerId,$Executable,(Join-Path $PSScriptRoot 'StartupMessages1147.dll'))
  for($attempt=0;$attempt -lt 100;$attempt++){
   if(Test-Path -LiteralPath $log){
    $text=Get-Content -LiteralPath $log -Raw
    if($text -match '(REFUSED:|ERROR:)'){throw "Native helper refused initialization. See $log"}
    if($text -match 'FIX_READY:'){return}
   }
   Start-Sleep -Milliseconds 100
  }
  throw "Native helper did not report ready. See $log"
 }catch{Write-Warning "Startup message fix did not load: $($_.Exception.Message). The game may still show its original messages."}
}
