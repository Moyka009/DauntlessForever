# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import hashlib, json, zipfile
root = Path(__file__).resolve().parents[1]
files = sorted(p for p in root.rglob('*') if p.is_file() and p.name != 'SHA256.json' and p.suffix not in {'.lib', '.pdb', '.a', '.o', '.obj', '.log'} and '__pycache__' not in p.parts)
hashes = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root / 'SHA256.json').write_text(json.dumps(hashes, indent=2) + '\n')
destination = root.with_suffix('.zip')
with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files + [root / 'SHA256.json']):
        info = zipfile.ZipInfo((Path(root.name) / path.relative_to(root)).as_posix(), (2026, 10, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes())
print(json.dumps({'zip': str(destination), 'bytes': destination.stat().st_size, 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'files': len(files) + 1}, indent=2))
