// SPDX-License-Identifier: AGPL-3.0-only
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
public static class StartupTraceAttach1147 {
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr VirtualAllocEx(IntPtr h,IntPtr address,UIntPtr size,uint type,uint protection);
 [DllImport("kernel32.dll")] static extern bool VirtualFreeEx(IntPtr h,IntPtr address,UIntPtr size,uint type);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool WriteProcessMemory(IntPtr h,IntPtr address,byte[] data,UIntPtr size,out UIntPtr written);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr CreateRemoteThread(IntPtr h,IntPtr attributes,UIntPtr stack,IntPtr start,IntPtr param,uint flags,IntPtr id);
 [DllImport("kernel32.dll")] static extern uint WaitForSingleObject(IntPtr h,uint timeout);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] static extern IntPtr GetModuleHandle(string name);
 [DllImport("kernel32.dll",CharSet=CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr h,string name);
 static IntPtr Loader(Process remote){
  IntPtr local=GetProcAddress(GetModuleHandle("kernel32.dll"),"LoadLibraryW");
  using(Process self=Process.GetCurrentProcess())foreach(ProcessModule module in self.Modules){
   long offset=local.ToInt64()-module.BaseAddress.ToInt64();if(offset<0||offset>=module.ModuleMemorySize)continue;
   foreach(ProcessModule other in remote.Modules)if(String.Equals(other.ModuleName,module.ModuleName,StringComparison.OrdinalIgnoreCase))return new IntPtr(other.BaseAddress.ToInt64()+offset);
  }
  return IntPtr.Zero;
 }
 public static void Load(int processId,string exe,string dll){
  if(!Environment.Is64BitProcess)throw new Exception("Run with 64-bit Windows PowerShell.");
  using(Process process=Process.GetProcessById(processId)){
   ProcessModule main=null;IntPtr loader=IntPtr.Zero;
   for(int attempt=0;attempt<250;attempt++){
    if(process.HasExited)throw new Exception("Player game exited before helper loading.");
    try{process.Refresh();main=process.MainModule;loader=Loader(process);if(main!=null&&loader!=IntPtr.Zero)break;}catch(System.ComponentModel.Win32Exception){}catch(InvalidOperationException){}
    Thread.Sleep(20);
   }
   if(main==null||loader==IntPtr.Zero)throw new Exception("Player process initialization did not finish.");
   if(!String.Equals(Path.GetFullPath(main.FileName),Path.GetFullPath(exe),StringComparison.OrdinalIgnoreCase))throw new Exception("Game path changed; trace stopped.");
   foreach(ProcessModule m in process.Modules)if(String.Equals(Path.GetFullPath(m.FileName),Path.GetFullPath(dll),StringComparison.OrdinalIgnoreCase))throw new Exception("Trace is already loaded. Close the game before recording again.");
   IntPtr h=OpenProcess(0x43a,false,processId);if(h==IntPtr.Zero)throw new Exception("Cannot open the game. Run the trace at the same permission level as the launcher.");
   IntPtr memory=IntPtr.Zero,thread=IntPtr.Zero;bool finished=false;
   try{
    byte[] bytes=Encoding.Unicode.GetBytes(Path.GetFullPath(dll)+"\0");
    memory=VirtualAllocEx(h,IntPtr.Zero,new UIntPtr((uint)bytes.Length),0x3000,4);if(memory==IntPtr.Zero)throw new Exception("Trace path allocation failed.");
    UIntPtr written;if(!WriteProcessMemory(h,memory,bytes,new UIntPtr((uint)bytes.Length),out written)||written.ToUInt64()!=(ulong)bytes.Length)throw new Exception("Trace path write failed.");
    thread=CreateRemoteThread(h,IntPtr.Zero,UIntPtr.Zero,loader,memory,0,IntPtr.Zero);if(thread==IntPtr.Zero)throw new Exception("Trace loader could not start.");
    if(WaitForSingleObject(thread,15000)!=0)throw new Exception("Trace loader timed out. Close the game before retrying.");finished=true;
    process.Refresh();bool found=false;foreach(ProcessModule m in process.Modules)if(String.Equals(Path.GetFullPath(m.FileName),Path.GetFullPath(dll),StringComparison.OrdinalIgnoreCase))found=true;
    if(!found)throw new Exception("Windows did not load the trace DLL.");
   }finally{
    if(thread!=IntPtr.Zero)CloseHandle(thread);
    if(memory!=IntPtr.Zero&&(finished||thread==IntPtr.Zero))VirtualFreeEx(h,memory,UIntPtr.Zero,0x8000);
    CloseHandle(h);
   }
  }
 }
}
