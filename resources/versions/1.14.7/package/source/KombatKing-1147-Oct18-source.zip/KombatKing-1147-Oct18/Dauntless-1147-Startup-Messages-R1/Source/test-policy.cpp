// SPDX-License-Identifier: AGPL-3.0-only
#include <stdio.h>
#include <assert.h>
#include "MessagePolicy.h"
int main(){
 alignas(16) unsigned char client[0x80]{};
 wchar_t text[sizeof(StartupMessages::Error)/sizeof(wchar_t)];
 auto value=(StartupMessages::String*)(client+0x68);
 auto reset=[&]{memcpy(text,StartupMessages::Error,sizeof(text));value->data=(uintptr_t)text;value->num=sizeof(text)/sizeof(wchar_t);value->max=value->num+32;};
 auto read=[&](uintptr_t at,void* dest,size_t n){
  if((at==(uintptr_t)value&&n==sizeof(*value))||(at==(uintptr_t)text&&n==sizeof(text))){memcpy(dest,(void*)at,n);return true;}return false;
 };
 reset();auto pointer=value->data;auto capacity=value->max;
 assert(StartupMessages::ClearExactError(false,client,read));assert(value->num==0&&value->data==pointer&&value->max==capacity);assert(memcmp(text,StartupMessages::Error,sizeof(text))==0);
 reset();int num=value->num;assert(!StartupMessages::ClearExactError(true,client,read)&&value->num==num);
 reset();text[0]=L'X';assert(!StartupMessages::ClearExactError(false,client,read)&&value->num==num);
 reset();value->num--;assert(!StartupMessages::ClearExactError(false,client,read));
 reset();value->max=1;assert(!StartupMessages::ClearExactError(false,client,read)&&value->num==num);
 reset();value->data=1;assert(!StartupMessages::ClearExactError(false,client,read)&&value->num==num);
 assert(!StartupMessages::ClearExactError(false,nullptr,read));
 puts("PASS actual error-clearing policy: exact-only, failed-load-only, capacity/buffer retained, malformed/unreadable/null rejected");
}
