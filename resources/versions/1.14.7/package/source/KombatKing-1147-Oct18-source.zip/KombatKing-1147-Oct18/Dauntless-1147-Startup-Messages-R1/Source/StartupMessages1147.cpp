// SPDX-License-Identifier: AGPL-3.0-only
// Client-only, temporary message fix for 1.14.7 CL647472.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <wchar.h>
#include "minhook/MinHook.h"
#include "VerifiedExe.h"
#include "MessagePolicy.h"
static HMODULE module;
static uintptr_t base;
static HANDLE logFile=INVALID_HANDLE_VALUE;
static SRWLOCK logGate=SRWLOCK_INIT;
static bool(*originalLoad)(void*,void*);
static void(*originalSkip)(void*,void*,void*);
static LONG eacCount=0,skipCount=0;
static void log(const char* text){
 AcquireSRWLockExclusive(&logGate);
 if(logFile!=INVALID_HANDLE_VALUE){DWORD n;WriteFile(logFile,text,(DWORD)strlen(text),&n,0);WriteFile(logFile,"\r\n",2,&n,0);}
 ReleaseSRWLockExclusive(&logGate);
}
static bool readmem(uintptr_t at,void* dest,size_t size){SIZE_T n=0;return at&&ReadProcessMemory(GetCurrentProcess(),(void*)at,dest,size,&n)&&n==size;}
static bool loadHook(void* client,void* path){
 const bool loaded=originalLoad(client,path);
 if(StartupMessages::ClearExactError(loaded,client,readmem)&&InterlockedIncrement(&eacCount)<=4)log("APPLIED: exact offline IGameClient error cleared; original load result remains false");
 return loaded;
}
static void skipHook(void* object,void* frame,void* result){
 // Preserve the wrapper's FFrame consumption; change only this function's bool result.
 originalSkip(object,frame,result);
 if(result){*(unsigned char*)result=1;if(InterlockedIncrement(&skipCount)<=4)log("APPLIED: ShouldSkipPressStartScreen returned true through its normal Blueprint check");}
}
static DWORD WINAPI start(void*){
 wchar_t path[32768];DWORD n=GetModuleFileNameW(module,path,32768);if(!n||n>=32768)return 0;
 wchar_t* slash=wcsrchr(path,L'\\');if(!slash)return 0;
 swprintf(slash+1,32768-(slash+1-path),L"startup-fix1147-%lu.log",GetCurrentProcessId());
 logFile=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
 log("Startup messages TEST R2: native gameplay confirmation pending");
 wchar_t server[8];if(GetEnvironmentVariableW(L"D1147_SERVER",server,8)&&server[0]==L'1'){log("REFUSED: server process");return 0;}
 if(!hashExe()){log("REFUSED: wrong executable SHA256");return 0;}
 base=(uintptr_t)GetModuleHandleW(0);
 const unsigned char load[]={0x48,0x89,0x5c,0x24,0x18,0x55,0x56,0x57};
 const unsigned char skip[]={0x40,0x53,0x48,0x83,0xec,0x20};
 // Byte signatures below are checked against the reference PE before shipping.
 // The wrapper begins with REX+push rbx; the shared false-return stub is never patched.
 if(memcmp((void*)(base+0x1477dd0),load,sizeof(load))||memcmp((void*)(base+0x17805a0),skip,sizeof(skip))){log("REFUSED: an entry is changed or a conflicting helper is loaded");return 0;}
 if(MH_Initialize()!=MH_OK){log("ERROR: hook initialization failed");return 0;}
 void* a=(void*)(base+0x1477dd0);void* b=(void*)(base+0x17805a0);
 if(MH_CreateHook(a,(void*)loadHook,(void**)&originalLoad)!=MH_OK||MH_CreateHook(b,(void*)skipHook,(void**)&originalSkip)!=MH_OK){log("ERROR: could not create message hooks");return 0;}
 MH_QueueEnableHook(a);MH_QueueEnableHook(b);
 if(MH_ApplyQueued()!=MH_OK){MH_DisableHook(MH_ALL_HOOKS);log("ERROR: could not enable message hooks");return 0;}
 log("FIX_READY: launch continues normally. APPLIED lines confirm which hooks actually ran.");return 0;
}
extern "C" BOOL WINAPI DllMain(HINSTANCE inst,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH){module=inst;DisableThreadLibraryCalls(inst);HANDLE t=CreateThread(0,0,start,0,0,0);if(t)CloseHandle(t);}return TRUE;}
