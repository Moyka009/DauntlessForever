# Build

The installed DLL is byte-for-byte the working StartupMessages1147.dll from Startup Messages Test R2. It was not rebuilt for this installer.

To rebuild with Zig 0.17.0:

```
zig c++ -target x86_64-windows-gnu -shared -O2 -o Payload/StartupMessages1147.dll Source/StartupMessages1147.cpp Source/minhook/hook.c Source/minhook/buffer.c Source/minhook/trampoline.c Source/minhook/hde/hde64.c -lkernel32 -lbcrypt
```

Copy Source/Attach.cs to Payload/Attach.cs after editing the loader. Run Source/package.py to refresh SHA256.json and ZIP. MinHook retains its license. Exact EXE and target checks are in validate-target.py. The native error policy test is test-policy.cpp.

1.14.7 CL647472 EXE SHA256: f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b.
Manifest SHA1: aa70748e4c0a776a991f2bac10ad342adaa31476.
EAC load: RVA 0x1477dd0; error FString +0x68, Num +0x70. Dedicated skip wrapper: RVA 0x17805a0. The shared false-return routine 0x9ea390 is not changed. Addresses were found in the exact 1.14.7 PE and SDK.
