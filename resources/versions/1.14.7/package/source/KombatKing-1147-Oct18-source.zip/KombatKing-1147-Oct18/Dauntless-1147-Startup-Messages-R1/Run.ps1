# SPDX-License-Identifier: AGPL-3.0-only
param([ValidateSet('install','check','restore')][string]$Action='install',[string]$Package='',[string]$Launcher='C:\DauntlessForever')
$ErrorActionPreference='Stop'
try {
 if(-not $Package){
  $dataRoot=if($env:DL_DATA_DIR){$env:DL_DATA_DIR}else{Join-Path $env:LOCALAPPDATA 'DauntlessForever'}
  $Package=Join-Path $dataRoot 'versions\1.14.7'
 }
 if(-not(Test-Path -LiteralPath (Join-Path $Package 'services_1147.json'))){$Package=(Read-Host 'Enter the active 1.14.7 package folder').Trim().Trim('"')}
 $Package=[IO.Path]::GetFullPath($Package)
 if($Action -ne 'check'){
  $running=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'Dauntless-Win64-Shipping.exe'})
  if($running.Count){throw 'Close the game and stop its server copies before installing or restoring.'}
 }
 $node=Join-Path $Launcher 'resources\runtime\node\node.exe'
 if(-not(Test-Path -LiteralPath $node)){
  $config=Get-Content -LiteralPath (Join-Path $Package 'config.json') -Raw | ConvertFrom-Json
  if($config.Node -and (Test-Path -LiteralPath $config.Node)){$node=$config.Node}
  else{$command=Get-Command node.exe -ErrorAction SilentlyContinue;if($command){$node=$command.Source}else{$node=(Read-Host 'Enter the full path to node.exe').Trim().Trim('"')}}
 }
 if(-not(Test-Path -LiteralPath $node)){throw 'Node executable not found.'}
 Write-Host "Active 1.14.7 package: $Package"
 & $node (Join-Path $PSScriptRoot 'Source\install.cjs') $Action $Package
 if($LASTEXITCODE -ne 0){throw 'Operation failed. Read the reason above.'}
 exit 0
}catch{Write-Host "STOPPED: $($_.Exception.Message)" -ForegroundColor Red;exit 1}
