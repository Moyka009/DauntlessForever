# Startup messages R1

- Permanently register the user-confirmed R2 startup-message DLL with normal 1.14.7 Play.
- Prepare the loader before starting the player and attach immediately afterward.
- Wait briefly for Windows module initialization before attachment.
- Verify game and helper hashes; report native initialization failure without terminating the player's game.
- Hide only the exact known offline IGameClient error; preserve other errors and original initialization result.
- Use the dedicated ShouldSkipPressStartScreen check; preserve FFrame handling and other shared game functions.
- Add Install, Check, Restore, verified backups, transactional writes, and failure rollback.
- Restore removes only marked additions, preserving later unrelated Play-script edits.
- Keep two prior helper logs, without starting another recording/background worker.
- Preserve saves, settings, backend, DLL loader, launcher ASAR, and PAKs.
