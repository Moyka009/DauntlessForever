# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import hashlib, struct, sys
b=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(b).hexdigest()=='f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b'
pe=struct.unpack_from('<I',b,0x3c)[0]
n=struct.unpack_from('<H',b,pe+6)[0]
opt=struct.unpack_from('<H',b,pe+20)[0]
sections=[]
for i in range(n):
    off=pe+24+opt+i*40
    size,rva,rawsize,raw=struct.unpack_from('<IIII',b,off+8)
    sections.append((rva,max(size,rawsize),raw))
def at(rva,n):
    for start,size,raw in sections:
        if start<=rva and rva+n<=start+size:return b[raw+rva-start:raw+rva-start+n]
    raise ValueError(hex(rva))
assert at(0x1477dd0,8).hex()=='48895c2418555657'
assert at(0x17805a0,6).hex()=='40534883ec20'
assert at(0x9ea390,3).hex()=='32c0c3'
call=at(0x17805be,5)
assert call[0]==0xe8 and 0x17805be+5+struct.unpack_from('<i',call,1)[0]==0x9ea390
message='Failed to create IGameClient instance!\nCheck that the game was run from the correct launcher.\nOnline Play may not be available.\0'.encode('utf-16-le')
assert at(0x52c0f20,len(message))==message
print('PASS exact target SHA256, both hook signatures, dedicated wrapper call, untouched shared stub, and full error literal')
