# Validation

The DLL is byte-identical to Test R2, which the user confirmed removed both messages without blocking the game.

Permanent installer checks passed: eight groups covering LF/CRLF round trips, install/check/reinstall, exact restore, later unrelated Play-script edits, saves preserved, failed-install rollback, failed-restore rollback, unsupported script refusal, and edited-helper refusal. Fixtures used the actual hash-matched reference EXE through hard links.

Real PowerShell 7.6.7 parsed every supplied PowerShell script. Add-Type compiled the actual loader. Startup helper gracefully skips when initialization has not succeeded. These integration checks ran on Linux; the first permanent Windows launcher run remains to be confirmed.

Installer edits only the active package's Play script and its own helper files. Native behavior and addresses are the already-confirmed R2 fix. No game EXE, server DLL, launcher ASAR, backend, save, settings, or PAK modification is included.
