# Validation — R2

## Passed

- **38 real backend HTTP/restart groups**: nineteen scenarios on the reviewed official backend and again with AIO/Radiant. Includes all R1 loadout behavior, free account slots, all 100 zero-price rank offers, real zero-wallet rank purchase, notification replay, positive-wallet purchase without any deduction, native platinum charge suppression, unchanged other currency costs and persistence through a further restart.
- **20 installer groups**: .5/.2 official/Radiant variants, LF/CRLF, fresh and R1 upgrades, idempotence, Check, precise Restore, exact save preservation, injected failure rollback of all four files, unknown-backend refusal and tampered-module detection.
- **6 focused save-safety/price groups**: R1's four memory/slot preservation scenarios plus platinum family/nested/string-price handling, retained platinum rewards/other-currency prices and native cost filtering.
- Both reviewed Hunt Pass versions compile after price/charge patches, in LF and CRLF.
- Static PowerShell syntax, JavaScript syntax, JSON parse, delivery SHA256 integrity and final ZIP CRC checks.

## Native evidence

The **1.14.7 CL647472** manifest and PAK entry hashes were used to read `Archon/Config/DefaultGame.ini`. It explicitly names the five `LoadoutSlot_01` … `_05` Path unlock conditions and the native endpoint URLs. `UpdateLoadoutSlotSetActiveEndpoint` and `UpdateActiveLoadoutSlotEndpoint` point to the same `/active/{index}` URL, confirming why the handler must support both save-and-switch and switch-only.

The SDK independently identifies `AArchonLoadout`'s active index, slot counts, Path unlock conditions and shared cosmetic functions. No 1.6.2 offsets, DLL addresses or PAKs are used by this fix.

## Limits

Windows native gameplay and Windows PowerShell execution were **not** available. PowerShell was statically parsed; current backend HTTP routes and actual persistence/restarts were executed. Tests prove backend behavior, not the final in-game UI/equipping animation.

The reviewed upstream snapshot is commit `5a8fe6e4f334ea86904476a117a4785af4632e8f`, package `2026-10-18.5`. A fresh network recheck timed out during packaging; the installer therefore accepts only the known reviewed hashes and refuses an unreviewed newer backend.

Re-run from this folder:

```text
node Tests/runtime.cjs
node Tests/module.cjs
node Tests/install-r2.cjs
python Tests/powershell-syntax.py
```

Runtime tests need the complete reviewed fixture backend; installer tests need the original executable. Paths can be set using `DF_OFFICIAL_1147` and `DF_ORIGINAL_1147_EXE` as documented in the test source. Static Python checks need tree-sitter and tree-sitter-powershell. Players only need the normal launcher Node runtime.
