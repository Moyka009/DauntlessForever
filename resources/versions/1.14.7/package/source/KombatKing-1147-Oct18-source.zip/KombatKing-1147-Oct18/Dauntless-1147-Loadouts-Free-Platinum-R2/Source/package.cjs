// SPDX-License-Identifier: AGPL-3.0-only
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=path.resolve(__dirname,'..'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const n of ['Install.cmd','Check.cmd','Restore.cmd','Run.ps1']){const p=path.join(base,n);fs.writeFileSync(p,fs.readFileSync(p,'utf8').replace(/\r?\n/g,'\r\n'));}
const files={};function walk(dir){for(const d of fs.readdirSync(dir,{withFileTypes:true})){if(d.name==='__pycache__')continue;const p=path.join(dir,d.name);if(d.isDirectory())walk(p);else{const n=path.relative(base,p).replaceAll('\\','/');if(n!=='Integrity.json')files[n]=hash(fs.readFileSync(p));}}}walk(base);fs.writeFileSync(path.join(base,'Integrity.json'),JSON.stringify({algorithm:'sha256',files},null,2)+'\n');console.log('Prepared '+Object.keys(files).length+' hashed source/delivery files.');
