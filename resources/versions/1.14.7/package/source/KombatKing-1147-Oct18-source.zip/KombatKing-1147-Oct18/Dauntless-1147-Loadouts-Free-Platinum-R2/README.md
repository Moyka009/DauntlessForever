# Dauntless 1.14.7 — Loadouts Fix + Free Platinum R2

Repairs the current game's loadout saving and switching, and makes platinum-priced purchases free. This updates the current loadout fix; it is separate from the 1.6.2 → 1.14.7 save-transfer tool.

## Install

1. Extract the whole ZIP into a normal folder.
2. Close Dauntless, its backend/server windows and the launcher.
3. Double-click **Install.cmd**.
4. Start 1.14.7 normally. Existing loadouts are repaired when the game first requests them.

**Check.cmd** verifies the installed hook/module. **Restore.cmd** removes this fix while retaining other compatible backend edits and your current save. Installation itself does not change any save bytes.

If Loadouts R1 is already installed, run this **Install.cmd** directly. You do not need to restore R1 first. This bundle also works without R1. Restoring R2 returns to the prior R1 installation if present; its backup/receipt remain intact. Restore R2 before attempting to restore R1.

## Platinum rule

- Returned platinum price/sale-price records are 0, including platform variants and captured store offers.
- All 100 Hunt Pass rank-skip offers are free. Purchase/redemption no longer requires or deducts platinum, including when no platinum stack exists.
- Account loadout-slot unlocks are free up to the reviewed slot limit. Retried requests retain the requested total instead of repeatedly incrementing it.
- Native inventory cost-removal requests cannot deduct platinum. Platinum rewards and existing wallet balances are retained.
- Other currencies retain their prices. Slayer's Path node ownership is not changed.

Zero-wallet and positive-wallet purchases were tested through the backend, including replay and restarts. No new shop products are invented by the price rule.

The normal active package is detected automatically:

`C:\Users\mw3ki\AppData\Local\DauntlessForever\versions\1.14.7`

On another PC the Windows username is detected automatically. Custom package paths can be supplied through `Run.ps1 -Package` or entered if detection fails. The launcher source directory under `resources\versions` is not the active save location.

## Included repairs

- Correct loadout counts using the game's five Slayer's Path loadout unlock conditions. Existing saved slots are retained. New players get the base slot; additional account slots cost 0 platinum. The fix does not mark Path nodes unlocked.
- Native account/character slot-count routes return counts; the account route no longer falls into the active-gear route.
- Empty positions in old sparse slot arrays are filled from an existing valid loadout, with independent copies and correct slot indices. Later saved gear and names remain intact.
- Slot saving normalizes `slot_index` to the requested slot.
- Both native active-slot flows work: switch-only, and **save the supplied loadout then activate it**. Previously the latter discarded the save body.
- Invalid/locked switches return an error instead of reporting success without switching.
- Shared persistent cosmetics have one authoritative record. Every returned slot gets that same record; stale embedded copies cannot replace it. Partial persistent saves keep omitted emoji/emote/accessory settings.
- Account/character ownership checks prevent requests from creating foreign-character loadouts under another player's account.
- Invalid arrays/JSON are refused without replacing the old saved data. A failed save rolls memory back as well.

Cells, dyes, weapon parts, equipped instance IDs and gear upgrade data are kept. This repair does not grant inventory items, alter damage/rules, change shops, or add diagnostic log recorders.

## Backups and restore

Installer backups:

`<active package>\backup\loadouts-free-platinum1147-r2\`

Before the first automatic normalization of an existing loadout record, its exact original JSON data is kept under:

`<active package>\backup\loadouts1147-repair\`

The filenames include a content hash: repeated unchanged reads do not create more copies. These repair backups are retained after Restore. Restore changes backend code only; it does not roll back gear, purchases or gameplay progress.

## Compatibility and boundaries

Reviewed official server packages **2026-10-18.5** and its **2026-10-18.2** predecessor, with or without the known All-in-One Radiant hook. Requires the original **1.14.7 CL647472** game executable. LF and Windows CRLF backend files are accepted. Unknown builds/edits are refused before installation.

Existing Inventory Search, Item Expiry, Trials shop, Personal Game Rules and Client Engine Log/cleanup files are left in place. Restore strips only this patch's exact hook, so compatible later edits outside that hook are retained. A later installer that independently manages recorder-1147.js may reject this extra hook; restore this fix before running that installer, then reinstall the loadout fix if the new backend is supported.

The fix retains the reviewed backend's 16-slot index limit. The native config proves five progression unlocks. Account slot unlocks now cost 0; progression slots still follow their Path nodes.

`update_version` is retained but is not turned into a new strict concurrency contract: native zero-version save behavior has not been fully traced. This release fixes the verified save-and-activate, slot-array, count and persistent-data problems; it does not claim to solve every possible delayed-packet race.

The actual Windows game was not run here. See VALIDATION.md for successful real backend/restart and installer tests.

Source, per-patch notes, backend.md, native evidence and **LICENSE-AGPL-3.0.txt** are included. No standalone NOTICE file is installed.
