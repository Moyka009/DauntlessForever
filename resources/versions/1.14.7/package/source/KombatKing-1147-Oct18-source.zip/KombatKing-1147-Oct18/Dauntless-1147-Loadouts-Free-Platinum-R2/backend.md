# Backend changes

## Installed files

- Adds `backend/loadouts-fix1147.js`.
- Adds `backend/free-platinum1147.js`.
- Inserts marked loadout dispatch, platinum price-response filtering and inventory charge filtering in `backend/recorder-1147.js`.
- Patches `backend/huntpass1147.js` price, balance-gate and deduction expressions so rank skips are actually free.

The loadout hook runs before the existing official/Radiant feature chain. Store JSON replies pass through a currency-aware zero-price transform. Native inventory removeStackedItems entries for platinum-family IDs are omitted before the original transaction machinery runs. Other costs and added platinum rewards remain.

Hunt Pass prices change from 150 × ranks to 0; the purchase balance gate and redemption deduction are removed. A missing platinum stack does not break free redemption. Existing reward settlement, character/token binding, rank limits and one-time notification replay behavior are retained.

## Save behavior

Only the requested account/character's loadout record is normalized. The module keeps its gear references and existing data, supplies independent copies for null/missing reachable slots, normalizes indices, and makes `persistent` consistent across slots.

`player.loadoutSlots1147` records retained account-slot allowance and reconciled character counts. This prevents a later Path unlock from erasing the inferred account allowance. Path ownership is read from `player.pjmMaps.main.nodes.LoadoutSlot_01` through `_05` with native status 2; those nodes are not changed. Existing slot arrays are also retained as evidence of previous use. New players are not granted additional Path slots just by installing the patch.

The reviewed backend previously accepted indices 0–15. This limit remains 16 total; five character slots come from the native Path conditions, with the remainder reserved as the account allowance. Account unlock requests now persist a requested total allowance at no platinum cost. Retries take the higher existing/requested total rather than repeatedly incrementing it. Path requirements remain separate.

Save-and-activate requests contain the new slot data under `body.data`. The old active handler ignored this. The repair parses/stores that object, sets its index, then switches the active index in one save. A switch-only request changes only the active index. Persistent writes merge partial fields into the canonical record and synchronize all stored slots.

Before automatic repair, original loadout JSON is copied to a hash-named recovery file. New-record creation does not fabricate an original backup. A failed state write restores both in-memory loadout and count metadata. Existing malformed non-object slot entries are refused instead of silently discarded.

Gear upgrades, Path node ownership, Radiant progression, transfer receipts and game rules are retained. Normal free purchases still grant advertised rewards/ranks/slots. Platinum balances are neither reset nor inflated; purchases simply cost 0. No background job or log recorder is installed.

## Restore

The installer verifies all four managed files and original backups. It accepts reviewed official/AIO backends with or without Loadouts R1. Restore removes R2's hooks and restores prior helper/Hunt Pass files. If R1 predated R2, its hook/module are restored; otherwise the bundled loadout hook is removed too. Compatible later recorder edits are kept byte-for-byte. Current save state and repair backups remain.

No optimistic version rejection was introduced from an unverified assumption about native `update_version` semantics. It remains a separate trace item; rejecting normal zero-version game saves could create new failures.
