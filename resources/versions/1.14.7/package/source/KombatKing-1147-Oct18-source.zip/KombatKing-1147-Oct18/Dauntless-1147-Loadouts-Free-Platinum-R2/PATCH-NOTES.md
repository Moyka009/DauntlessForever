# R2 — 2026-10-18

- Added the requested rule: every platinum price is 0, including platform variants and sale prices.
- Removed Hunt Pass rank-skip platinum balance checks and deductions; supports a zero wallet/no platinum stack.
- Added a platinum cost-removal guard to native inventory transactions; rewards/additions and other currencies are retained.
- Made account loadout-slot unlocks free, with idempotent total-count handling.
- Included all R1 loadout repairs below in the same installer.
- Supports direct installation over R1 or a reviewed fresh official/AIO backend; R2 Restore reinstates the prior R1 installation where present.

- Repair loadout slot counts from native Path unlock conditions and retained existing slots.
- Handle the account-level slotcount URL before the generic active-loadout URL.
- Repair sparse arrays and inconsistent slot indices without deleting later slots.
- Save payloads supplied to the native save-and-activate endpoint.
- Keep shared cosmetics synchronized across active/all-slot replies and normal saves.
- Reject invalid/locked switches and malformed payloads.
- Add account/character ownership checks and failed-write rollback.
- Back up original loadout records before normalization, deduplicated by content hash.
- Add standalone Install, Check and partial Restore with original-file backup.
- Preserve official/AIO/Radiant feature routing and existing inventory/rule/logging patches.
- Include source, native evidence, tests, backend.md and AGPL-3.0-only license.

This is a current-game loadout/free-platinum fix, not a save-transfer revision. Strict delayed-packet version handling remains outside this release's verified scope.
