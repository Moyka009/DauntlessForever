# SPDX-License-Identifier: AGPL-3.0-only
param([ValidateSet('install','check','restore')][string]$Action='install',[string]$Package='',[string]$Launcher='C:\DauntlessForever')
$ErrorActionPreference='Stop'
try {
    if (-not $Package) {
        $roots=@()
        if ($env:DL_DATA_DIR) { $roots += $env:DL_DATA_DIR }
        elseif ($env:LOCALAPPDATA) {
            $legacy=Join-Path $env:LOCALAPPDATA 'DauntlessOffline'
            if ((Test-Path -LiteralPath (Join-Path $legacy 'launcher.json')) -or (Test-Path -LiteralPath (Join-Path $legacy 'versions'))) { $roots += $legacy }
            else { $roots += (Join-Path $env:LOCALAPPDATA 'DauntlessForever') }
        }
        foreach ($root in $roots) {
            $candidate=Join-Path $root 'versions\1.14.7'
            if (Test-Path -LiteralPath (Join-Path $candidate 'backend\recorder-1147.js')) { $Package=$candidate; break }
        }
        if (-not $Package) { $Package=Read-Host 'Enter the active 1.14.7 package folder' }
    }
    $Package=[IO.Path]::GetFullPath($Package.Trim().Trim('"'))
    if ($Action -ne 'check') {
        $running=@(Get-CimInstance Win32_Process | Where-Object {
            $_.Name -eq 'Dauntless-Win64-Shipping.exe' -or
            ($_.Name -eq 'node.exe' -and $_.CommandLine -match '(recorder|supervisor)-1147\.js') -or
            $_.Name -in @('DauntlessForever.exe','Dauntless Forever.exe')
        })
        if ($running.Count) { throw 'Close Dauntless, stop its backend/servers and close the launcher first.' }
    }
    $cfg=Get-Content -LiteralPath (Join-Path $Package 'config.json') -Raw | ConvertFrom-Json
    $nodePath=$cfg.Node
    if (-not $nodePath -or -not (Test-Path -LiteralPath $nodePath)) { $nodePath=Join-Path $Launcher 'resources\runtime\node\node.exe' }
    if (-not (Test-Path -LiteralPath $nodePath)) {
        $nodeCommand=Get-Command node.exe -ErrorAction SilentlyContinue
        if ($nodeCommand) { $nodePath=$nodeCommand.Source }
        else { throw 'Node.js was not found. Run the official launcher Set up first.' }
    }
    Write-Host "Active 1.14.7 package: $Package"
    & $nodePath (Join-Path $PSScriptRoot 'Source\install-r2.cjs') $Action $Package
    if ($LASTEXITCODE -ne 0) { throw 'Operation failed. Read the reason above.' }
    exit 0
} catch { Write-Host "STOPPED: $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
