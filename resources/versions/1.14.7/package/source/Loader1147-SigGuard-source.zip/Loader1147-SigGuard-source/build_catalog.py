# SPDX-License-Identifier: AGPL-3.0-only
from pathlib import Path
import hashlib, json, struct
from equipment_asset import Asset
from catalog_reader import table
R=Path(__file__).resolve().parent.parent
p=R/'Source/Inputs/weapon_dp_gameplay_catalog.uasset'
a=Asset(p); original=a.b
e=a.exports[0];pos,_=a.properties(e['start']);pos+=4
count=struct.unpack_from('<I',a.b,pos)[0];pos+=4
changes=[]
for _ in range(count):
    key,pos=a.name(pos);end,fields=a.properties(pos)
    if key=='WP_DP_BEGINNER':
        scan=pos
        while scan<end:
            t=a.tag(scan)
            if t['name']=='GenericItemData':
                inner=t['start']
                while inner<t['end']:
                    sub=a.tag(inner)
                    if sub['name']=='Kind':
                        assert sub['type']=='EnumProperty' and sub['size']==8
                        assert a.name(sub['start'])[0]=='EItemGroupType::Weapon_Sword'
                        data=bytearray(a.b)
                        struct.pack_into('<II',data,sub['start'],a.names.index('EItemGroupType::Weapon_DP'),0)
                        a.b=bytes(data);changes.append(sub['start'])
                    inner=sub['end']
            scan=t['end']
    pos=end
assert len(changes)==1
built=R/'Source/Built';built.mkdir(exist_ok=True)
(built/p.name).write_bytes(a.ua);(built/p.with_suffix('.uexp').name).write_bytes(a.b)
before=table(p);after=table(built/p.name)
differences=[]
for old,new in zip(before['rows'],after['rows']):
    for x,y in zip(old['fields'],new['fields']):
        if x!=y:differences.append({'id':old['id'],'before':x,'after':y})
assert len(differences)==1 and differences[0]['id']=='WP_DP_BEGINNER'
assert differences[0]['after']['value']=='EItemGroupType::Weapon_DP'
def fstr(s):
    b=s.encode()+b'\0';return struct.pack('<i',len(b))+b
def entry(off,data):
    return struct.pack('<QQQI',off,len(data),len(data),0)+hashlib.sha1(data).digest()+bytes(5)
files={f'Gameplay/Backend/Catalogs/Gear_Catalogs/{p.stem}.{ext}':data for ext,data in [('uasset',a.ua),('uexp',a.b)]}
out=bytearray();rows=[]
for name,data in sorted(files.items()):
    ent=entry(len(out),data);out+=ent+data;rows.append((name,ent))
index=fstr('../../../Archon/Content/')+struct.pack('<I',len(rows))+b''.join(fstr(name)+ent for name,ent in rows)
offset=len(out);out+=index
out+=bytes(17)+struct.pack('<IIQQ',0x5a6f12e1,8,offset,len(index))+hashlib.sha1(index).digest()+b'Zlib'.ljust(32,b'\0')+bytes(128)
(R/'Payload/zzzzzzzz_Equipment1147_P.pak').write_bytes(out)
(R/'Reports/catalog-change.json').write_text(json.dumps({'game':'1.14.7 CL647472','rows':count,'differences':differences,'changed_asset_offsets':changes,'pak_version':8},indent=2))
print('PASS: exactly one catalog field changed, 34 repeater rows retained, legacy PAK 8')
