// SPDX-License-Identifier: AGPL-3.0-only
const fs=require('fs'),path=require('path'),os=require('os'),assert=require('assert');
const root=path.resolve(__dirname,'..'),tmp=fs.mkdtempSync(path.join(os.tmpdir(),'equipment-fixture-'));
const game=path.join(tmp,'game'),pkg=path.join(tmp,'package'),bin=path.join(game,'Archon/Binaries/Win64'),paks=path.join(game,'Archon/Content/Paks');
for(const d of [bin,paks,path.join(pkg,'tools'),path.join(pkg,'bin'),path.join(pkg,'data')])fs.mkdirSync(d,{recursive:true});
if(!process.argv[2]||!process.argv[3])throw Error('Usage: node Source/test_installer.cjs ORIGINAL_PACKAGE EXACT_1147_EXE');
fs.copyFileSync(path.resolve(process.argv[3]),path.join(bin,'Dauntless-Win64-Shipping.exe'));
const old=path.resolve(process.argv[2]);
for(const p of [path.join(bin,'dxgi.dll'),path.join(pkg,'bin/dxgi.dll')])fs.copyFileSync(path.join(old,'bin/dxgi.dll'),p);
fs.copyFileSync(path.join(old,'tools/common.ps1'),path.join(pkg,'tools/common.ps1'));
fs.writeFileSync(path.join(pkg,'data/state.json'),'SAVE SENTINEL');
const launcher=path.join(tmp,'launcher'),versionDir=path.join(launcher,'resources/versions/1.14.7'),bundled=path.join(versionDir,'package');
for(const d of [path.join(bundled,'bin'),path.join(bundled,'tools')])fs.mkdirSync(d,{recursive:true});
fs.copyFileSync(path.join(old,'bin/dxgi.dll'),path.join(bundled,'bin/dxgi.dll'));
fs.copyFileSync(path.join(old,'tools/common.ps1'),path.join(bundled,'tools/common.ps1'));
fs.copyFileSync(path.join(old,'bin/EOSSDK-Win64-Shipping.dll'),path.join(bin,'EOSSDK-Win64-Shipping.dll'));
const metaSource=path.join(old,'../version.json');
const metadata=fs.readFileSync(metaSource),metadataPaths=[path.join(pkg,'version.json'),path.join(versionDir,'version.json')];
for(const p of metadataPaths)fs.writeFileSync(p,metadata);
const crypto=require('crypto');
function setupReady(p){const j=JSON.parse(fs.readFileSync(p));return j.package.installedFiles.every(f=>crypto.createHash('sha256').update(fs.readFileSync(path.join(game,f.rel))).digest('hex')===f.sha256.toLowerCase());}
assert(metadataPaths.every(setupReady));
const {run}=require(path.join(root,'Tools/patch.cjs')),input={game,packages:[pkg,bundled],launcher};
const common=path.join(pkg,'tools/common.ps1'),original=fs.readFileSync(common);
fs.appendFileSync(common,'# another change');assert.throws(()=>run('install',input),/no files changed/);
assert(!fs.existsSync(path.join(paks,'zzzzzzzz_Equipment1147_P.pak')));fs.writeFileSync(common,original);
run('install',input);run('check',input);run('install',input);assert(metadataPaths.every(setupReady));
const installed=fs.readFileSync(common);assert(installed.includes(Buffer.from(require(path.join(root,'manifest.json')).payload['dxgi.dll'].toUpperCase())));
fs.appendFileSync(common,'# later edit');assert.throws(()=>run('restore',input),/Target changed/);
assert(fs.existsSync(path.join(paks,'zzzzzzzz_Equipment1147_P.pak')));fs.writeFileSync(common,installed);
run('restore',input);run('restore',input);
// Reproduce original R1: DLL/common patched but launcher metadata left original.
run('install',input);
const upgradeState=path.join(game,'PatchState/Equipment1147'),upgradeRec=path.join(upgradeState,'installation.json');
const oldRecord=JSON.parse(fs.readFileSync(upgradeRec));
const omitted=oldRecord.targets.filter(t=>t.metadata||t.path.startsWith(bundled+path.sep));
for(const t of omitted)fs.copyFileSync(path.join(upgradeState,t.backup),t.path);
oldRecord.targets=oldRecord.targets.filter(t=>!omitted.includes(t));delete oldRecord.installer_fix;delete oldRecord.metadata_files;
fs.writeFileSync(upgradeRec,JSON.stringify(oldRecord));
assert(metadataPaths.every(p=>!setupReady(p))); // Original setup loop reproduced.
assert.throws(()=>run('check',input),/launcher setup metadata/);
run('install',input);run('check',input);assert(metadataPaths.every(setupReady));
run('restore',input);assert(metadataPaths.every(setupReady));
for(const p of metadataPaths)assert(fs.readFileSync(p).equals(metadata));
// Simulate interruption after one target write; retry must recover and complete.
run('install',input);
const state=path.join(game,'PatchState/Equipment1147');
const recPath=path.join(state,'installation.json');
const record=JSON.parse(fs.readFileSync(recPath));
for(const t of record.targets.slice(1)){if(t.before===null)fs.unlinkSync(t.path);else fs.copyFileSync(path.join(state,t.backup),t.path);}
fs.renameSync(recPath,path.join(state,'pending.json'));
assert.throws(()=>run('check',input),/interrupted/);
run('install',input);run('check',input);run('restore',input);
assert(fs.readFileSync(common).equals(original));assert.equal(fs.readFileSync(path.join(pkg,'data/state.json'),'utf8'),'SAVE SENTINEL');
assert(!fs.existsSync(path.join(paks,'zzzzzzzz_Equipment1147_P.pak')));
const {entries}=require(path.join(root,'Tools/paks.cjs'));
const ents=entries(path.join(root,'Payload/zzzzzzzz_Equipment1147_P.pak'));assert.equal(ents.length,2);assert(ents.every(s=>s.includes('weapon_dp_gameplay_catalog.')));
assert(metadataPaths.every(setupReady));for(const p of metadataPaths)assert(fs.readFileSync(p).equals(metadata));
fs.rmSync(tmp,{recursive:true,force:true});console.log('PASS: launcher setup predicate on active and bundled metadata, original R1 upgrade without restore, metadata exact restore, edited-target preflight, install/check/idempotence, changed-target restore refusal, exact restore, save preservation, PAK scope');
