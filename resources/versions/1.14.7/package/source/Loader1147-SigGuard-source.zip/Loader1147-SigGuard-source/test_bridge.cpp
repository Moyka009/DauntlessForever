// SPDX-License-Identifier: AGPL-3.0-only
// Host-side behavioral checks. Does not execute Unreal or prove in-game behavior.
#include <cassert>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cstdarg>
#include <cwchar>
#include <sys/mman.h>
using DWORD = unsigned long;
constexpr DWORD PAGE_READWRITE = 4;
static bool VirtualProtect(void*, size_t, DWORD, DWORD* old) { *old = 4; return true; }
static void* InterlockedExchangePointer(void* volatile* target, void* value) {
    void* old = *target; *target = value; return old;
}
static uintptr_t g_base;
namespace A { constexpr uintptr_t Object_Class = 0x10, ProcessEvent = 0x2861880; }
template<class T> static T& at(uintptr_t a) { return *(T*)a; }
static void logf_(const char*, ...) {}
static void* find_function(void*, const wchar_t* n) {
    assert(!wcscmp(n, L"ClientActivateAbilityFailed")); return (void*)1;
}
#include "equipment_bridge.h"
static int downs, ups, activates, failures;
static bool result;
static uint32_t expectedHandle;
static void* expectedEvent;
static void down(void*, uint32_t h) { assert(h == expectedHandle); ++downs; }
static void up(void*, uint32_t h) { assert(h == expectedHandle); ++ups; }
static bool activation(void*, uint32_t h, EquipmentPredictionKey* k, void** instance, void* ended, void* event) {
    assert(h == expectedHandle && k->current == 17 && k->base == 9);
    assert(k->predictiveConnection == (void*)0x1234 && !ended && event == expectedEvent);
    ++activates; k->current = 99; *instance = (void*)2; return result;
}
static void failure(void*, void* fn, void* args) {
    assert(fn == (void*)1); auto* p = (uint8_t*)args;
    assert(*(uint32_t*)p == expectedHandle && *(int16_t*)(p+4) == 17); ++failures;
}
static void jump(uintptr_t rva, void* target) {
    uint8_t bytes[12] = {0x48,0xb8}; memcpy(bytes+2, &target, 8); bytes[10]=0xff; bytes[11]=0xe0;
    memcpy((void*)(g_base+rva),bytes,12);
}
int main() {
    g_base=(uintptr_t)mmap(nullptr,0x5400000,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    assert(g_base!=(uintptr_t)MAP_FAILED);
    assert(!install_equipment_bridge()); // Foreign executable rejected before vtable writes.
    memcpy((void*)(g_base+0x16C85D0),"\x4C\x89\x4C\x24\x20\x4C\x89\x44\x24\x18\x89\x54\x24\x10\x55\x53",16);
    memcpy((void*)(g_base+0x16DEC40),"\x48\x8B\x81\xF8\x04\x00\x00\x4C",8);
    memcpy((void*)(g_base+0x16DEC80),"\x48\x8B\x81\xF8\x04\x00\x00\x4C",8);
    at<uintptr_t>(g_base+0x533E190)=g_base+0x9EA380;
    at<uintptr_t>(g_base+0x53E2A88)=0;
    assert(!install_equipment_bridge());
    assert(at<uintptr_t>(g_base+0x533E190)==g_base+0x9EA380); // No partial write on mismatch.
    at<uintptr_t>(g_base+0x53E2A88)=g_base+0x9EA380;
    assert(install_equipment_bridge());
    assert(at<void*>(g_base+0x533E190)==(void*)&equipment_activate);
    assert(at<void*>(g_base+0x53E2A88)==(void*)&equipment_activate);
    jump(0x16DEC40,(void*)&down);jump(0x16DEC80,(void*)&up);
    jump(0x16C85D0,(void*)&activation);jump(A::ProcessEvent,(void*)&failure);
    uint8_t component[32]{};EquipmentPredictionKey key{17,9,0,0,{0,0},(void*)0x1234};expectedHandle=42;
    result=true;expectedEvent=nullptr;equipment_activate(component,42,true,&key,nullptr);
    assert(downs==1&&ups==0&&activates==1&&failures==0&&key.current==17);
    result=false;equipment_activate(component,42,true,&key,nullptr);
    assert(downs==2&&ups==1&&activates==2&&failures==1&&key.current==17);
    expectedEvent=(void*)0x5678;equipment_activate(component,42,false,&key,expectedEvent);
    assert(downs==2&&ups==1&&activates==3&&failures==2);
    result=true;equipment_activate(component,42,false,&key,expectedEvent);
    assert(downs==2&&ups==1&&activates==4&&failures==2);
    equipment_activate(nullptr,42,false,&key,nullptr);equipment_activate(component,42,false,nullptr,nullptr);
    assert(activates==4);
    puts("PASS: guarded installation, no partial writes, success/failure, input state, key isolation, event forwarding, null rejection");
}
