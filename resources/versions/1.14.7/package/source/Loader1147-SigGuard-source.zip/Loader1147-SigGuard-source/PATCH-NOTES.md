# Equipment Fix 1.14.7 — R1 test build, installer fix 1

- Replaces the empty server ability-activation handler with the existing native activation routine. Both plain activation requests and requests carrying event data use this repair.
- Preserves the incoming prediction key, updates pressed/released input state, and sends the existing failure reply when activation is rejected.
- Corrects Recruit's Repeaters from the sword inventory category to the repeater category. Other repeater catalog fields are unchanged.
- Updates both the startup-script loader hash and the launcher version metadata hash to match the rebuilt DLL. This resolves the repeated setup prompt after installation.
- Supports upgrading the original R1 installation in place, including finding and patching bundled package files that the first installer missed.
- Adds verified backups outside the extracted patch folder, repeat-install checks, interrupted-install recovery, and restore.

## **IMPORTANT**: CHANGES MADE TO BACKEND IN THIS PATCH

- Rebuilds the native server loader `bin/dxgi.dll` and installs the same DLL beside the game executable. The new gameplay handler is enabled only in server processes started with `D1147_SERVER=1`.
- Changes two ability-system vtable entries in server memory, after checking their original targets and the native routine's bytes. The shared empty function itself is not modified.
- Changes only `$LoaderHash` in each detected package's `tools/common.ps1` to recognize the new DLL.
- Updates only the DXGI entry in `package.installedFiles` in detected 1.14.7 `version.json` files. Other metadata values are retained, and original metadata bytes are backed up for restore.
- The HTTP backend `backend/recorder-1147.js` is not changed. No save migration or inventory grants are performed.
- Original game executable SHA256: `f3f95fbf22709ef077a11632ed95d675b7209b7e0172d9ecb9ba7d02a1fbb66b`.
- Original native loader SHA256: `176cb7ad849a9e213d884510416bbc1fb2bf4b56ef9561ee554a0abfbd6ac208`.
- New native loader SHA256: `69f263440a51e13d20af60be2cf2dc36aad891319dbb1d00cbb218f692422227`.

This is a gameplay test build. The missing activation path is repaired in code; native gameplay has not been run here. Healing, self-revive, tonics, grenades, pylons, lanterns, Omnicells, weapon specials and mods must be tested in the game. Hammer ammo, pike charge retention and the chain-blade visual issue are not separately claimed fixed.
