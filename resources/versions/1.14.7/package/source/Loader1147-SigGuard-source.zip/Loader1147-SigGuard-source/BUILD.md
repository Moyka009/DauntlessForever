# Build

The native loader derives from the supplied 1.14.7 official package's `source/d1147_source.zip`, by Addison2k, under AGPL-3.0-only. The activation repair uses the approach demonstrated by SyST3MDeV/Undaunted (gwog and contributors), with independently traced addresses for CL647472. No offsets from its 1.4.4 build are used.

Build the DLL with Zig 0.17.0 (x86_64 Windows GNU target):

```sh
zig c++ -target x86_64-windows-gnu -shared -O2 -o Payload/dxgi.dll Source/d1147.cpp Source/minhook/hook.c Source/minhook/buffer.c Source/minhook/trampoline.c Source/minhook/hde/hde64.c -luser32 -lkernel32
```

Build the catalog overlay with Python 3:

```sh
python3 Source/build_catalog.py
```

The builder checks the old item kind, changes one enum value, re-parses the table, asserts that exactly one decoded field changed, and writes a legacy PAK 8 overlay. Its inputs are original CL647472 assets, not assets from an older build.

After rebuilding the DLL, update the loader hash in `Payload/common.ps1` and all payload hashes in `manifest.json`. Keep the original loader/common/EXE hashes as the install baseline. The installer uses the manifest rather than the patch folder's location for verification.

Host behavioral checks on Linux:

```sh
g++ -std=c++17 -O2 -Wall -Wextra Source/test_bridge.cpp -o test-bridge
./test-bridge
```

The test maps synthetic native entry points and checks success/rejection behavior, input state, key isolation, event forwarding, guarded vtable installation and no partial writes on a mismatched target. It does not emulate Unreal or test Windows networking.

Installer fixture tests were run against copies of the inspected package and exact original EXE.

```sh
node Source/test_installer.cjs /path/to/original/package /path/to/Dauntless-Win64-Shipping.exe
``` They test install/check/repeat install, preflight refusal, exact restore, unrelated-save preservation and PAK contents. Native Windows game execution remains required.

Manifest identity: `Dauntless_1.14.7.647472.manifest`, SHA256 `c7380ac8f94cd700edb4af7a393721f064ae2cb9b9a668a6f7363bde16c5812a`.

Installer fix 1 also updates the launcher's independent installed-file hash in 1.14.7 version metadata. Fixture tests reproduce the original R1 hash mismatch, upgrade it without restore, check the installed-file predicate for active and bundled metadata, and restore both metadata files byte for byte. The gameplay DLL is unchanged from R1.
